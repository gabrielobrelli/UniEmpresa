<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/index.php
 * RESPONSABILIDADE: dashboard do funcionário — atalho para nova
 *                    venda, resumo de vendas do dia e status da
 *                    jornada atual.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Jornada.php';
require_once __DIR__ . '/../app/models/Venda.php';
require_once __DIR__ . '/../app/models/ConfiguracaoEmpresa.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);
$empresaId = Auth::empresaIdEscopo();

$textoBoasVindas = ConfiguracaoEmpresa::obter($empresaId, 'texto_boas_vindas');

$pdo = getPDO();
$resumoHoje = $pdo->prepare(
    "SELECT COUNT(*) AS total_vendas, COALESCE(SUM(total), 0) AS valor_total
     FROM vendas
     WHERE funcionario_id = :usuario_id AND status = 'finalizada' AND DATE(finalizada_em) = CURDATE()"
);
$resumoHoje->execute([':usuario_id' => usuarioId()]);
$hoje = $resumoHoje->fetch();

$jornadaAberta = Jornada::buscarAbertaDoUsuario(usuarioId());
$vendaAberta = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);

$tituloPagina = 'Dashboard';
$itemMenuAtivo = 'dashboard';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<?php if ($textoBoasVindas): ?>
    <div class="alerta alerta--info"><?= escapar($textoBoasVindas) ?></div>
<?php endif; ?>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Vendas hoje</div>
        <div class="card-indicador__valor"><?= (int) $hoje['total_vendas'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Total vendido hoje</div>
        <div class="card-indicador__valor"><?= formatarMoeda((float) $hoje['valor_total']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Jornada</div>
        <div class="card-indicador__valor">
            <?= $jornadaAberta ? '<span class="badge badge--verde">Em serviço</span>' : '<span class="badge badge--cinza">Fora</span>' ?>
        </div>
    </div>
</div>

<div style="display:flex; gap:16px;">
    <a href="/funcionario/nova-venda.php" class="botao botao--primario" style="font-size:16px; padding:16px 24px;">
        <?= $vendaAberta ? 'Continuar venda em aberto' : '+ Nova venda' ?>
    </a>
    <a href="/funcionario/jornada.php" class="botao" style="background:#fff; border:1px solid var(--cor-borda); padding:16px 24px;">
        Controlar jornada
    </a>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
