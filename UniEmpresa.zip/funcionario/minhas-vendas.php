<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/minhas-vendas.php
 * RESPONSABILIDADE: o funcionário vê apenas as próprias vendas
 *                    (seção 14: "Pode: Visualizar suas próprias
 *                    vendas"). Este arquivo estava referenciado no
 *                    menu lateral, mas nunca havia sido criado.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Venda.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);
$empresaId = Auth::empresaIdEscopo();

$statusFiltro = $_GET['status'] ?? null;
$vendas = Venda::listarPorEmpresa($empresaId, $statusFiltro ?: null, usuarioId());

$tituloPagina = 'Minhas vendas';
$itemMenuAtivo = 'minhas-vendas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="nao-imprimir" style="margin-bottom:16px;">
    <a href="/funcionario/minhas-vendas.php" class="botao <?= !$statusFiltro ? 'botao--primario' : '' ?>" style="<?= $statusFiltro ? 'background:#fff;border:1px solid var(--cor-borda);' : '' ?>">Todas</a>
    <a href="/funcionario/minhas-vendas.php?status=aberta" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Abertas</a>
    <a href="/funcionario/minhas-vendas.php?status=finalizada" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Finalizadas</a>
    <a href="/funcionario/minhas-vendas.php?status=cancelada" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Canceladas</a>
</div>

<?php if (empty($vendas)): ?>
    <?php $mensagemVazia = 'Você ainda não tem vendas registradas.'; ?>
    <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
<?php else: ?>
    <table class="tabela-padrao">
        <thead>
            <tr><th>Nº</th><th>Cliente</th><th>Total</th><th>Status</th><th>Data</th><th></th></tr>
        </thead>
        <tbody>
            <?php
            $mapaBadge = [
                'aberta' => 'badge--amarelo', 'finalizada' => 'badge--verde',
                'cancelada' => 'badge--vermelho', 'devolvida' => 'badge--vermelho',
                'parcial_devolvida' => 'badge--amarelo',
            ];
            foreach ($vendas as $venda): ?>
                <tr>
                    <td>#<?= escapar($venda['numero_venda']) ?></td>
                    <td><?= escapar($venda['cliente_nome'] ?? '—') ?></td>
                    <td><?= formatarMoeda((float) $venda['total']) ?></td>
                    <td><span class="badge <?= $mapaBadge[$venda['status']] ?? 'badge--cinza' ?>"><?= ucfirst($venda['status']) ?></span></td>
                    <td><?= formatarData($venda['created_at'], true) ?></td>
                    <td>
                        <?php if ($venda['status'] !== 'aberta'): ?>
                            <a href="/funcionario/venda-comprovante.php?id=<?= (int) $venda['id'] ?>">Ver</a>
                        <?php else: ?>
                            <a href="/funcionario/nova-venda.php">Continuar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
