<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/perfil.php
 * RESPONSABILIDADE: o funcionário edita seus próprios dados
 *                    pessoais (nome, e-mail, telefone, foto, bio),
 *                    troca a senha, e vê os feedbacks recebidos do
 *                    administrador (seções 39 e 49).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Feedback.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);
$empresaId = Auth::empresaIdEscopo();

$resultado = processarFormularioPerfil();
$erro = $resultado['erro'];
$sucesso = $resultado['sucesso'];

$usuario = Usuario::buscarPorId(usuarioId());
$feedbacks = Feedback::listarPorFuncionario(usuarioId(), $empresaId);
$rotulosTipo = ['positivo' => 'Positivo', 'atencao' => 'Ponto de atenção', 'observacao' => 'Observação'];
$classeBadge = ['positivo' => 'badge--verde', 'atencao' => 'badge--amarelo', 'observacao' => 'badge--cinza'];

$tituloPagina = 'Meu perfil';
$itemMenuAtivo = 'perfil';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div style="flex:1; min-width:300px; display:flex; flex-direction:column; gap:20px;">
        <?php require __DIR__ . '/../app/views/perfil-corpo.php'; ?>
    </div>

    <div style="flex:1; min-width:320px;">
        <h3 style="margin-top:0;">Meus feedbacks</h3>
        <?php if (empty($feedbacks)): ?>
            <?php $mensagemVazia = 'Nenhum feedback recebido ainda.'; ?>
            <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
        <?php else: ?>
            <table class="tabela-padrao">
                <thead><tr><th>Data</th><th>Tipo</th><th>Descrição</th></tr></thead>
                <tbody>
                    <?php foreach ($feedbacks as $fb): ?>
                        <tr>
                            <td><?= formatarData($fb['created_at'], true) ?></td>
                            <td><span class="badge <?= $classeBadge[$fb['tipo']] ?>"><?= $rotulosTipo[$fb['tipo']] ?></span></td>
                            <td><?= escapar($fb['descricao']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
