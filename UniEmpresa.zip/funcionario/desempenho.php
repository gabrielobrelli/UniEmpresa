<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/desempenho.php
 * RESPONSABILIDADE: o funcionário acompanha o próprio desempenho
 *                    de vendas por período (seção 14: "Pode:
 *                    Visualizar seus próprios relatórios"). Este
 *                    arquivo estava referenciado no menu lateral,
 *                    mas nunca havia sido criado.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Relatorio.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);
$empresaId = Auth::empresaIdEscopo();

$atalho = $_GET['periodo'] ?? 'mes';
$periodo = resolverPeriodo($atalho, $_GET['data_inicio'] ?? null, $_GET['data_fim'] ?? null);

$desempenho = Relatorio::desempenhoFuncionario($empresaId, usuarioId(), $periodo['inicio'], $periodo['fim']);

// O ranking geral é usado só para calcular em que posição o
// funcionário está — não expõe os valores dos colegas nesta tela.
$ranking = Relatorio::rankingFuncionarios($empresaId, $periodo['inicio'], $periodo['fim']);
$minhaPosicao = null;
foreach (array_values($ranking) as $indice => $linha) {
    if ((int) $linha['id'] === usuarioId()) {
        $minhaPosicao = $indice + 1;
        break;
    }
}

$tituloPagina = 'Meu desempenho';
$itemMenuAtivo = 'desempenho';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<form method="GET" action="/funcionario/desempenho.php" class="campo nao-imprimir" style="max-width:220px; margin-bottom:16px;">
    <label for="periodo">Período</label>
    <select id="periodo" name="periodo" onchange="this.form.submit()">
        <?php foreach (['hoje' => 'Hoje', 'semana' => 'Semana', 'mes' => 'Mês', 'trimestre' => 'Trimestre'] as $valor => $rotulo): ?>
            <option value="<?= $valor ?>" <?= $atalho === $valor ? 'selected' : '' ?>><?= $rotulo ?></option>
        <?php endforeach; ?>
    </select>
</form>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Vendas no período</div>
        <div class="card-indicador__valor"><?= (int) $desempenho['total_vendas'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Total vendido</div>
        <div class="card-indicador__valor"><?= formatarMoeda((float) $desempenho['valor_total']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Ticket médio</div>
        <div class="card-indicador__valor"><?= formatarMoeda((float) $desempenho['ticket_medio']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Posição no ranking</div>
        <div class="card-indicador__valor"><?= $minhaPosicao ? '#' . $minhaPosicao . ' de ' . count($ranking) : '—' ?></div>
    </div>
</div>

<?php if ((int) $desempenho['total_vendas'] === 0): ?>
    <?php $mensagemVazia = 'Nenhuma venda finalizada no período selecionado.'; ?>
    <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
<?php endif; ?>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
