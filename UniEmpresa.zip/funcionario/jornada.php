<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/jornada.php
 * RESPONSABILIDADE: o funcionário inicia/encerra sua sessão de
 *                    serviço e acompanha suas próprias horas
 *                    trabalhadas comparadas à meta diária (seções
 *                    45, 46 e 48). O funcionário só vê os próprios
 *                    dados — nunca os de outro funcionário.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Jornada.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);
$usuario = Usuario::buscarPorId(usuarioId());

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    if (($_POST['acao'] ?? '') === 'iniciar') {
        Jornada::iniciar(usuarioEmpresaId(), usuarioId());
        Auditoria::registrar('jornada_iniciada', 'jornadas', usuarioId());
    } elseif (($_POST['acao'] ?? '') === 'encerrar') {
        Jornada::encerrar(usuarioId());
        Auditoria::registrar('jornada_encerrada', 'jornadas', usuarioId());
    }

    header('Location: /funcionario/jornada.php');
    exit;
}

$jornadaAberta = Jornada::buscarAbertaDoUsuario(usuarioId());

$atalho = $_GET['periodo'] ?? 'semana';
$periodo = resolverPeriodo($atalho, $_GET['data_inicio'] ?? null, $_GET['data_fim'] ?? null);

$historico = Jornada::listarPorUsuario(usuarioId(), $periodo['inicio'], $periodo['fim']);
$resumo = Jornada::resumoPorUsuario(usuarioId(), $periodo['inicio'], $periodo['fim'], (int) $usuario['meta_minutos_diarios']);

$tituloPagina = 'Minha jornada';
$itemMenuAtivo = 'jornada';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario" style="text-align:center;">
    <?php if ($jornadaAberta): ?>
        <p>Sessão iniciada às <strong><?= formatarData($jornadaAberta['entrada'], true) ?></strong></p>
        <form method="POST" action="/funcionario/jornada.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="encerrar">
            <button type="submit" class="botao" style="background: var(--cor-erro); color:#fff; font-size:16px; padding:14px 28px;">
                Encerrar sessão de serviço
            </button>
        </form>
    <?php else: ?>
        <p>Nenhuma sessão em andamento.</p>
        <form method="POST" action="/funcionario/jornada.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="iniciar">
            <button type="submit" class="botao botao--primario" style="font-size:16px; padding:14px 28px;">
                Iniciar sessão de serviço
            </button>
        </form>
    <?php endif; ?>
</div>

<div class="grade-cards" style="margin-top:24px;">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Horas trabalhadas no período</div>
        <div class="card-indicador__valor"><?= minutosParaHoras($resumo['minutos_trabalhados']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Horas previstas (meta x dias)</div>
        <div class="card-indicador__valor"><?= minutosParaHoras($resumo['minutos_previstos']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Diferença</div>
        <div class="card-indicador__valor" style="color: <?= $resumo['diferenca_minutos'] < 0 ? 'var(--cor-erro)' : 'var(--cor-sucesso)' ?>;">
            <?= $resumo['diferenca_minutos'] < 0 ? '-' : '+' ?><?= minutosParaHoras(abs($resumo['diferenca_minutos'])) ?>
        </div>
    </div>
</div>

<form method="GET" action="/funcionario/jornada.php" class="campo nao-imprimir" style="max-width:220px; margin-bottom:16px;">
    <label for="periodo">Período</label>
    <select id="periodo" name="periodo" onchange="this.form.submit()">
        <?php foreach (['hoje' => 'Hoje', 'semana' => 'Semana', 'mes' => 'Mês', 'ultimos_30_dias' => 'Últimos 30 dias'] as $valor => $rotulo): ?>
            <option value="<?= $valor ?>" <?= $atalho === $valor ? 'selected' : '' ?>><?= $rotulo ?></option>
        <?php endforeach; ?>
    </select>
</form>

<table class="tabela-padrao">
    <thead><tr><th>Entrada</th><th>Saída</th><th>Duração</th></tr></thead>
    <tbody>
        <?php foreach ($historico as $j): ?>
            <tr>
                <td><?= formatarData($j['entrada'], true) ?></td>
                <td><?= $j['saida'] ? formatarData($j['saida'], true) : '— em andamento —' ?></td>
                <td><?= $j['duracao_minutos'] !== null ? minutosParaHoras((int) $j['duracao_minutos']) : '—' ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($historico)): ?>
            <tr><td colspan="3">Nenhum registro de jornada no período.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
