<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/venda-comprovante.php
 * RESPONSABILIDADE: exibir o comprovante de uma venda finalizada,
 *                    pronto para impressão (seção 28). Acessível
 *                    tanto pelo funcionário que fez a venda quanto
 *                    por administradores da mesma empresa.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Venda.php';

Auth::exigirTipo([TIPO_FUNCIONARIO, TIPO_ADMIN]);
$empresaId = Auth::empresaIdEscopo();

$vendaId = (int) ($_GET['id'] ?? 0);
$venda = Venda::buscarPorId($vendaId, $empresaId);

if (!$venda) {
    http_response_code(404);
    die('Venda não encontrada.');
}

// Um funcionário só pode ver o próprio comprovante; o admin pode ver
// qualquer venda da empresa (a checagem de empresa já veio acima).
if (usuarioTipo() === TIPO_FUNCIONARIO && (int) $venda['funcionario_id'] !== usuarioId()) {
    http_response_code(403);
    die('Você não tem permissão para ver esta venda.');
}

$itens = Venda::listarItens($vendaId);

$pdo = getPDO();
$stmtPagamentos = $pdo->prepare('SELECT * FROM venda_pagamentos WHERE venda_id = :id');
$stmtPagamentos->execute([':id' => $vendaId]);
$pagamentos = $stmtPagamentos->fetchAll();

$stmtEmpresa = $pdo->prepare('SELECT nome_fantasia, logo, cpf_cnpj, telefone, endereco FROM empresas WHERE id = :id');
$stmtEmpresa->execute([':id' => $empresaId]);
$empresa = $stmtEmpresa->fetch();

$stmtFuncionario = $pdo->prepare('SELECT nome FROM usuarios WHERE id = :id');
$stmtFuncionario->execute([':id' => $venda['funcionario_id']]);
$funcionario = $stmtFuncionario->fetch();

$rotulosPagamento = ['dinheiro' => 'Dinheiro', 'pix' => 'Pix', 'debito' => 'Cartão de débito', 'credito' => 'Cartão de crédito', 'outro' => 'Outro'];
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comprovante — Venda #<?= escapar($venda['numero_venda']) ?></title>
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/comprovante.css">
</head>
<body>

<div class="comprovante">
    <div class="comprovante__cabecalho">
        <?php if (!empty($empresa['logo'])): ?>
            <img src="<?= escapar($empresa['logo']) ?>" alt="Logo" class="comprovante__logo">
        <?php endif; ?>
        <h2><?= escapar($empresa['nome_fantasia']) ?></h2>
        <p><?= escapar($empresa['cpf_cnpj'] ?? '') ?> · <?= escapar($empresa['telefone'] ?? '') ?></p>
        <p><?= escapar($empresa['endereco'] ?? '') ?></p>
    </div>

    <hr>

    <p><strong>Venda:</strong> #<?= escapar($venda['numero_venda']) ?></p>
    <p><strong>Data:</strong> <?= formatarData($venda['finalizada_em'] ?? $venda['created_at'], true) ?></p>
    <p><strong>Atendente:</strong> <?= escapar($funcionario['nome'] ?? '—') ?></p>
    <p><strong>Status:</strong> <?= escapar(ucfirst($venda['status'])) ?></p>

    <table class="tabela-padrao">
        <thead>
            <tr><th>Produto</th><th>Qtd.</th><th>Unit.</th><th>Subtotal</th></tr>
        </thead>
        <tbody>
            <?php foreach ($itens as $item): ?>
                <tr>
                    <td><?= escapar($item['produto_nome']) ?></td>
                    <td><?= rtrim(rtrim(number_format((float) $item['quantidade'], 3, ',', '.'), '0'), ',') ?></td>
                    <td><?= formatarMoeda((float) $item['preco_unitario']) ?></td>
                    <td><?= formatarMoeda((float) $item['subtotal']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <p class="comprovante__total">Total: <?= formatarMoeda((float) $venda['total']) ?></p>

    <p><strong>Pagamento:</strong></p>
    <ul>
        <?php foreach ($pagamentos as $pagamento): ?>
            <li>
                <?= escapar($rotulosPagamento[$pagamento['forma']] ?? $pagamento['forma']) ?>:
                <?= formatarMoeda((float) $pagamento['valor']) ?>
                <?= $pagamento['parcelas'] > 1 ? 'em ' . (int) $pagamento['parcelas'] . 'x' : '' ?>
            </li>
        <?php endforeach; ?>
    </ul>

    <p class="comprovante__rodape">
        Este é um comprovante interno/comercial e não substitui documento fiscal oficial.
    </p>

    <button class="botao botao--primario nao-imprimir" onclick="window.print()">Imprimir</button>
</div>

</body>
</html>
