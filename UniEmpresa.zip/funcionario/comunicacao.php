<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/comunicacao.php
 * RESPONSABILIDADE: tela de chat do Funcionário — conversa apenas
 *                    com administradores da própria empresa
 *                    (seção 40).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);

$tituloPagina = 'Chat';
$itemMenuAtivo = 'chat';
require __DIR__ . '/../app/views/layout-inicio.php';
require __DIR__ . '/../app/views/comunicacao-corpo.php';
require __DIR__ . '/../app/views/layout-fim.php';
