<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/nova-venda.php
 * RESPONSABILIDADE: interface de PDV — o funcionário informa o
 *                    código do produto, quantidade, o sistema
 *                    localiza automaticamente, soma o carrinho e
 *                    finaliza a venda (seção 22 do documento).
 *
 * A tela em si é só a estrutura HTML; toda a interação dinâmica
 * (buscar produto, adicionar/remover itens, finalizar) acontece
 * via JavaScript (public/js/pdv.js) conversando com api/pdv.php.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Venda.php';
require_once __DIR__ . '/../app/models/Cliente.php';

Auth::exigirTipo([TIPO_FUNCIONARIO, TIPO_ADMIN]);
$empresaId = Auth::empresaIdEscopo();

// Recupera (ou implicitamente cria, ao adicionar o primeiro item) a
// venda em aberto do usuário, para o carrinho já aparecer preenchido
// caso ele tenha saído da tela no meio de um atendimento.
$vendaAberta = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);
$itensCarrinho = $vendaAberta ? Venda::listarItens((int) $vendaAberta['id']) : [];
$totalAtual = $vendaAberta ? (float) $vendaAberta['total'] : 0.0;

$clientes = Cliente::listarPorEmpresa($empresaId);

$tituloPagina = 'Nova venda';
$itemMenuAtivo = 'nova-venda';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="pdv">
    <div class="pdv__entrada cartao-formulario" style="max-width:none;">
        <div class="linha-campos">
            <div class="campo">
                <label for="pdv-codigo">Código do produto</label>
                <input type="text" id="pdv-codigo" placeholder="Digite ou escaneie o código" autofocus>
            </div>
            <div class="campo">
                <label for="pdv-quantidade">Quantidade</label>
                <input type="text" id="pdv-quantidade" value="1">
            </div>
        </div>
        <button type="button" id="pdv-btn-adicionar" class="botao botao--primario">Adicionar produto</button>

        <div class="campo" style="margin-top:14px; position:relative;">
            <label for="pdv-busca-nome">Não sabe o código? Busque pelo nome do produto</label>
            <input type="text" id="pdv-busca-nome" placeholder="Digite ao menos 2 letras do nome..." autocomplete="off">
            <div id="pdv-sugestoes" class="pdv-sugestoes" style="display:none;"></div>
        </div>

        <div id="pdv-mensagem" class="alerta" style="display:none; margin-top:12px;"></div>

        <div class="campo" style="margin-top:16px;">
            <label for="pdv-cliente">Cliente (opcional)</label>
            <div style="display:flex; gap:8px;">
                <select id="pdv-cliente" style="flex:1;">
                    <option value="">— Venda sem cliente identificado —</option>
                    <?php foreach ($clientes as $cliente): ?>
                        <option value="<?= (int) $cliente['id'] ?>" <?= (($vendaAberta['cliente_id'] ?? null) == $cliente['id']) ? 'selected' : '' ?>>
                            <?= escapar($cliente['nome']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="button" id="pdv-btn-novo-cliente" class="botao" style="background:#fff; border:1px solid var(--cor-borda); white-space:nowrap;">+ Novo</button>
            </div>

            <div id="pdv-form-novo-cliente" style="display:none; margin-top:10px; padding:12px; background:#f8fafc; border-radius:var(--raio-padrao);">
                <div class="linha-campos">
                    <div class="campo">
                        <label for="pdv-cliente-nome">Nome *</label>
                        <input type="text" id="pdv-cliente-nome">
                    </div>
                    <div class="campo">
                        <label for="pdv-cliente-telefone">Telefone</label>
                        <input type="text" id="pdv-cliente-telefone">
                    </div>
                </div>
                <button type="button" id="pdv-btn-salvar-cliente" class="botao botao--primario">Salvar cliente</button>
                <button type="button" id="pdv-btn-cancelar-cliente" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Cancelar</button>
            </div>
        </div>
    </div>

    <div class="pdv__carrinho cartao-formulario" style="max-width:none; margin-top:20px;">
        <h3 style="margin-top:0;">Carrinho</h3>
        <table class="tabela-padrao">
            <thead>
                <tr><th>Produto</th><th>Qtd.</th><th>Preço unit.</th><th>Subtotal</th><th></th></tr>
            </thead>
            <tbody id="pdv-tabela-itens">
                <?php foreach ($itensCarrinho as $item): ?>
                    <tr data-item-id="<?= (int) $item['id'] ?>">
                        <td><?= escapar($item['produto_nome']) ?></td>
                        <td><?= rtrim(rtrim(number_format((float) $item['quantidade'], 3, ',', '.'), '0'), ',') ?></td>
                        <td><?= formatarMoeda((float) $item['preco_unitario']) ?></td>
                        <td><?= formatarMoeda((float) $item['subtotal']) ?></td>
                        <td><button type="button" class="pdv-remover-item" data-item-id="<?= (int) $item['id'] ?>" style="color:var(--cor-erro); border:none; background:none; cursor:pointer;">Remover</button></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="text-align:right; margin-top:16px; font-size:22px; font-weight:700;">
            Total: <span id="pdv-total"><?= formatarMoeda($totalAtual) ?></span>
        </div>

        <button type="button" id="pdv-btn-finalizar" class="botao botao--primario" style="margin-top:16px;">
            Finalizar venda
        </button>
    </div>
</div>

<!-- Modal simples de pagamento, controlado por JS (mostrar/ocultar) -->
<div id="pdv-modal-pagamento" class="pdv-modal" style="display:none;">
    <div class="pdv-modal__conteudo cartao-formulario">
        <h3 style="margin-top:0;">Pagamento</h3>
        <p>Total da venda: <strong id="pdv-modal-total"></strong></p>

        <div id="pdv-lista-pagamentos"></div>

        <div class="linha-campos">
            <div class="campo">
                <label for="pdv-forma-pagamento">Forma</label>
                <select id="pdv-forma-pagamento">
                    <option value="dinheiro">Dinheiro</option>
                    <option value="pix">Pix</option>
                    <option value="debito">Cartão de débito</option>
                    <option value="credito">Cartão de crédito</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
            <div class="campo">
                <label for="pdv-valor-pagamento">Valor (R$)</label>
                <input type="text" id="pdv-valor-pagamento">
            </div>
        </div>
        <div class="campo" id="pdv-campo-parcelas" style="display:none;">
            <label for="pdv-parcelas">Número de parcelas</label>
            <input type="number" id="pdv-parcelas" min="1" value="1">
        </div>

        <button type="button" id="pdv-btn-add-pagamento" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">
            + Adicionar forma de pagamento
        </button>

        <p style="margin-top:16px;">Restante a pagar: <strong id="pdv-restante"></strong></p>

        <div style="display:flex; gap:8px; margin-top:16px;">
            <button type="button" id="pdv-btn-confirmar-pagamento" class="botao botao--primario">Confirmar e finalizar</button>
            <button type="button" id="pdv-btn-cancelar-pagamento" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Cancelar</button>
        </div>
    </div>
</div>

<link rel="stylesheet" href="/public/css/pdv.css">
<script>
    // Dados iniciais passados do PHP para o JavaScript do PDV.
    window.PDV_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;
    window.PDV_TOTAL_ATUAL = <?= json_encode($totalAtual) ?>;
</script>
<script src="/public/js/pdv.js"></script>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
