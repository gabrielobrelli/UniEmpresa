<?php
/**
 * =============================================================
 * ARQUIVO: funcionario/completar-perfil.php
 * RESPONSABILIDADE: tela obrigatória de primeiro acesso do
 *                    funcionário (seção 13). Enquanto os campos
 *                    obrigatórios não forem preenchidos, o
 *                    middleware Auth::verificarPerfilCompleto()
 *                    redireciona qualquer outra página para cá.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_FUNCIONARIO);

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $nome = limparEntrada($_POST['nome'] ?? '');
    $telefone = limparEntrada($_POST['telefone'] ?? '');
    $cargo = limparEntrada($_POST['cargo'] ?? '');

    if ($nome === '' || $telefone === '' || $cargo === '') {
        $erro = 'Nome, telefone e cargo são obrigatórios para continuar.';
    } elseif (empty($_FILES['foto']['name'])) {
        $erro = 'A foto de perfil é obrigatória para continuar.';
    } else {
        try {
            $caminhoFoto = salvarImagemEnviada($_FILES['foto'], 'usuarios/' . usuarioId());

            $pdo = getPDO();
            $pdo->prepare(
                'UPDATE usuarios SET nome=:nome, telefone=:telefone, cargo=:cargo, foto=:foto,
                    perfil_completo=1, updated_at=NOW() WHERE id=:id'
            )->execute([
                ':nome' => $nome, ':telefone' => $telefone, ':cargo' => $cargo,
                ':foto' => $caminhoFoto, ':id' => usuarioId(),
            ]);

            $_SESSION['nome'] = $nome;
            marcarPerfilComoCompleto();

            Auditoria::registrar('perfil_completado', 'usuarios', usuarioId());

            header('Location: /funcionario/index.php');
            exit;
        } catch (RuntimeException $e) {
            $erro = $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Complete seu perfil — <?= escapar(APP_NOME) ?></title>
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
</head>
<body class="pagina-login">
    <main class="cartao-login" style="max-width: 440px;">
        <h1 class="cartao-login__titulo">Complete seu perfil</h1>
        <p class="cartao-login__subtitulo">
            Antes de continuar, precisamos de mais algumas informações suas.
        </p>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/funcionario/completar-perfil.php" enctype="multipart/form-data" class="formulario-login">
            <?= csrfCampoOculto() ?>

            <label for="nome">Nome completo</label>
            <input type="text" id="nome" name="nome" required value="<?= escapar($_SESSION['nome'] ?? '') ?>">

            <label for="foto">Foto de perfil</label>
            <input type="file" id="foto" name="foto" accept=".jpg,.jpeg,.png,.webp" required>

            <label for="cargo">Função/cargo</label>
            <input type="text" id="cargo" name="cargo" required>

            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" required>

            <button type="submit" class="botao botao--primario">Concluir e entrar no sistema</button>
        </form>
    </main>
</body>
</html>
