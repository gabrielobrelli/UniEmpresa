<?php
/**
 * =============================================================
 * ARQUIVO: api/notificacoes.php
 * RESPONSABILIDADE: endpoint AJAX usado pelo sino de notificações
 *                    no topo das telas internas — lista as
 *                    notificações do usuário logado e permite
 *                    marcá-las como lidas (seção 42).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Notificacao.php';

// Definido antes de tudo, para qualquer erro já responder em JSON.
header('Content-Type: application/json; charset=utf-8');

$acao = $_REQUEST['acao'] ?? 'listar';

try {
    // A checagem de login roda dentro do try — se falhar de forma
    // inesperada, cai no catch e responde em JSON, nunca em branco.
    Auth::exigirLogin();

    if (in_array($acao, ['marcar_lida', 'marcar_todas_lidas'], true)) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            echo json_encode(['sucesso' => false, 'mensagem' => 'Método não permitido.']);
            exit;
        }
        csrfValidarOuFalhar();
    }

    switch ($acao) {

        case 'listar':
            echo json_encode([
                'sucesso' => true,
                'notificacoes' => Notificacao::listarDoUsuario(usuarioId()),
                'nao_lidas' => Notificacao::contarNaoLidas(usuarioId()),
            ]);
            break;

        case 'marcar_lida':
            Notificacao::marcarComoLida((int) ($_POST['id'] ?? 0), usuarioId());
            echo json_encode(['sucesso' => true]);
            break;

        case 'marcar_todas_lidas':
            Notificacao::marcarTodasComoLidas(usuarioId());
            echo json_encode(['sucesso' => true]);
            break;

        default:
            echo json_encode(['sucesso' => false, 'mensagem' => 'Ação inválida.']);
    }
} catch (Throwable $e) {
    error_log('[api/notificacoes] ' . $e->getMessage());
    echo json_encode(['sucesso' => false, 'mensagem' => 'Não foi possível completar a ação agora.']);
}
