<?php
/**
 * =============================================================
 * ARQUIVO: api/comunicacao.php
 * RESPONSABILIDADE: endpoint único de AJAX/fetch do chat interno,
 *                    usado por Mestre, Admin e Funcionário. Como o
 *                    InfinityFree não suporta WebSocket, o frontend
 *                    faz polling periódico (a cada poucos segundos)
 *                    chamando 'listar_mensagens' com o ID da última
 *                    mensagem já recebida (seção 41).
 *
 * AÇÕES SUPORTADAS (via $_POST['acao'] ou $_GET['acao']):
 *   - inicializar        : contatos + conversas em uma única chamada
 *   - listar_contatos    : quem o usuário logado pode conversar
 *   - listar_conversas   : conversas já existentes + não lidas
 *   - abrir_conversa     : obtém/cria a conversa com um contato
 *   - listar_mensagens   : mensagens de uma conversa (polling incremental)
 *   - enviar_mensagem    : envia uma nova mensagem
 *
 * IMPORTANTE: TUDO neste arquivo — inclusive a checagem de login —
 * roda dentro de um único try/catch (ver mais abaixo). Isso garante
 * que qualquer erro inesperado (de banco, de permissão, o que for)
 * sempre vira uma resposta JSON legível, nunca uma página de erro
 * em branco ou genérica do servidor.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Conversa.php';
require_once __DIR__ . '/../app/models/Mensagem.php';

// Definido ANTES de qualquer outra coisa, para garantir que mesmo um
// erro bem no início da requisição já responda em JSON (e não em
// HTML), o que ajuda tanto o frontend quanto a depuração.
header('Content-Type: application/json; charset=utf-8');

/**
 * FUNÇÃO: responderChat()
 * O QUE FAZ: padroniza toda resposta deste endpoint e encerra a
 *            execução — usada tanto pelas ações de sucesso quanto
 *            pelo tratamento de erro no final do arquivo.
 * FIM DA FUNÇÃO
 */
function responderChat(bool $sucesso, array $dados = [], string $mensagem = ''): void
{
    echo json_encode(array_merge(['sucesso' => $sucesso, 'mensagem' => $mensagem], $dados));
    exit;
}

try {
    // A verificação de login também está dentro do try — se ela
    // lançar qualquer exceção inesperada (ex.: falha de conexão com
    // o banco), cai no catch lá embaixo e responde em JSON, em vez de
    // travar a requisição sem explicação nenhuma.
    Auth::exigirLogin();

    // GET é aceito apenas para as ações de LEITURA (polling); qualquer
    // ação que grava dado (enviar mensagem, abrir conversa) exige POST
    // com token CSRF validado — leitura não muda estado, então dispensa
    // CSRF, mas escrita sempre precisa.
    $acao = $_REQUEST['acao'] ?? '';
    $acoesDeEscrita = ['enviar_mensagem', 'abrir_conversa'];

    if (in_array($acao, $acoesDeEscrita, true)) {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            responderChat(false, [], 'Método não permitido.');
        }
        csrfValidarOuFalhar();
    }

    switch ($acao) {

        case 'inicializar':
            // Combina contatos + conversas em UMA única requisição, em
            // vez de duas simultâneas — reduz o "pico" de tráfego ao
            // abrir o chat.
            responderChat(true, [
                'contatos' => Conversa::contatosPermitidos(usuarioId(), usuarioTipo(), usuarioEmpresaId()),
                'conversas' => Conversa::listarConversasDoUsuario(usuarioId()),
            ]);
            break;

        case 'listar_contatos':
            responderChat(true, ['contatos' => Conversa::contatosPermitidos(usuarioId(), usuarioTipo(), usuarioEmpresaId())]);
            break;

        case 'listar_conversas':
            responderChat(true, ['conversas' => Conversa::listarConversasDoUsuario(usuarioId())]);
            break;

        case 'abrir_conversa':
            $destinatarioId = (int) ($_POST['destinatario_id'] ?? 0);

            // Checagem de permissão no backend — a lista mostrada na
            // tela é só uma sugestão visual, quem decide de verdade é aqui.
            if (!Conversa::podeConversarCom(usuarioId(), usuarioTipo(), usuarioEmpresaId(), $destinatarioId)) {
                responderChat(false, [], 'Você não tem permissão para conversar com este usuário.');
            }

            responderChat(true, ['conversa_id' => Conversa::obterOuCriar(usuarioId(), $destinatarioId)]);
            break;

        case 'listar_mensagens':
            $conversaId = (int) ($_REQUEST['conversa_id'] ?? 0);
            $depoisDoId = (int) ($_REQUEST['depois_de'] ?? 0);

            if (!Conversa::participaDaConversa($conversaId, usuarioId())) {
                responderChat(false, [], 'Conversa não encontrada.');
            }

            $mensagens = Mensagem::listarPorConversa($conversaId, $depoisDoId);
            Mensagem::marcarComoLidas($conversaId, usuarioId());

            responderChat(true, ['mensagens' => $mensagens]);
            break;

        case 'enviar_mensagem':
            $conversaId = (int) ($_POST['conversa_id'] ?? 0);
            $texto = trim($_POST['texto'] ?? '');

            if (!Conversa::participaDaConversa($conversaId, usuarioId())) {
                responderChat(false, [], 'Conversa não encontrada.');
            }
            if ($texto === '') {
                responderChat(false, [], 'Digite uma mensagem antes de enviar.');
            }

            Mensagem::enviar($conversaId, usuarioId(), $texto);
            responderChat(true);
            break;

        default:
            responderChat(false, [], 'Ação inválida.');
    }
} catch (Throwable $e) {
    // Detalhe técnico só no log do servidor — nunca exposto ao
    // navegador, mas é o primeiro lugar a olhar (vPanel > Error Log)
    // se esta mensagem genérica aparecer com frequência.
    error_log('[api/chat] ' . $e->getMessage());
    responderChat(false, [], 'Não foi possível completar a ação agora. Tente novamente em instantes.');
}
