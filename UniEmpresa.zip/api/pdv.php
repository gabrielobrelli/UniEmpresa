<?php
/**
 * =============================================================
 * ARQUIVO: api/pdv.php
 * RESPONSABILIDADE: endpoint único de AJAX/fetch usado pela tela
 *                    de PDV (funcionario/nova-venda.php). Recebe
 *                    POST com um campo 'acao' e devolve JSON.
 *
 * POR QUE UM ENDPOINT SÓ: o InfinityFree não oferece WebSocket nem
 * processos em background — a tela de PDV conversa com o servidor
 * inteiramente via fetch() comuns (seção 41), e concentrar as ações
 * do carrinho em um único arquivo evita duplicar a checagem de
 * autenticação/CSRF/empresa em vários endpoints pequenos.
 *
 * AÇÕES SUPORTADAS (via $_POST['acao']):
 *   - buscar_produto   : localizar produto por código/código de barras
 *   - adicionar_item   : adicionar produto ao carrinho da venda aberta
 *   - remover_item     : remover uma linha do carrinho
 *   - vincular_cliente : associar um cliente à venda aberta
 *   - finalizar        : fechar a venda com os pagamentos informados
 *   - cancelar_aberta  : cancelar a venda aberta atual (esvaziar carrinho)
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/Venda.php';
require_once __DIR__ . '/../app/models/Cliente.php';

// Definido logo de cara: mesmo um erro bem no início da requisição
// (ex.: na checagem de login) já responde em JSON, nunca em HTML.
header('Content-Type: application/json; charset=utf-8');

$acao = $_POST['acao'] ?? '';

/**
 * FUNÇÃO: responder()
 * O QUE FAZ: padroniza o formato de resposta JSON de todo o
 *            endpoint (sucesso/erro + dados), e encerra a execução.
 * FIM DA FUNÇÃO
 */
function responder(bool $sucesso, array $dados = [], string $mensagem = ''): void
{
    echo json_encode(array_merge(['sucesso' => $sucesso, 'mensagem' => $mensagem], $dados));
    exit;
}

/**
 * FUNÇÃO: obterOuAbrirVendaAtual()
 * O QUE FAZ: devolve o ID da venda aberta do usuário logado,
 *            criando uma nova automaticamente se não existir.
 * FIM DA FUNÇÃO
 */
function obterOuAbrirVendaAtual(int $empresaId): int
{
    $venda = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);
    if ($venda) {
        return (int) $venda['id'];
    }

    return Venda::abrirNova($empresaId, usuarioId());
}

/**
 * FUNÇÃO: montarResumoCarrinho()
 * O QUE FAZ: monta o array de itens + total atual da venda, no
 *            formato que o JavaScript do PDV espera para redesenhar
 *            o carrinho na tela sem precisar recarregar a página.
 * FIM DA FUNÇÃO
 */
function montarResumoCarrinho(int $vendaId, int $empresaId): array
{
    $venda = Venda::buscarPorId($vendaId, $empresaId);
    $itens = Venda::listarItens($vendaId);

    return [
        'venda_id' => $vendaId,
        'total' => (float) $venda['total'],
        'itens' => array_map(static function (array $item): array {
            return [
                'id' => (int) $item['id'],
                'produto_nome' => $item['produto_nome'],
                'quantidade' => (float) $item['quantidade'],
                'preco_unitario' => (float) $item['preco_unitario'],
                'subtotal' => (float) $item['subtotal'],
            ];
        }, $itens),
    ];
}

// Qualquer erro inesperado vira uma resposta JSON legível, em vez de
// travar silenciosamente o carrinho de compras do funcionário — a
// checagem de login/permissão também roda aqui dentro, coberta pela
// mesma proteção.
try {

// O PDV é usado por funcionários e também pode ser usado por
// administradores realizando vendas diretamente (seção 22 não
// restringe o PDV só ao funcionário).
Auth::exigirTipo([TIPO_FUNCIONARIO, TIPO_ADMIN]);
$empresaId = Auth::empresaIdEscopo();
csrfValidarOuFalhar();

switch ($acao) {

    case 'buscar_produto':
        $codigo = limparEntrada($_POST['codigo'] ?? '');
        $produto = Produto::buscarPorCodigoOuBarras($codigo, $empresaId);

        if (!$produto) {
            responder(false, [], 'Produto não encontrado para o código informado.');
        }

        responder(true, [
            'produto' => [
                'id' => (int) $produto['id'],
                'nome' => $produto['nome'],
                'preco_venda' => (float) $produto['preco_venda'],
                'estoque_atual' => (float) $produto['estoque_atual'],
            ],
        ]);
        break;

    case 'sugerir_produtos':
        // Busca por nome (ou código) para o autocomplete do PDV — útil
        // quando o produto não tem um código fácil de decorar/digitar.
        // Limitado a 8 resultados para a lista de sugestões ficar rápida
        // de ler no celular.
        $termo = limparEntrada($_POST['termo'] ?? '');

        if (mb_strlen($termo) < 2) {
            responder(true, ['produtos' => []]);
        }

        $produtos = Produto::listarPorEmpresa($empresaId, $termo, 1, 8);

        responder(true, [
            'produtos' => array_map(static function (array $p): array {
                return [
                    'id' => (int) $p['id'],
                    'nome' => $p['nome'],
                    'codigo' => $p['codigo'],
                    'preco_venda' => (float) $p['preco_venda'],
                    'estoque_atual' => (float) $p['estoque_atual'],
                ];
            }, $produtos),
        ]);
        break;

    case 'criar_cliente':
        // Cadastro rápido de cliente sem sair da tela de venda —
        // usado pelo botão "+ Novo cliente" ao lado do seletor.
        $nome = limparEntrada($_POST['nome'] ?? '');
        $telefone = limparEntrada($_POST['telefone'] ?? '');

        if ($nome === '') {
            responder(false, [], 'Informe o nome do cliente.');
        }

        $clienteId = Cliente::criar($empresaId, ['nome' => $nome, 'telefone' => $telefone ?: null]);

        responder(true, ['cliente' => ['id' => $clienteId, 'nome' => $nome]]);
        break;

    case 'adicionar_item':
        $produtoId = (int) ($_POST['produto_id'] ?? 0);
        $quantidade = (float) str_replace(',', '.', $_POST['quantidade'] ?? '1');

        if ($produtoId <= 0 || $quantidade <= 0) {
            responder(false, [], 'Informe um produto e uma quantidade válida.');
        }

        $vendaId = obterOuAbrirVendaAtual($empresaId);

        try {
            Venda::adicionarItem($vendaId, $produtoId, $empresaId, $quantidade);
            responder(true, montarResumoCarrinho($vendaId, $empresaId));
        } catch (RuntimeException $e) {
            responder(false, [], $e->getMessage());
        }
        break;

    case 'remover_item':
        $itemId = (int) ($_POST['item_id'] ?? 0);
        $venda = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);

        if (!$venda) {
            responder(false, [], 'Nenhuma venda em aberto.');
        }

        Venda::removerItem($itemId, (int) $venda['id']);
        responder(true, montarResumoCarrinho((int) $venda['id'], $empresaId));
        break;

    case 'vincular_cliente':
        $clienteId = (int) ($_POST['cliente_id'] ?? 0) ?: null;
        $venda = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);

        if (!$venda) {
            responder(false, [], 'Nenhuma venda em aberto.');
        }

        Venda::vincularCliente((int) $venda['id'], $clienteId);
        responder(true);
        break;

    case 'finalizar':
        $venda = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);
        if (!$venda) {
            responder(false, [], 'Nenhuma venda em aberto para finalizar.');
        }

        // Os pagamentos chegam como JSON dentro do POST (uma lista de
        // { forma, valor, parcelas }), permitindo pagamento combinado
        // (seção 26) com qualquer número de formas simultâneas.
        $pagamentosJson = $_POST['pagamentos'] ?? '[]';
        $pagamentos = json_decode($pagamentosJson, true);

        if (!is_array($pagamentos) || empty($pagamentos)) {
            responder(false, [], 'Informe ao menos uma forma de pagamento.');
        }

        try {
            Venda::finalizar((int) $venda['id'], $empresaId, $pagamentos, usuarioId());

            Auditoria::registrar('venda_finalizada', 'vendas', (int) $venda['id']);

            responder(true, ['venda_id' => (int) $venda['id']], 'Venda finalizada com sucesso.');
        } catch (RuntimeException $e) {
            responder(false, [], $e->getMessage());
        }
        break;

    case 'cancelar_aberta':
        $venda = Venda::buscarVendaAbertaDoFuncionario(usuarioId(), $empresaId);
        if ($venda) {
            Venda::cancelar((int) $venda['id'], $empresaId, 'Cancelada pelo funcionário antes de finalizar', usuarioId());
        }
        responder(true);
        break;

    default:
        responder(false, [], 'Ação inválida.');
}

} catch (Throwable $e) {
    error_log('[api/pdv] ' . $e->getMessage());
    responder(false, [], 'Não foi possível completar a ação agora. Tente novamente em instantes.');
}
