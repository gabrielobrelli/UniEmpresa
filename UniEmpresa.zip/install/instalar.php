<?php
/**
 * =============================================================
 * ARQUIVO: install/instalar.php
 * RESPONSABILIDADE: criar o primeiro usuário Mestre da plataforma,
 *                    uma única vez, logo após importar o schema.sql.
 *
 * COMO USAR:
 *   1. Importe database/schema.sql pelo phpMyAdmin.
 *   2. Configure config/database.php com os dados reais do banco.
 *   3. Acesse este arquivo pelo navegador (ex.: seusite.com/install/instalar.php).
 *   4. Após a mensagem de sucesso, APAGUE a pasta install/ do servidor
 *      — ela não deve continuar acessível em produção.
 *
 * SEGURANÇA:
 *   - Este script verifica se já existe um Mestre cadastrado antes de
 *     fazer qualquer coisa, para não ser possível criar um segundo
 *     Mestre "escondido" rodando o instalador de novo.
 *   - A senha é gravada apenas como hash (password_hash()), nunca em
 *     texto puro.
 *   - As credenciais abaixo são as informadas para a implantação
 *     inicial deste projeto — troque a senha pelo painel do sistema
 *     assim que possível após o primeiro login.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Usuario.php';

// Credenciais do primeiro acesso, definidas para esta implantação.
const MESTRE_INICIAL_USUARIO = 'gabrielobrelli@gmail.com';
const MESTRE_INICIAL_SENHA = 'idn78910';

/**
 * FUNÇÃO: executarInstalacao()
 * O QUE FAZ: função principal deste script — verifica se a
 *            instalação já foi feita e, se não, cria o Mestre.
 * COMO FAZ: chama Usuario::existeAlgumMestre(); se já existir,
 *           interrompe com uma mensagem clara. Caso contrário,
 *           insere o novo usuário com tipo 'mestre' e empresa_id
 *           nulo (Mestre não pertence a nenhuma empresa).
 * FIM DA FUNÇÃO
 */
function executarInstalacao(): string
{
    if (Usuario::existeAlgumMestre()) {
        return 'Já existe um usuário Mestre cadastrado. Por segurança, este instalador não faz nada. Apague a pasta install/ do servidor.';
    }

    // O campo 'email' da tabela usuarios é usado como login. O
    // formulário de login aceita tanto um e-mail quanto um simples
    // nome de usuário nesse campo (não exige o formato "algo@algo.com").
    Usuario::criar([
        'empresa_id' => null,
        'tipo' => TIPO_MESTRE,
        'nome' => 'Administrador da Plataforma',
        'email' => MESTRE_INICIAL_USUARIO,
        'senha' => MESTRE_INICIAL_SENHA,
        'perfil_completo' => 1,
        'status' => 'ativo',
    ]);

    return 'Usuário Mestre criado com sucesso! Use "' . MESTRE_INICIAL_USUARIO . '" e a senha definida para acessar /login.php. '
        . 'Em seguida, troque a senha pelo painel e APAGUE a pasta install/ do servidor.';
}

$resultado = executarInstalacao();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Instalação — <?= escapar(APP_NOME) ?></title>
    <link rel="icon" type="image/png" href="/assets/img/empresa.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
</head>
<body class="pagina-login">
    <main class="cartao-login">
        <img src="/assets/img/empresa.png" alt="<?= escapar(APP_NOME) ?>" class="cartao-login__logo">
        <h1 class="cartao-login__titulo">Instalação</h1>
        <div class="alerta alerta--info"><?= escapar($resultado) ?></div>
        <a href="/login.php" class="botao botao--primario">Ir para o login</a>
    </main>
</body>
</html>
