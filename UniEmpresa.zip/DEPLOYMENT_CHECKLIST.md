# Checklist de Implantação — UniEmpresa

Use esta lista antes de considerar o sistema pronto para uso real,
por segmento do documento de requisitos original (seção 96).

## Autenticação
- [ ] Login Mestre funciona com as credenciais criadas no instalador
- [ ] Login Admin funciona (criar um administrador de teste pelo Mestre)
- [ ] Login Funcionário funciona (criar um funcionário de teste pelo Admin) e força a tela de completar perfil
- [ ] Logout funciona
- [ ] Recuperação de senha gera o link (verificar `error_log` do servidor caso o e-mail não chegue, já que `mail()` em hospedagem gratuita pode ser limitado)

## Permissões
- [ ] Funcionário não consegue acessar `/admin/*` (deve receber 403)
- [ ] Admin não consegue acessar `/mestre/*` (deve receber 403)
- [ ] Empresa A não visualiza dados da Empresa B em nenhuma tela

## Estoque
- [ ] Entrada de estoque atualiza a quantidade e gera histórico
- [ ] Saída manual (ajuste/perda/avaria) atualiza e gera histórico
- [ ] Histórico exibe corretamente quantidade anterior/movimentada/posterior
- [ ] Baixa automática por venda funciona e aparece no histórico com o motivo "venda"

## Vendas
- [ ] Criar venda, adicionar produtos por código, calcular total
- [ ] Pagamento único fecha a venda corretamente
- [ ] Pagamento combinado (duas ou mais formas) fecha corretamente e rejeita valores que não somam o total
- [ ] Finalizar dá baixa no estoque
- [ ] Cancelar uma venda finalizada estorna o estoque
- [ ] Comprovante é gerado e imprime corretamente

## Financeiro
- [ ] Entradas e saídas manuais aparecem no fluxo de caixa
- [ ] Vendas finalizadas geram entrada financeira automaticamente
- [ ] Saldo do período está correto

## Funcionários
- [ ] Cadastro pelo admin funciona
- [ ] Primeiro acesso força completar perfil (nome, foto, cargo, telefone)
- [ ] Feedback pode ser registrado e visualizado pelo funcionário

## Jornada
- [ ] Iniciar/encerrar sessão de serviço funciona (admin e funcionário)
- [ ] Cálculo de horas trabalhadas está correto
- [ ] Alerta de abaixo da meta aparece quando aplicável

## Comunicação
- [ ] Chat: funcionário só vê administradores da própria empresa como contato
- [ ] Chat: admin vê outros admins/funcionários da própria empresa + Mestre
- [ ] Chat: Mestre vê todos os admins/funcionários
- [ ] Notificações aparecem no sino e podem ser marcadas como lidas
- [ ] Lembretes podem ser criados e concluídos

## Empresa
- [ ] Personalização de cores/logo reflete no painel do admin/funcionário
- [ ] Congelamento bloqueia o acesso e mostra a mensagem configurada
- [ ] Reativação libera o acesso imediatamente

## Backup
- [ ] Backup da empresa é gerado e contém só os dados dela
- [ ] Backup global do Mestre é gerado com todas as empresas
- [ ] Downloads de backup não funcionam sem estar logado com o usuário correto

## Antes de ir para produção
- [ ] Pasta `/install` removida do servidor
- [ ] `config/database.php` com as credenciais reais (não os placeholders)
- [ ] `config/app.php`: `APP_AMBIENTE` definido como `'producao'` e `APP_URL_BASE` com o domínio real
- [ ] Senha do Login Mestre trocada em relação à senha inicial de implantação
- [ ] Nenhuma empresa ou usuário fictício de teste deixado no ambiente de produção
