<?php
/**
 * =============================================================
 * ARQUIVO: login.php
 * RESPONSABILIDADE: exibir o formulário de login e processar a
 *                    autenticação de Mestre, Administrador e
 *                    Funcionário (todos usam a mesma tela — o
 *                    tipo é descoberto pelo e-mail cadastrado).
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/app/models/Usuario.php';

// Se já existe um login ativo, não faz sentido mostrar o formulário
// de novo — manda direto para a área correspondente.
if (usuarioLogado()) {
    header('Location: /index.php');
    exit;
}

$erro = null;

// Mensagem de empresa bloqueada, definida pelo middleware Auth
// quando detecta uma empresa congelada/inativa durante a navegação.
if (!empty($_SESSION['mensagem_bloqueio'])) {
    $erro = $_SESSION['mensagem_bloqueio'];
    unset($_SESSION['mensagem_bloqueio']);
}

/**
 * BLOCO: processamento do formulário (POST)
 * O QUE FAZ: valida CSRF, aplica rate limiting por IP, verifica
 *            e-mail/senha e, se tudo estiver correto, inicia a
 *            sessão do usuário.
 * COMO FAZ: nunca revela se o problema foi "e-mail não encontrado"
 *           ou "senha errada" — a mensagem de erro é sempre a
 *           mesma, para não ajudar um atacante a descobrir e-mails
 *           válidos cadastrados no sistema.
 * FIM DO BLOCO
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'desconhecido';

    if (loginBloqueadoPorTentativas($ip)) {
        $erro = 'Muitas tentativas de login. Aguarde alguns minutos antes de tentar novamente.';
    } else {
        $email = limparEntrada($_POST['email'] ?? '');
        $senha = (string) ($_POST['senha'] ?? '');

        $usuario = Usuario::buscarPorEmail($email);

        // A ordem importa: só chamamos password_verify() se o usuário
        // existir, mas a MENSAGEM de erro final é idêntica nos dois
        // casos (usuário inexistente ou senha errada).
        if ($usuario && $usuario['status'] === 'ativo' && password_verify($senha, $usuario['senha_hash'])) {
            limparTentativasLogin($ip);
            iniciarLogin($usuario);

            Auditoria::registrar('login', 'usuarios', (int) $usuario['id']);

            header('Location: /index.php');
            exit;
        }

        registrarTentativaLogin($ip);
        $erro = 'E-mail ou senha inválidos.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login — <?= escapar(APP_NOME) ?></title>
    <link rel="icon" type="image/png" href="/assets/img/empresa.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
</head>
<body class="pagina-login">

    <main class="cartao-login">
        <img src="/assets/img/empresa.png" alt="<?= escapar(APP_NOME) ?>" class="cartao-login__logo">
        <h1 class="cartao-login__titulo"><?= escapar(APP_NOME) ?></h1>
        <p class="cartao-login__subtitulo">Acesse sua conta</p>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/login.php" class="formulario-login">
            <?= csrfCampoOculto() ?>

            <label for="email">Usuário</label>
            <input type="text" id="email" name="email" required autofocus>

            <label for="senha">Senha</label>
            <input type="password" id="senha" name="senha" required>

            <button type="submit" class="botao botao--primario">Entrar</button>
        </form>

        <a href="/recuperar-senha.php" class="link-secundario">Esqueci minha senha</a>
    </main>

</body>
</html>
