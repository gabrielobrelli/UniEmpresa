<?php
/**
 * =============================================================
 * ARQUIVO: 404.php
 * RESPONSABILIDADE: página de erro exibida quando a URL acessada
 *                    não existe no sistema. Configurada como
 *                    ErrorDocument 404 no .htaccess da raiz.
 *
 * Esta página é intencionalmente simples e não exige login — uma
 * URL quebrada pode ser acessada por qualquer pessoa, logada ou não.
 * =============================================================
 */

require_once __DIR__ . '/config/app.php';

http_response_code(404);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página não encontrada — <?= htmlspecialchars(APP_NOME, ENT_QUOTES, 'UTF-8') ?></title>
    <link rel="icon" type="image/png" href="/assets/img/empresa.png">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
    <style>
        .pagina-erro__codigo {
            font-size: 72px;
            font-weight: 800;
            color: var(--primary-color);
            margin: 0;
            line-height: 1;
        }
        .pagina-erro__imagem {
            max-width: 180px;
            margin: 16px auto;
            display: block;
        }
    </style>
</head>
<body class="pagina-login">
    <main class="cartao-login" style="text-align:center; max-width: 420px;">
        <p class="pagina-erro__codigo">404</p>
        <img src="/assets/img/nadaencontrado.png" alt="" class="pagina-erro__imagem"
             onerror="this.style.display='none'">
        <h1 class="cartao-login__titulo" style="font-size:20px;">Página não encontrada</h1>
        <p class="cartao-login__subtitulo">
            O endereço acessado não existe ou foi movido. Confira o link ou volte para o início.
        </p>
        <a href="/index.php" class="botao botao--primario" style="display:inline-block; margin-top:8px;">
            Voltar para o início
        </a>
    </main>
</body>
</html>
