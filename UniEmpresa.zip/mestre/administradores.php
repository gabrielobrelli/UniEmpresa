<?php
/**
 * =============================================================
 * ARQUIVO: mestre/administradores.php
 * RESPONSABILIDADE: o Mestre visualiza todos os administradores
 *                    cadastrados em todas as empresas da plataforma,
 *                    com um atalho para a empresa de cada um.
 *
 * Este arquivo estava referenciado no menu lateral, mas nunca havia
 * sido criado — é por isso que o link dava 404.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_MESTRE);

$busca = limparEntrada($_GET['busca'] ?? '');

$pdo = getPDO();
$sql = "SELECT u.id, u.nome, u.email, u.telefone, u.status, u.created_at,
               e.id AS empresa_id, e.nome_fantasia AS empresa_nome
        FROM usuarios u
        JOIN empresas e ON e.id = u.empresa_id
        WHERE u.tipo = 'admin' AND u.deleted_at IS NULL";
$parametros = [];

if ($busca !== '') {
    $sql .= ' AND (u.nome LIKE :busca OR u.email LIKE :busca OR e.nome_fantasia LIKE :busca)';
    $parametros[':busca'] = '%' . $busca . '%';
}

$sql .= ' ORDER BY e.nome_fantasia ASC, u.nome ASC';

$stmt = $pdo->prepare($sql);
$stmt->execute($parametros);
$administradores = $stmt->fetchAll();

// Conta quantas empresas existem no total — usado para diferenciar
// "nenhuma empresa cadastrada ainda" de "nenhum admin bate com a busca".
$totalEmpresas = (int) $pdo->query('SELECT COUNT(*) AS total FROM empresas WHERE deleted_at IS NULL')->fetch()['total'];

$tituloPagina = 'Administradores';
$itemMenuAtivo = 'administradores';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="barra-filtros" style="margin-bottom: 20px;">
    <form method="GET" action="/mestre/administradores.php" class="barra-filtros" style="flex: 1 1 260px;">
        <input type="text" name="busca" placeholder="Buscar por nome, e-mail ou empresa"
               value="<?= escapar($busca) ?>" class="barra-filtros__busca">
        <button type="submit" class="botao botao--primario">Buscar</button>
    </form>
</div>

<?php if (empty($administradores)): ?>
    <?php
    $mensagemVazia = $totalEmpresas === 0
        ? 'Nenhuma empresa cadastrada ainda. Cadastre uma empresa e seu primeiro administrador para começar.'
        : 'Nenhum administrador encontrado para essa busca.';
    require __DIR__ . '/../app/views/estado-vazio.php';
    ?>
    <?php if ($totalEmpresas === 0): ?>
        <div style="text-align:center; margin-top:16px;">
            <a href="/mestre/empresa-form.php" class="botao botao--primario">+ Cadastrar primeira empresa</a>
        </div>
    <?php endif; ?>
<?php else: ?>
    <table class="tabela-padrao">
        <thead>
            <tr><th>Nome</th><th>E-mail</th><th>Empresa</th><th>Status</th><th>Cadastrado em</th><th>Ações</th></tr>
        </thead>
        <tbody>
            <?php foreach ($administradores as $admin): ?>
                <tr>
                    <td><?= escapar($admin['nome']) ?></td>
                    <td><?= escapar($admin['email']) ?></td>
                    <td><a href="/mestre/empresa-detalhe.php?id=<?= (int) $admin['empresa_id'] ?>"><?= escapar($admin['empresa_nome']) ?></a></td>
                    <td><?= $admin['status'] === 'ativo' ? '<span class="badge badge--verde">Ativo</span>' : '<span class="badge badge--cinza">Inativo</span>' ?></td>
                    <td><?= formatarData($admin['created_at']) ?></td>
                    <td><a href="/mestre/administrador-form.php?empresa_id=<?= (int) $admin['empresa_id'] ?>">+ Novo nesta empresa</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
