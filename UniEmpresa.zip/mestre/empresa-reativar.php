<?php
/**
 * =============================================================
 * ARQUIVO: mestre/empresa-reativar.php
 * RESPONSABILIDADE: processar a reativação de uma empresa
 *                    previamente congelada.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';

Auth::exigirTipo(TIPO_MESTRE);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /mestre/empresas.php');
    exit;
}

csrfValidarOuFalhar();

$empresaId = (int) ($_POST['empresa_id'] ?? 0);
$empresa = Empresa::buscarPorId($empresaId);

if (!$empresa) {
    http_response_code(404);
    die('Empresa não encontrada.');
}

Empresa::reativar($empresaId);
Auditoria::registrar('empresa_reativada', 'empresas', $empresaId);

header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId);
exit;
