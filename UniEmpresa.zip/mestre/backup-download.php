<?php
/**
 * =============================================================
 * ARQUIVO: mestre/backup-download.php
 * RESPONSABILIDADE: liberar o download de um backup global,
 *                    acessível exclusivamente ao Login Mestre.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_MESTRE);

$nomeArquivo = basename($_GET['arquivo'] ?? '');

if ($nomeArquivo === '' || str_contains($nomeArquivo, '/') || str_contains($nomeArquivo, '\\')) {
    http_response_code(400);
    die('Arquivo inválido.');
}

$caminhoCompleto = __DIR__ . '/../storage/backups/global/' . $nomeArquivo;

if (!is_file($caminhoCompleto)) {
    http_response_code(404);
    die('Backup não encontrado.');
}

Auditoria::registrar('backup_global_baixado', null, null, null, ['arquivo' => $nomeArquivo]);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $nomeArquivo . '"');
header('Content-Length: ' . filesize($caminhoCompleto));
readfile($caminhoCompleto);
exit;
