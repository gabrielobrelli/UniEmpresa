<?php
/**
 * =============================================================
 * ARQUIVO: mestre/empresa-congelar.php
 * RESPONSABILIDADE: processar o congelamento de uma empresa.
 *                    Não gera HTML — apenas processa o POST e
 *                    redireciona de volta para o detalhe da empresa.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';
require_once __DIR__ . '/../app/models/Usuario.php';
require_once __DIR__ . '/../app/models/Notificacao.php';

Auth::exigirTipo(TIPO_MESTRE);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /mestre/empresas.php');
    exit;
}

csrfValidarOuFalhar();

$empresaId = (int) ($_POST['empresa_id'] ?? 0);
$motivo = limparEntrada($_POST['motivo'] ?? '');
$mensagem = limparEntrada($_POST['mensagem'] ?? '');

$empresa = Empresa::buscarPorId($empresaId);
if (!$empresa) {
    http_response_code(404);
    die('Empresa não encontrada.');
}

if ($motivo === '' || $mensagem === '') {
    header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId . '&erro=campos_obrigatorios');
    exit;
}

// A ação em si é feita dentro de uma transação simples: o congelamento
// grava vários campos relacionados (status, motivo, mensagem,
// responsável, data) que devem ser vistos como uma única operação.
$pdo = getPDO();
$pdo->beginTransaction();

try {
    Empresa::congelar($empresaId, $motivo, $mensagem, usuarioId());

    // Avisa todos os administradores da empresa através do sistema de
    // notificações — além da mensagem que aparece ao tentar logar.
    foreach (Usuario::listarPorEmpresaETipo($empresaId, TIPO_ADMIN) as $admin) {
        Notificacao::criar($empresaId, (int) $admin['id'], 'conta_congelada', 'vermelho', 'Conta congelada', $mensagem);
    }

    Auditoria::registrar('empresa_congelada', 'empresas', $empresaId, null, [
        'motivo' => $motivo,
        'mensagem' => $mensagem,
    ]);

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    error_log('[empresa-congelar] falha: ' . $e->getMessage());
    header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId . '&erro=falha_interna');
    exit;
}

header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId);
exit;
