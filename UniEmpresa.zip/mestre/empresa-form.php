<?php
/**
 * =============================================================
 * ARQUIVO: mestre/empresa-form.php
 * RESPONSABILIDADE: uma única tela que serve tanto para CRIAR
 *                    quanto para EDITAR uma empresa — se a URL
 *                    trouxer ?id=, carrega os dados existentes
 *                    para edição; caso contrário, é um cadastro novo.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';

Auth::exigirTipo(TIPO_MESTRE);

$empresaId = isset($_GET['id']) ? (int) $_GET['id'] : null;
$empresa = $empresaId ? Empresa::buscarPorId($empresaId) : null;

if ($empresaId && !$empresa) {
    http_response_code(404);
    die('Empresa não encontrada.');
}

$erro = null;

/**
 * BLOCO: processamento do formulário (POST)
 * O QUE FAZ: valida os campos obrigatórios e cria ou atualiza a
 *            empresa, tratando também o upload opcional do logo.
 * FIM DO BLOCO
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $dados = [
        'razao_social' => limparEntrada($_POST['razao_social'] ?? ''),
        'nome_fantasia' => limparEntrada($_POST['nome_fantasia'] ?? ''),
        'cpf_cnpj' => limparEntrada($_POST['cpf_cnpj'] ?? ''),
        'segmento' => limparEntrada($_POST['segmento'] ?? ''),
        'telefone' => limparEntrada($_POST['telefone'] ?? ''),
        'whatsapp' => limparEntrada($_POST['whatsapp'] ?? ''),
        'email' => limparEntrada($_POST['email'] ?? ''),
        'endereco' => limparEntrada($_POST['endereco'] ?? ''),
        'cidade' => limparEntrada($_POST['cidade'] ?? ''),
        'estado' => strtoupper(limparEntrada($_POST['estado'] ?? '')),
        'cep' => limparEntrada($_POST['cep'] ?? ''),
        'observacoes' => limparEntrada($_POST['observacoes'] ?? ''),
    ];

    if ($dados['razao_social'] === '' || $dados['nome_fantasia'] === '') {
        $erro = 'Razão social e nome fantasia são obrigatórios.';
    } else {
        try {
            if ($empresaId) {
                Empresa::atualizar($empresaId, $dados);
                Auditoria::registrar('empresa_atualizada', 'empresas', $empresaId, null, $dados);
            } else {
                $empresaId = Empresa::criar($dados);
                Auditoria::registrar('empresa_criada', 'empresas', $empresaId, null, $dados);
            }

            // Upload de logo é opcional e tratado separadamente do
            // restante dos dados, pois só faz sentido depois de saber
            // o ID definitivo da empresa (usado na subpasta de destino).
            if (!empty($_FILES['logo']['name'])) {
                $caminhoLogo = salvarImagemEnviada($_FILES['logo'], 'empresas/' . $empresaId);
                if ($caminhoLogo) {
                    Empresa::atualizarLogo($empresaId, $caminhoLogo);
                }
            }

            header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId);
            exit;
        } catch (RuntimeException $e) {
            $erro = $e->getMessage();
        }
    }

    // Em caso de erro, recarrega os dados digitados para não obrigar
    // o Mestre a preencher tudo de novo.
    $empresa = array_merge($empresa ?? [], $dados);
}

$tituloPagina = $empresaId ? 'Editar empresa' : 'Nova empresa';
$itemMenuAtivo = 'empresas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="/mestre/empresa-form.php<?= $empresaId ? '?id=' . $empresaId : '' ?>" enctype="multipart/form-data">
        <?= csrfCampoOculto() ?>

        <div class="linha-campos">
            <div class="campo">
                <label for="razao_social">Razão social *</label>
                <input type="text" id="razao_social" name="razao_social" required
                       value="<?= escapar($empresa['razao_social'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="nome_fantasia">Nome fantasia *</label>
                <input type="text" id="nome_fantasia" name="nome_fantasia" required
                       value="<?= escapar($empresa['nome_fantasia'] ?? '') ?>">
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="cpf_cnpj">CPF/CNPJ</label>
                <input type="text" id="cpf_cnpj" name="cpf_cnpj"
                       value="<?= escapar($empresa['cpf_cnpj'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="segmento">Segmento</label>
                <input type="text" id="segmento" name="segmento" placeholder="Ex.: Loja de roupas, Mercado, Autopeças..."
                       value="<?= escapar($empresa['segmento'] ?? '') ?>">
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone"
                       value="<?= escapar($empresa['telefone'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="whatsapp">WhatsApp</label>
                <input type="text" id="whatsapp" name="whatsapp"
                       value="<?= escapar($empresa['whatsapp'] ?? '') ?>">
            </div>
        </div>

        <div class="campo">
            <label for="email">E-mail</label>
            <input type="email" id="email" name="email" value="<?= escapar($empresa['email'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="endereco">Endereço</label>
            <input type="text" id="endereco" name="endereco" value="<?= escapar($empresa['endereco'] ?? '') ?>">
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="cidade">Cidade</label>
                <input type="text" id="cidade" name="cidade" value="<?= escapar($empresa['cidade'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="estado">UF</label>
                <input type="text" id="estado" name="estado" maxlength="2" value="<?= escapar($empresa['estado'] ?? '') ?>">
            </div>
        </div>

        <div class="campo">
            <label for="cep">CEP</label>
            <input type="text" id="cep" name="cep" value="<?= escapar($empresa['cep'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="logo">Logo (JPG, PNG ou WEBP — máx. 3MB)</label>
            <input type="file" id="logo" name="logo" accept=".jpg,.jpeg,.png,.webp">
        </div>

        <div class="campo">
            <label for="observacoes">Observações</label>
            <textarea id="observacoes" name="observacoes" rows="3"><?= escapar($empresa['observacoes'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="botao botao--primario"><?= $empresaId ? 'Salvar alterações' : 'Cadastrar empresa' ?></button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
