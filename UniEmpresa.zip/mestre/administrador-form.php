<?php
/**
 * =============================================================
 * ARQUIVO: mestre/administrador-form.php
 * RESPONSABILIDADE: o Mestre cria um novo Administrador para uma
 *                    empresa específica (seção 10 do documento).
 *                    Uma empresa pode ter vários administradores.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_MESTRE);

$empresaId = (int) ($_GET['empresa_id'] ?? $_POST['empresa_id'] ?? 0);
$empresa = Empresa::buscarPorId($empresaId);

if (!$empresa) {
    http_response_code(404);
    die('Empresa não encontrada.');
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $nome = limparEntrada($_POST['nome'] ?? '');
    $email = limparEntrada($_POST['email'] ?? '');
    $senha = (string) ($_POST['senha'] ?? '');
    $confirmacao = (string) ($_POST['confirmacao'] ?? '');
    $telefone = limparEntrada($_POST['telefone'] ?? '');
    $cargo = limparEntrada($_POST['cargo'] ?? '');

    if ($nome === '' || $email === '') {
        $erro = 'Nome e e-mail são obrigatórios.';
    } elseif (strlen($senha) < 8) {
        $erro = 'A senha deve ter pelo menos 8 caracteres.';
    } elseif ($senha !== $confirmacao) {
        $erro = 'A confirmação de senha não confere.';
    } elseif (Usuario::buscarPorEmail($email)) {
        $erro = 'Já existe um usuário cadastrado com este e-mail.';
    } else {
        $novoId = Usuario::criar([
            'empresa_id' => $empresaId,
            'tipo' => TIPO_ADMIN,
            'nome' => $nome,
            'email' => $email,
            'senha' => $senha,
            'telefone' => $telefone,
            'cargo' => $cargo,
            'perfil_completo' => 1,
        ]);

        Auditoria::registrar('administrador_criado', 'usuarios', $novoId, null, [
            'empresa_id' => $empresaId,
            'email' => $email,
        ]);

        header('Location: /mestre/empresa-detalhe.php?id=' . $empresaId);
        exit;
    }
}

$tituloPagina = 'Novo administrador';
$itemMenuAtivo = 'empresas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario">
    <p style="margin-top:0; color: var(--cor-texto-suave);">
        Empresa: <strong><?= escapar($empresa['nome_fantasia']) ?></strong>
    </p>

    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="/mestre/administrador-form.php">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="empresa_id" value="<?= $empresaId ?>">

        <div class="campo">
            <label for="nome">Nome completo *</label>
            <input type="text" id="nome" name="nome" required value="<?= escapar($_POST['nome'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="email">Usuário de acesso *</label>
            <input type="text" id="email" name="email" required value="<?= escapar($_POST['email'] ?? '') ?>">
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="senha">Senha inicial *</label>
                <input type="password" id="senha" name="senha" minlength="8" required>
            </div>
            <div class="campo">
                <label for="confirmacao">Confirme a senha *</label>
                <input type="password" id="confirmacao" name="confirmacao" minlength="8" required>
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone" value="<?= escapar($_POST['telefone'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="cargo">Cargo</label>
                <input type="text" id="cargo" name="cargo" value="<?= escapar($_POST['cargo'] ?? '') ?>">
            </div>
        </div>

        <button type="submit" class="botao botao--primario">Cadastrar administrador</button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
