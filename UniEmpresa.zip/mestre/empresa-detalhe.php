<?php
/**
 * =============================================================
 * ARQUIVO: mestre/empresa-detalhe.php
 * RESPONSABILIDADE: tela central de gestão de UMA empresa pelo
 *                    Mestre — mostra dados cadastrais, lista de
 *                    administradores, contagem de funcionários e
 *                    os controles de congelamento/reativação
 *                    (seção 9 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_MESTRE);

$empresaId = (int) ($_GET['id'] ?? 0);
$empresa = Empresa::buscarPorId($empresaId);

if (!$empresa) {
    http_response_code(404);
    die('Empresa não encontrada.');
}

$administradores = Usuario::listarPorEmpresaETipo($empresaId, TIPO_ADMIN);
$contagemUsuarios = Empresa::contarUsuariosPorTipo($empresaId);

$tituloPagina = $empresa['nome_fantasia'];
$itemMenuAtivo = 'empresas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; justify-content: space-between; align-items: flex-start; margin-bottom: 20px;">
    <div>
        <p style="margin:0;"><strong>Razão social:</strong> <?= escapar($empresa['razao_social']) ?></p>
        <p style="margin:0;"><strong>Segmento:</strong> <?= escapar($empresa['segmento'] ?? '—') ?></p>
        <p style="margin:0;"><strong>Cidade/UF:</strong> <?= escapar(($empresa['cidade'] ?? '—') . '/' . ($empresa['estado'] ?? '')) ?></p>
        <p style="margin:0;">
            <strong>Status:</strong>
            <?php if ($empresa['status'] === 'ativa'): ?>
                <span class="badge badge--verde">Ativa</span>
            <?php elseif ($empresa['status'] === 'congelada'): ?>
                <span class="badge badge--amarelo">Congelada</span>
            <?php else: ?>
                <span class="badge badge--vermelho">Inativa</span>
            <?php endif; ?>
        </p>
        <?php if ($empresa['status'] === 'congelada'): ?>
            <p style="margin:8px 0 0; color:var(--cor-texto-suave);">
                <strong>Motivo:</strong> <?= escapar($empresa['motivo_congelamento'] ?? '—') ?><br>
                <strong>Mensagem exibida:</strong> <?= escapar($empresa['mensagem_congelamento'] ?? '—') ?><br>
                <strong>Congelada em:</strong> <?= formatarData($empresa['congelada_em'], true) ?>
            </p>
        <?php endif; ?>
    </div>
    <a href="/mestre/empresa-form.php?id=<?= $empresaId ?>" class="botao botao--primario">Editar dados</a>
</div>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Administradores</div>
        <div class="card-indicador__valor"><?= (int) $contagemUsuarios['admin'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Funcionários</div>
        <div class="card-indicador__valor"><?= (int) $contagemUsuarios['funcionario'] ?></div>
    </div>
</div>

<div style="display:flex; gap: 24px; flex-wrap: wrap;">

    <!-- Bloco: controle de status da empresa -->
    <div class="cartao-formulario" style="flex: 1; min-width: 300px;">
        <h3 style="margin-top:0;">Controle de acesso</h3>

        <?php if ($empresa['status'] === 'congelada'): ?>
            <form method="POST" action="/mestre/empresa-reativar.php">
                <?= csrfCampoOculto() ?>
                <input type="hidden" name="empresa_id" value="<?= $empresaId ?>">
                <p>Esta empresa está congelada. Os dados continuam preservados; o acesso está bloqueado.</p>
                <button type="submit" class="botao botao--primario">Reativar empresa</button>
            </form>
        <?php else: ?>
            <form method="POST" action="/mestre/empresa-congelar.php">
                <?= csrfCampoOculto() ?>
                <input type="hidden" name="empresa_id" value="<?= $empresaId ?>">

                <div class="campo">
                    <label for="motivo">Motivo do congelamento</label>
                    <input type="text" id="motivo" name="motivo" placeholder="Ex.: Atraso de pagamento" required>
                </div>
                <div class="campo">
                    <label for="mensagem">Mensagem exibida aos administradores</label>
                    <textarea id="mensagem" name="mensagem" rows="3" required
                        placeholder="Ex.: Login congelado por atraso de pagamento. Realize o pagamento para a reativação da conta."></textarea>
                </div>
                <button type="submit" class="botao botao--primario">Congelar empresa</button>
            </form>
        <?php endif; ?>
    </div>

    <!-- Bloco: administradores da empresa -->
    <div class="cartao-formulario" style="flex: 1; min-width: 300px;">
        <h3 style="margin-top:0;">Administradores</h3>

        <table class="tabela-padrao">
            <thead>
                <tr><th>Nome</th><th>E-mail</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($administradores as $admin): ?>
                    <tr>
                        <td><?= escapar($admin['nome']) ?></td>
                        <td><?= escapar($admin['email']) ?></td>
                        <td><?= $admin['status'] === 'ativo' ? '<span class="badge badge--verde">Ativo</span>' : '<span class="badge badge--cinza">Inativo</span>' ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($administradores)): ?>
                    <tr><td colspan="3">Nenhum administrador cadastrado ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <a href="/mestre/administrador-form.php?empresa_id=<?= $empresaId ?>" class="botao botao--primario" style="margin-top:16px; display:inline-block;">
            + Novo administrador
        </a>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
