<?php
/**
 * =============================================================
 * ARQUIVO: mestre/notificacoes.php
 * RESPONSABILIDADE: histórico completo de notificações do Mestre
 *                    — o sino no topo mostra as mais recentes, esta
 *                    tela mostra o histórico com opção de marcar
 *                    tudo como lido de uma vez (seção 42).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Notificacao.php';

Auth::exigirTipo(TIPO_MESTRE);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();
    if (($_POST['acao'] ?? '') === 'marcar_todas') {
        Notificacao::marcarTodasComoLidas(usuarioId());
    }
    header('Location: /mestre/notificacoes.php');
    exit;
}

$notificacoes = Notificacao::listarDoUsuario(usuarioId(), 100);
$iconePorPrioridade = ['verde' => 'ℹ️', 'amarelo' => '⚠️', 'vermelho' => '🔴'];

$tituloPagina = 'Notificações';
$itemMenuAtivo = 'notificacoes';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<form method="POST" action="/mestre/notificacoes.php" style="margin-bottom:16px;">
    <?= csrfCampoOculto() ?>
    <input type="hidden" name="acao" value="marcar_todas">
    <button type="submit" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Marcar tudo como lido</button>
</form>

<table class="tabela-padrao">
    <thead><tr><th></th><th>Título</th><th>Mensagem</th><th>Data</th><th>Status</th></tr></thead>
    <tbody>
        <?php foreach ($notificacoes as $n): ?>
            <tr>
                <td><?= $iconePorPrioridade[$n['prioridade']] ?? 'ℹ️' ?></td>
                <td><?= escapar($n['titulo']) ?></td>
                <td><?= escapar($n['mensagem']) ?></td>
                <td><?= formatarData($n['created_at'], true) ?></td>
                <td><?= $n['lida_em'] ? '<span class="badge badge--cinza">Lida</span>' : '<span class="badge badge--vermelho">Não lida</span>' ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($notificacoes)): ?>
            <tr><td colspan="5">Nenhuma notificação por aqui.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
