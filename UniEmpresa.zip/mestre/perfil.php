<?php
/**
 * =============================================================
 * ARQUIVO: mestre/perfil.php
 * RESPONSABILIDADE: o Mestre edita os próprios dados pessoais
 *                    (nome, e-mail de acesso, telefone, foto, bio)
 *                    e pode trocar a senha — sem precisar de acesso
 *                    ao phpMyAdmin para isso.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_MESTRE);

$resultado = processarFormularioPerfil();
$erro = $resultado['erro'];
$sucesso = $resultado['sucesso'];

$usuario = Usuario::buscarPorId(usuarioId());

$tituloPagina = 'Meu perfil';
$itemMenuAtivo = 'perfil';
require __DIR__ . '/../app/views/layout-inicio.php';
require __DIR__ . '/../app/views/perfil-corpo.php';
require __DIR__ . '/../app/views/layout-fim.php';
