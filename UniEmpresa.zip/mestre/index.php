<?php
/**
 * =============================================================
 * ARQUIVO: mestre/index.php
 * RESPONSABILIDADE: dashboard do Login Mestre — visão geral da
 *                    plataforma (seção 7 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';

Auth::exigirTipo(TIPO_MESTRE);

$pdo = getPDO();

// --- Indicadores principais -----------------------------------------
$empresasPorStatus = Empresa::contarPorStatus();
$totalEmpresas = array_sum($empresasPorStatus);

$totalAdministradores = $pdo->query(
    "SELECT COUNT(*) AS total FROM usuarios WHERE tipo = 'admin' AND deleted_at IS NULL"
)->fetch()['total'];

$totalFuncionarios = $pdo->query(
    "SELECT COUNT(*) AS total FROM usuarios WHERE tipo = 'funcionario' AND deleted_at IS NULL"
)->fetch()['total'];

// Usuário é considerado "online" se teve atividade nos últimos 5 minutos
// (ver seção 50 do documento — heartbeat aproximado via última atividade).
$totalOnline = $pdo->query(
    "SELECT COUNT(*) AS total FROM usuarios
     WHERE ultima_atividade >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) AND deleted_at IS NULL"
)->fetch()['total'];

// --- Empresas cadastradas recentemente --------------------------------
$empresasRecentes = $pdo->query(
    "SELECT id, nome_fantasia, segmento, status, created_at FROM empresas
     WHERE deleted_at IS NULL ORDER BY created_at DESC LIMIT 5"
)->fetchAll();

// --- Atividade recente (últimas ações registradas na auditoria) -------
$atividadeRecente = $pdo->query(
    "SELECT a.acao, a.created_at, u.nome AS usuario_nome, e.nome_fantasia AS empresa_nome
     FROM auditoria a
     LEFT JOIN usuarios u ON u.id = a.usuario_id
     LEFT JOIN empresas e ON e.id = a.empresa_id
     ORDER BY a.created_at DESC LIMIT 10"
)->fetchAll();

$tituloPagina = 'Dashboard';
$itemMenuAtivo = 'dashboard';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Empresas cadastradas</div>
        <div class="card-indicador__valor"><?= (int) $totalEmpresas ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Empresas ativas</div>
        <div class="card-indicador__valor"><?= (int) $empresasPorStatus['ativa'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Empresas congeladas</div>
        <div class="card-indicador__valor"><?= (int) $empresasPorStatus['congelada'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Empresas inativas</div>
        <div class="card-indicador__valor"><?= (int) $empresasPorStatus['inativa'] ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Administradores</div>
        <div class="card-indicador__valor"><?= (int) $totalAdministradores ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Funcionários</div>
        <div class="card-indicador__valor"><?= (int) $totalFuncionarios ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Usuários online agora</div>
        <div class="card-indicador__valor"><?= (int) $totalOnline ?></div>
    </div>
</div>

<h2>Empresas cadastradas recentemente</h2>
<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Empresa</th>
            <th>Segmento</th>
            <th>Status</th>
            <th>Cadastrada em</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($empresasRecentes as $empresa): ?>
            <tr>
                <td><?= escapar($empresa['nome_fantasia']) ?></td>
                <td><?= escapar($empresa['segmento'] ?? '—') ?></td>
                <td>
                    <?php if ($empresa['status'] === 'ativa'): ?>
                        <span class="badge badge--verde">Ativa</span>
                    <?php elseif ($empresa['status'] === 'congelada'): ?>
                        <span class="badge badge--amarelo">Congelada</span>
                    <?php else: ?>
                        <span class="badge badge--vermelho">Inativa</span>
                    <?php endif; ?>
                </td>
                <td><?= formatarData($empresa['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($empresasRecentes)): ?>
            <tr><td colspan="4">Nenhuma empresa cadastrada ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<h2 style="margin-top: 32px;">Atividade recente</h2>
<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Ação</th>
            <th>Usuário</th>
            <th>Empresa</th>
            <th>Data/hora</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($atividadeRecente as $log): ?>
            <tr>
                <td><?= escapar($log['acao']) ?></td>
                <td><?= escapar($log['usuario_nome'] ?? '—') ?></td>
                <td><?= escapar($log['empresa_nome'] ?? '—') ?></td>
                <td><?= formatarData($log['created_at'], true) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($atividadeRecente)): ?>
            <tr><td colspan="4">Nenhuma atividade registrada ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
