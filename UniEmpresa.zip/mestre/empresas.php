<?php
/**
 * =============================================================
 * ARQUIVO: mestre/empresas.php
 * RESPONSABILIDADE: listar todas as empresas da plataforma, com
 *                    busca por nome/CNPJ, e links para as ações
 *                    de cadastrar, editar, congelar/reativar e
 *                    ver detalhes de cada uma.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';

Auth::exigirTipo(TIPO_MESTRE);

$busca = limparEntrada($_GET['busca'] ?? '');
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));

$empresas = Empresa::listarTodas($busca, $pagina);

$tituloPagina = 'Empresas';
$itemMenuAtivo = 'empresas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="barra-filtros" style="justify-content: space-between; margin-bottom: 20px;">
    <form method="GET" action="/mestre/empresas.php" class="barra-filtros" style="flex: 1 1 260px;">
        <input type="text" name="busca" placeholder="Buscar por nome ou CNPJ/CPF"
               value="<?= escapar($busca) ?>" class="barra-filtros__busca">
        <button type="submit" class="botao botao--primario">Buscar</button>
    </form>

    <a href="/mestre/empresa-form.php" class="botao botao--primario">+ Nova empresa</a>
</div>

<?php if (empty($empresas)): ?>
    <?php $mensagemVazia = $busca ? 'Nenhuma empresa encontrada para essa busca.' : 'Nenhuma empresa cadastrada ainda. Clique em "+ Nova empresa" para começar.'; ?>
    <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
<?php else: ?>
<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Empresa</th>
            <th>Segmento</th>
            <th>Cidade/UF</th>
            <th>Status</th>
            <th>Cadastrada em</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($empresas as $empresa): ?>
            <tr>
                <td><?= escapar($empresa['nome_fantasia']) ?></td>
                <td><?= escapar($empresa['segmento'] ?? '—') ?></td>
                <td><?= escapar(($empresa['cidade'] ?? '—') . '/' . ($empresa['estado'] ?? '')) ?></td>
                <td>
                    <?php if ($empresa['status'] === 'ativa'): ?>
                        <span class="badge badge--verde">Ativa</span>
                    <?php elseif ($empresa['status'] === 'congelada'): ?>
                        <span class="badge badge--amarelo">Congelada</span>
                    <?php else: ?>
                        <span class="badge badge--vermelho">Inativa</span>
                    <?php endif; ?>
                </td>
                <td><?= formatarData($empresa['created_at']) ?></td>
                <td>
                    <a href="/mestre/empresa-detalhe.php?id=<?= (int) $empresa['id'] ?>">Ver</a>
                    &nbsp;|&nbsp;
                    <a href="/mestre/empresa-form.php?id=<?= (int) $empresa['id'] ?>">Editar</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
