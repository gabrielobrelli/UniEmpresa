<?php
/**
 * =============================================================
 * ARQUIVO: mestre/backup.php
 * RESPONSABILIDADE: backup GLOBAL da plataforma (seção 54) —
 *                    diferente do backup do admin, este inclui:
 *                      1) TODOS os arquivos e pastas do projeto,
 *                         exatamente como estão hoje no htdocs
 *                         (código-fonte completo, para reconstruir
 *                         o site do zero se precisar);
 *                      2) o banco de dados COMPLETO (todas as
 *                         empresas, todas as tabelas) em SQL.
 *                    Acessível apenas ao Login Mestre. Nunca inclui
 *                    senha em texto puro (só hashes) — e o próprio
 *                    arquivo de backup gerado fica de fora do zip,
 *                    para não crescer indefinidamente a cada backup.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_MESTRE);

$pastaBackups = __DIR__ . '/../storage/backups/global';
$avisoZip = null;

/**
 * FUNÇÃO: todasAsTabelas()
 * O QUE FAZ: lista todas as tabelas de dados do sistema, na ordem
 *            segura para reimportação (respeitando dependências de
 *            chave estrangeira: tabelas "pai" antes das "filhas").
 * FIM DA FUNÇÃO
 */
function todasAsTabelas(): array
{
    return [
        'empresas', 'usuarios', 'tokens_recuperacao',
        'categorias', 'unidades_medida', 'fornecedores', 'produtos', 'movimentacoes_estoque',
        'clientes', 'vendas', 'venda_itens', 'venda_pagamentos', 'venda_devolucoes',
        'movimentacoes_financeiras', 'jornadas',
        'conversas', 'mensagens', 'notificacoes', 'lembretes', 'feedbacks',
        'auditoria', 'configuracoes_empresa',
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'gerar') {
    csrfValidarOuFalhar();

    if (!is_dir($pastaBackups)) {
        mkdir($pastaBackups, 0755, true);
    }

    $pdo = getPDO();

    // --- 1) Dump completo do banco de dados (todas as tabelas) ---------
    $dumpCompleto = "-- Backup completo do banco de dados — " . date('d/m/Y H:i:s') . "\n"
        . "-- Gerado pelo Login Mestre em " . APP_URL_BASE . "\n\n"
        . file_get_contents(__DIR__ . '/../database/schema.sql') . "\n\n";

    foreach (todasAsTabelas() as $tabela) {
        $dumpCompleto .= dumpTabelaComoSql($pdo, $tabela, null);
    }

    $nomeBase = 'backup_global_' . date('Y-m-d_His');
    $caminhoSql = $pastaBackups . '/' . $nomeBase . '_banco.sql';
    file_put_contents($caminhoSql, $dumpCompleto);

    // --- 2) Zip com TODO o diretório do projeto (código-fonte completo) -
    // Sempre exclui a própria pasta de backups (para não incluir
    // backups anteriores dentro do novo) e a pasta de uploads de
    // usuários só se for muito grande — aqui incluímos tudo, já que o
    // objetivo é reconstruir o site inteiro em caso de necessidade.
    $caminhoZipArquivos = $pastaBackups . '/' . $nomeBase . '_arquivos.zip';
    $resultadoZip = zipDiretorioCompleto(
        __DIR__ . '/..',
        $caminhoZipArquivos,
        ['storage/backups']
    );

    if ($resultadoZip === null) {
        $avisoZip = 'A extensão ZipArchive não está disponível neste servidor — apenas o banco de dados (.sql) foi gerado desta vez. Os arquivos do sistema continuam disponíveis normalmente no seu gerenciador de arquivos/FTP.';
    } else {
        // Junta banco + arquivos em um único .zip final, para o Mestre
        // baixar um pacote só em vez de dois arquivos separados.
        $caminhoZipFinal = $pastaBackups . '/' . $nomeBase . '.zip';
        $zipFinal = new ZipArchive();
        $zipFinal->open($caminhoZipFinal, ZipArchive::CREATE | ZipArchive::OVERWRITE);
        $zipFinal->addFile($caminhoSql, 'banco-de-dados.sql');

        // Copia cada entrada do zip de arquivos para dentro do zip final.
        $zipArquivos = new ZipArchive();
        $zipArquivos->open($caminhoZipArquivos);
        for ($i = 0; $i < $zipArquivos->numFiles; $i++) {
            $nomeEntrada = $zipArquivos->getNameIndex($i);
            $zipFinal->addFromString('sistema/' . $nomeEntrada, $zipArquivos->getFromIndex($i));
        }
        $zipArquivos->close();
        $zipFinal->close();

        // Remove os arquivos intermediários — só o pacote final fica salvo.
        unlink($caminhoSql);
        unlink($caminhoZipArquivos);
    }

    Auditoria::registrar('backup_global_gerado', null, null, null, ['nome_base' => $nomeBase]);
}

$backupsExistentes = [];
if (is_dir($pastaBackups)) {
    foreach (scandir($pastaBackups, SCANDIR_SORT_DESCENDING) as $arquivo) {
        if ($arquivo !== '.' && $arquivo !== '..') {
            $backupsExistentes[] = $arquivo;
        }
    }
}

$tituloPagina = 'Backup global';
$itemMenuAtivo = 'backup';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario" style="margin-bottom:24px;">
    <p>
        Gera um pacote com o <strong>sistema completo</strong> (todos os arquivos do projeto, exatamente
        como estão hoje no servidor) e o <strong>banco de dados inteiro</strong> (todas as empresas).
        Este arquivo é sensível — mantenha-o em local seguro e não o compartilhe publicamente.
    </p>
    <form method="POST" action="/mestre/backup.php">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="acao" value="gerar">
        <button type="submit" class="botao botao--primario">Gerar backup global</button>
    </form>
    <p style="font-size:12.5px; color:var(--cor-texto-suave); margin-top:10px; margin-bottom:0;">
        Pode levar alguns segundos a mais que o backup de uma única empresa — o pacote inclui todo o código-fonte.
    </p>
</div>

<?php if ($avisoZip): ?>
    <div class="alerta alerta--info"><?= escapar($avisoZip) ?></div>
<?php endif; ?>

<table class="tabela-padrao">
    <thead><tr><th>Arquivo</th><th>Ações</th></tr></thead>
    <tbody>
        <?php foreach ($backupsExistentes as $arquivo): ?>
            <tr>
                <td><?= escapar($arquivo) ?></td>
                <td><a href="/mestre/backup-download.php?arquivo=<?= urlencode($arquivo) ?>">Baixar</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($backupsExistentes)): ?>
            <tr><td colspan="2">Nenhum backup global gerado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
