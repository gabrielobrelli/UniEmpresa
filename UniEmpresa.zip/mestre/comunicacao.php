<?php
/**
 * =============================================================
 * ARQUIVO: mestre/comunicacao.php
 * RESPONSABILIDADE: tela de chat do Login Mestre — reaproveita o
 *                    corpo compartilhado em app/views/comunicacao-corpo.php.
 *                    O Mestre pode conversar com qualquer admin ou
 *                    funcionário de qualquer empresa (seção 40).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_MESTRE);

$tituloPagina = 'Chat';
$itemMenuAtivo = 'chat';
require __DIR__ . '/../app/views/layout-inicio.php';
require __DIR__ . '/../app/views/comunicacao-corpo.php';
require __DIR__ . '/../app/views/layout-fim.php';
