<?php
/**
 * =============================================================
 * ARQUIVO: logout.php
 * RESPONSABILIDADE: encerrar a sessão do usuário de forma segura
 *                    e devolvê-lo para a tela de login.
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';

// Registra o logout na auditoria antes de destruir a sessão,
// já que depois de encerrarSessao() não teríamos mais o usuario_id.
if (usuarioLogado()) {
    Auditoria::registrar('logout', 'usuarios', usuarioId());
}

encerrarSessao();

header('Location: /login.php');
exit;
