<?php
/**
 * =============================================================
 * ARQUIVO: bootstrap.php
 * RESPONSABILIDADE: ponto único de inicialização do sistema.
 *
 * Todo arquivo de entrada (login.php, index.php, páginas de
 * admin/mestre/funcionario, endpoints de api/) deve começar com:
 *
 *     require_once __DIR__ . '/bootstrap.php';
 *
 * Isso garante que configurações, helpers e sessão estejam
 * sempre disponíveis, na ordem certa, sem repetir includes em
 * cada arquivo.
 * =============================================================
 */

// --- Configurações base -------------------------------------------------
require_once __DIR__ . '/config/app.php';        // timezone, moeda, sessão
require_once __DIR__ . '/config/constants.php';  // constantes de tipos/status
require_once __DIR__ . '/config/database.php';   // conexão PDO (getPDO())

// --- Helpers reutilizáveis -----------------------------------------------
require_once __DIR__ . '/app/helpers/sessao.php';
require_once __DIR__ . '/app/helpers/csrf.php';
require_once __DIR__ . '/app/helpers/seguranca.php';
require_once __DIR__ . '/app/helpers/formatacao.php';
require_once __DIR__ . '/app/helpers/upload.php';
require_once __DIR__ . '/app/helpers/periodos.php';
require_once __DIR__ . '/app/helpers/exportacao.php';
require_once __DIR__ . '/app/helpers/backup.php';
require_once __DIR__ . '/app/helpers/perfil.php';

// --- Models usados pelo próprio middleware/bootstrap ------------------------
// Precisam vir ANTES do middleware, pois Auth::exigirLogin() chama
// Usuario::atualizarUltimaAtividade() e Auditoria::registrar().
require_once __DIR__ . '/app/models/Usuario.php';
require_once __DIR__ . '/app/models/Auditoria.php';

// --- Middleware ------------------------------------------------------------
require_once __DIR__ . '/app/middleware/Auth.php';

// --- Inicialização da sessão ------------------------------------------------
iniciarSessao();
