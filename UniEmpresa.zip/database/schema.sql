-- ============================================================
-- UNIEMPRESA — SCHEMA DE BANCO DE DADOS
-- Plataforma SaaS multiempresa de gestão comercial
-- Compatível com MySQL 5.7+/8.0 (InfinityFree)
-- Charset: utf8mb4 | Engine: InnoDB
-- ============================================================

SET NAMES utf8mb4;
SET time_zone = '-03:00';

-- ============================================================
-- 1. EMPRESAS
-- ============================================================

CREATE TABLE empresas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    razao_social VARCHAR(150) NOT NULL,
    nome_fantasia VARCHAR(150) NOT NULL,
    cpf_cnpj VARCHAR(20) NULL,
    segmento VARCHAR(100) NULL,
    telefone VARCHAR(20) NULL,
    whatsapp VARCHAR(20) NULL,
    email VARCHAR(150) NULL,
    endereco VARCHAR(200) NULL,
    cidade VARCHAR(100) NULL,
    estado CHAR(2) NULL,
    cep VARCHAR(10) NULL,
    logo VARCHAR(255) NULL,
    observacoes TEXT NULL,

    status ENUM('ativa', 'congelada', 'inativa') NOT NULL DEFAULT 'ativa',
    motivo_congelamento VARCHAR(150) NULL,
    mensagem_congelamento TEXT NULL,
    congelada_por INT UNSIGNED NULL,
    congelada_em DATETIME NULL,

    cor_primaria VARCHAR(7) NOT NULL DEFAULT '#2563eb',
    cor_secundaria VARCHAR(7) NOT NULL DEFAULT '#1e293b',
    cor_destaque VARCHAR(7) NOT NULL DEFAULT '#f59e0b',

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    INDEX idx_empresas_status (status),
    INDEX idx_empresas_segmento (segmento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 2. USUÁRIOS (mestre, administrador, funcionário)
-- ============================================================

CREATE TABLE usuarios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NULL,
    tipo ENUM('mestre', 'admin', 'funcionario') NOT NULL,

    nome VARCHAR(150) NOT NULL,
    email VARCHAR(150) NOT NULL,
    senha_hash VARCHAR(255) NOT NULL,
    foto VARCHAR(255) NULL,
    telefone VARCHAR(20) NULL,
    whatsapp VARCHAR(20) NULL,
    cpf VARCHAR(20) NULL,
    cargo VARCHAR(80) NULL,

    data_admissao DATE NULL,
    meta_minutos_diarios INT UNSIGNED NULL DEFAULT 480,

    perfil_completo TINYINT(1) NOT NULL DEFAULT 0,
    status ENUM('ativo', 'inativo') NOT NULL DEFAULT 'ativo',
    observacoes TEXT NULL,

    ultima_atividade DATETIME NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    UNIQUE KEY uq_usuarios_email (email),
    INDEX idx_usuarios_empresa (empresa_id),
    INDEX idx_usuarios_tipo (tipo),
    INDEX idx_usuarios_status (status),

    CONSTRAINT fk_usuarios_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE empresas
    ADD CONSTRAINT fk_empresas_congelada_por FOREIGN KEY (congelada_por) REFERENCES usuarios(id) ON DELETE SET NULL;

-- ============================================================
-- 3. RECUPERAÇÃO DE SENHA
-- ============================================================

CREATE TABLE tokens_recuperacao (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    token_hash VARCHAR(255) NOT NULL,
    expira_em DATETIME NOT NULL,
    usado_em DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_tokens_usuario (usuario_id),
    CONSTRAINT fk_tokens_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 4. CATEGORIAS / SUBCATEGORIAS / UNIDADES / FORNECEDORES
-- ============================================================

CREATE TABLE categorias (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    categoria_pai_id INT UNSIGNED NULL,
    nome VARCHAR(100) NOT NULL,
    status ENUM('ativa', 'inativa') NOT NULL DEFAULT 'ativa',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    INDEX idx_categorias_empresa (empresa_id),
    INDEX idx_categorias_pai (categoria_pai_id),

    CONSTRAINT fk_categorias_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_categorias_pai FOREIGN KEY (categoria_pai_id) REFERENCES categorias(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE unidades_medida (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    nome VARCHAR(50) NOT NULL,
    sigla VARCHAR(10) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_unidades_empresa (empresa_id),
    CONSTRAINT fk_unidades_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE fornecedores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(20) NULL,
    email VARCHAR(150) NULL,
    observacao TEXT NULL,
    status ENUM('ativo', 'inativo') NOT NULL DEFAULT 'ativo',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    INDEX idx_fornecedores_empresa (empresa_id),
    CONSTRAINT fk_fornecedores_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 5. PRODUTOS E ESTOQUE
-- ============================================================

CREATE TABLE produtos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    categoria_id INT UNSIGNED NULL,
    unidade_id INT UNSIGNED NULL,
    fornecedor_id INT UNSIGNED NULL,

    codigo VARCHAR(50) NULL,
    codigo_barras VARCHAR(50) NULL,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT NULL,

    preco_custo DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    preco_venda DECIMAL(12,2) NOT NULL DEFAULT 0.00,

    estoque_atual DECIMAL(12,3) NOT NULL DEFAULT 0,
    estoque_minimo DECIMAL(12,3) NOT NULL DEFAULT 0,
    estoque_maximo DECIMAL(12,3) NULL,
    permite_estoque_negativo TINYINT(1) NOT NULL DEFAULT 0,

    foto VARCHAR(255) NULL,
    status ENUM('ativo', 'inativo') NOT NULL DEFAULT 'ativo',
    observacoes TEXT NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    INDEX idx_produtos_empresa (empresa_id),
    INDEX idx_produtos_categoria (categoria_id),
    INDEX idx_produtos_codigo (empresa_id, codigo),
    INDEX idx_produtos_codigo_barras (empresa_id, codigo_barras),
    INDEX idx_produtos_status (status),
    FULLTEXT INDEX ft_produtos_nome (nome),

    CONSTRAINT fk_produtos_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_produtos_categoria FOREIGN KEY (categoria_id) REFERENCES categorias(id) ON DELETE SET NULL,
    CONSTRAINT fk_produtos_unidade FOREIGN KEY (unidade_id) REFERENCES unidades_medida(id) ON DELETE SET NULL,
    CONSTRAINT fk_produtos_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE movimentacoes_estoque (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    produto_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    venda_id INT UNSIGNED NULL,

    tipo ENUM('entrada', 'saida') NOT NULL,
    motivo ENUM('compra', 'venda', 'ajuste', 'perda', 'avaria', 'uso_interno', 'devolucao', 'outro') NOT NULL,

    quantidade_anterior DECIMAL(12,3) NOT NULL,
    quantidade_movimentada DECIMAL(12,3) NOT NULL,
    quantidade_posterior DECIMAL(12,3) NOT NULL,

    valor_unitario DECIMAL(12,2) NULL,
    valor_total DECIMAL(12,2) NULL,

    fornecedor_id INT UNSIGNED NULL,
    observacao TEXT NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_mov_estoque_empresa (empresa_id),
    INDEX idx_mov_estoque_produto (produto_id),
    INDEX idx_mov_estoque_data (created_at),

    CONSTRAINT fk_mov_estoque_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_mov_estoque_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE RESTRICT,
    CONSTRAINT fk_mov_estoque_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
    CONSTRAINT fk_mov_estoque_fornecedor FOREIGN KEY (fornecedor_id) REFERENCES fornecedores(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 6. CLIENTES
-- ============================================================

CREATE TABLE clientes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    cpf_cnpj VARCHAR(20) NULL,
    telefone VARCHAR(20) NULL,
    email VARCHAR(150) NULL,
    observacao TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    deleted_at DATETIME NULL,

    INDEX idx_clientes_empresa (empresa_id),
    FULLTEXT INDEX ft_clientes_nome (nome),

    CONSTRAINT fk_clientes_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 7. VENDAS / PDV
-- ============================================================

CREATE TABLE vendas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    numero_venda VARCHAR(30) NOT NULL,
    funcionario_id INT UNSIGNED NOT NULL,
    cliente_id INT UNSIGNED NULL,

    status ENUM('aberta', 'finalizada', 'cancelada', 'devolvida', 'parcial_devolvida') NOT NULL DEFAULT 'aberta',

    subtotal DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    desconto DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    total DECIMAL(12,2) NOT NULL DEFAULT 0.00,

    observacoes TEXT NULL,
    motivo_cancelamento VARCHAR(255) NULL,
    cancelada_por INT UNSIGNED NULL,

    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    finalizada_em DATETIME NULL,
    cancelada_em DATETIME NULL,

    UNIQUE KEY uq_vendas_numero (empresa_id, numero_venda),
    INDEX idx_vendas_empresa (empresa_id),
    INDEX idx_vendas_funcionario (funcionario_id),
    INDEX idx_vendas_status (status),
    INDEX idx_vendas_data (created_at),

    CONSTRAINT fk_vendas_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_vendas_funcionario FOREIGN KEY (funcionario_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
    CONSTRAINT fk_vendas_cliente FOREIGN KEY (cliente_id) REFERENCES clientes(id) ON DELETE SET NULL,
    CONSTRAINT fk_vendas_cancelada_por FOREIGN KEY (cancelada_por) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

ALTER TABLE movimentacoes_estoque
    ADD CONSTRAINT fk_mov_estoque_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL;

CREATE TABLE venda_itens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venda_id INT UNSIGNED NOT NULL,
    produto_id INT UNSIGNED NOT NULL,
    quantidade DECIMAL(12,3) NOT NULL,
    preco_unitario DECIMAL(12,2) NOT NULL,
    subtotal DECIMAL(12,2) NOT NULL,
    quantidade_devolvida DECIMAL(12,3) NOT NULL DEFAULT 0,

    INDEX idx_venda_itens_venda (venda_id),
    INDEX idx_venda_itens_produto (produto_id),

    CONSTRAINT fk_venda_itens_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
    CONSTRAINT fk_venda_itens_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE venda_pagamentos (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venda_id INT UNSIGNED NOT NULL,
    forma ENUM('dinheiro', 'pix', 'debito', 'credito', 'outro') NOT NULL,
    valor DECIMAL(12,2) NOT NULL,
    parcelas SMALLINT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_venda_pagamentos_venda (venda_id),

    CONSTRAINT fk_venda_pagamentos_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE venda_devolucoes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    venda_id INT UNSIGNED NOT NULL,
    venda_item_id INT UNSIGNED NOT NULL,
    quantidade DECIMAL(12,3) NOT NULL,
    motivo VARCHAR(255) NULL,
    usuario_id INT UNSIGNED NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_devolucoes_venda (venda_id),

    CONSTRAINT fk_devolucoes_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE CASCADE,
    CONSTRAINT fk_devolucoes_item FOREIGN KEY (venda_item_id) REFERENCES venda_itens(id) ON DELETE CASCADE,
    CONSTRAINT fk_devolucoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 8. FINANCEIRO
-- ============================================================

CREATE TABLE movimentacoes_financeiras (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    tipo ENUM('entrada', 'saida') NOT NULL,
    categoria VARCHAR(100) NOT NULL,
    descricao VARCHAR(255) NOT NULL,
    valor DECIMAL(12,2) NOT NULL,
    forma_pagamento ENUM('dinheiro', 'pix', 'debito', 'credito', 'transferencia', 'outro') NULL,
    responsavel_id INT UNSIGNED NOT NULL,
    venda_id INT UNSIGNED NULL,
    movimentacao_estoque_id INT UNSIGNED NULL,
    observacao TEXT NULL,
    data_movimentacao DATE NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_fin_empresa (empresa_id),
    INDEX idx_fin_tipo (tipo),
    INDEX idx_fin_data (data_movimentacao),

    CONSTRAINT fk_fin_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_fin_responsavel FOREIGN KEY (responsavel_id) REFERENCES usuarios(id) ON DELETE RESTRICT,
    CONSTRAINT fk_fin_venda FOREIGN KEY (venda_id) REFERENCES vendas(id) ON DELETE SET NULL,
    CONSTRAINT fk_fin_mov_estoque FOREIGN KEY (movimentacao_estoque_id) REFERENCES movimentacoes_estoque(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 9. JORNADA DE TRABALHO
-- ============================================================

CREATE TABLE jornadas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    entrada DATETIME NOT NULL,
    saida DATETIME NULL,
    duracao_minutos INT UNSIGNED NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_jornadas_empresa (empresa_id),
    INDEX idx_jornadas_usuario (usuario_id),
    INDEX idx_jornadas_entrada (entrada),

    CONSTRAINT fk_jornadas_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_jornadas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 10. COMUNICAÇÃO — CHAT, NOTIFICAÇÕES, LEMBRETES, FEEDBACK
-- ============================================================

CREATE TABLE conversas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario1_id INT UNSIGNED NOT NULL,
    usuario2_id INT UNSIGNED NOT NULL,
    ultima_mensagem_em DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE KEY uq_conversas_par (usuario1_id, usuario2_id),
    INDEX idx_conversas_u1 (usuario1_id),
    INDEX idx_conversas_u2 (usuario2_id),

    CONSTRAINT fk_conversas_u1 FOREIGN KEY (usuario1_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_conversas_u2 FOREIGN KEY (usuario2_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE mensagens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    conversa_id INT UNSIGNED NOT NULL,
    remetente_id INT UNSIGNED NOT NULL,
    texto TEXT NOT NULL,
    lida_em DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_mensagens_conversa (conversa_id),
    INDEX idx_mensagens_data (created_at),

    CONSTRAINT fk_mensagens_conversa FOREIGN KEY (conversa_id) REFERENCES conversas(id) ON DELETE CASCADE,
    CONSTRAINT fk_mensagens_remetente FOREIGN KEY (remetente_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE notificacoes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NOT NULL,
    tipo ENUM('informativa', 'alerta', 'aviso', 'sistema', 'estoque', 'financeiro', 'jornada', 'conta_congelada', 'mensagem') NOT NULL,
    prioridade ENUM('verde', 'amarelo', 'vermelho') NOT NULL DEFAULT 'verde',
    titulo VARCHAR(150) NOT NULL,
    mensagem TEXT NOT NULL,
    lida_em DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_notif_usuario (usuario_id),
    INDEX idx_notif_lida (lida_em),

    CONSTRAINT fk_notif_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE,
    CONSTRAINT fk_notif_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE lembretes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    criador_id INT UNSIGNED NOT NULL,
    destinatario_id INT UNSIGNED NOT NULL,
    titulo VARCHAR(150) NOT NULL,
    descricao TEXT NULL,
    prioridade ENUM('verde', 'amarelo', 'vermelho') NOT NULL DEFAULT 'verde',
    status ENUM('pendente', 'concluido') NOT NULL DEFAULT 'pendente',
    data_conclusao DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_lembretes_empresa (empresa_id),
    INDEX idx_lembretes_destinatario (destinatario_id),

    CONSTRAINT fk_lembretes_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_lembretes_criador FOREIGN KEY (criador_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_lembretes_destinatario FOREIGN KEY (destinatario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE feedbacks (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    funcionario_id INT UNSIGNED NOT NULL,
    admin_id INT UNSIGNED NOT NULL,
    tipo ENUM('positivo', 'atencao', 'observacao') NOT NULL,
    descricao TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_feedbacks_funcionario (funcionario_id),

    CONSTRAINT fk_feedbacks_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE RESTRICT,
    CONSTRAINT fk_feedbacks_funcionario FOREIGN KEY (funcionario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    CONSTRAINT fk_feedbacks_admin FOREIGN KEY (admin_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- 11. AUDITORIA E CONFIGURAÇÕES
-- ============================================================

CREATE TABLE auditoria (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NULL,
    acao VARCHAR(100) NOT NULL,
    tabela_afetada VARCHAR(60) NULL,
    registro_id INT UNSIGNED NULL,
    dados_anteriores JSON NULL,
    dados_novos JSON NULL,
    ip VARCHAR(45) NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    INDEX idx_auditoria_empresa (empresa_id),
    INDEX idx_auditoria_usuario (usuario_id),
    INDEX idx_auditoria_acao (acao),
    INDEX idx_auditoria_data (created_at),

    CONSTRAINT fk_auditoria_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE SET NULL,
    CONSTRAINT fk_auditoria_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE configuracoes_empresa (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    empresa_id INT UNSIGNED NOT NULL,
    chave VARCHAR(100) NOT NULL,
    valor TEXT NULL,

    UNIQUE KEY uq_config_empresa_chave (empresa_id, chave),
    CONSTRAINT fk_config_empresa FOREIGN KEY (empresa_id) REFERENCES empresas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- FIM DO SCHEMA
-- ============================================================
