/**
 * =============================================================
 * ARQUIVO: public/js/comunicacao.js
 * RESPONSABILIDADE: toda a interatividade da tela de chat —
 *                    carregar contatos/conversas, abrir uma
 *                    conversa, buscar mensagens novas por polling
 *                    e enviar mensagens. Fala com api/comunicacao.php.
 * =============================================================
 */

const INTERVALO_POLLING_CHAT_MS = 12000; // 12 segundos — evita rajadas de requisições

/**
 * FUNÇÃO: statusPresenca()
 * O QUE FAZ: a partir do horário da última atividade de um usuário,
 *            devolve um texto de status ("Online agora" ou "Visto por
 *            último às HH:mm") e se ele deve ser tratado como online.
 * COMO FAZ: considera "online" quem teve atividade nos últimos 5
 *           minutos — o mesmo critério usado no dashboard do Mestre
 *           (Usuario::atualizarUltimaAtividade() roda a cada página
 *           carregada, então esse valor fica sempre atualizado
 *           enquanto a pessoa está navegando pelo sistema).
 * FIM DA FUNÇÃO
 */
function statusPresenca(ultimaAtividade) {
    if (!ultimaAtividade) {
        return { online: false, texto: 'Nunca acessou' };
    }

    // O MySQL devolve "AAAA-MM-DD HH:mm:ss"; trocamos o espaço por "T"
    // para o JavaScript conseguir interpretar a data corretamente.
    const dataAtividade = new Date(ultimaAtividade.replace(' ', 'T'));
    const minutosDesdeAtividade = (Date.now() - dataAtividade.getTime()) / 60000;

    if (minutosDesdeAtividade <= 5) {
        return { online: true, texto: 'Online agora' };
    }

    const horaFormatada = dataAtividade.toLocaleString('pt-BR', {
        day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit',
    });
    return { online: false, texto: 'Visto por último em ' + horaFormatada };
}

let conversaAtualId = null;
let ultimoIdMensagemRecebida = 0;
let intervaloPollingMensagens = null;

/**
 * FUNÇÃO: chamarApiChat()
 * O QUE FAZ: centraliza as chamadas fetch() para api/comunicacao.php,
 *            usando GET para leitura e POST (com CSRF) para escrita.
 * FIM DA FUNÇÃO
 */
async function chamarApiChat(acao, parametros = {}, metodoPost = false) {
    if (metodoPost) {
        const dados = new FormData();
        dados.append('acao', acao);
        dados.append('csrf_token', window.APP_CSRF_TOKEN);
        for (const chave in parametros) {
            dados.append(chave, parametros[chave]);
        }

        const resposta = await fetch('/api/comunicacao.php', { method: 'POST', body: dados });
        return resposta.json();
    }

    const query = new URLSearchParams({ acao, ...parametros }).toString();
    const resposta = await fetch('/api/comunicacao.php?' + query);
    return resposta.json();
}

/**
 * FUNÇÃO: carregarConversasEContatos()
 * O QUE FAZ: busca a lista de conversas já existentes e a lista de
 *            contatos com quem o usuário pode iniciar uma nova
 *            conversa, e desenha as duas listas na barra lateral.
 * FIM DA FUNÇÃO
 */
async function carregarConversasEContatos() {
    // Uma única requisição combinada (em vez de duas simultâneas via
    // Promise.all) — reduz o "pico" de tráfego ao abrir o chat, que
    // hospedagens gratuitas às vezes tratam como comportamento suspeito.
    const resposta = await chamarApiChat('inicializar');

    if (!resposta.sucesso) {
        document.getElementById('chat-lista-conversas').innerHTML =
            '<p style="font-size:13px;color:var(--cor-erro);">Não foi possível carregar o chat agora. Atualize a página em instantes.</p>';
        return;
    }

    const listaConversas = document.getElementById('chat-lista-conversas');
    listaConversas.innerHTML = resposta.conversas.map((conversa) => {
        const presenca = statusPresenca(conversa.outro_usuario_ultima_atividade);
        return `
        <div class="chat-conversa" data-conversa-id="${conversa.id}" data-nome="${conversa.outro_usuario_nome}" data-status="${presenca.texto}">
            <span>
                <span class="chat-status-bolinha ${presenca.online ? 'chat-status-bolinha--online' : ''}" title="${presenca.texto}"></span>
                ${conversa.outro_usuario_nome}
            </span>
            ${conversa.nao_lidas > 0 ? `<span class="badge badge--vermelho">${conversa.nao_lidas}</span>` : ''}
        </div>
    `;
    }).join('') || '<p style="font-size:13px;color:var(--cor-texto-suave);">Nenhuma conversa ainda.</p>';

    const listaContatos = document.getElementById('chat-lista-contatos');
    listaContatos.innerHTML = resposta.contatos.map((contato) => {
        const presenca = statusPresenca(contato.ultima_atividade);
        return `
        <div class="chat-contato" data-destinatario-id="${contato.id}" data-nome="${contato.nome}" data-status="${presenca.texto}">
            <span class="chat-status-bolinha ${presenca.online ? 'chat-status-bolinha--online' : ''}" title="${presenca.texto}"></span>
            ${contato.nome}
        </div>
    `;
    }).join('') || '<p style="font-size:13px;color:var(--cor-texto-suave);">Nenhum contato disponível.</p>';
}

/**
 * FUNÇÃO: renderizarMensagens()
 * O QUE FAZ: adiciona à janela de conversa as mensagens recebidas,
 *            diferenciando visualmente as mensagens enviadas por
 *            mim das recebidas do outro participante.
 * FIM DA FUNÇÃO
 */
function renderizarMensagens(mensagens) {
    const painel = document.getElementById('chat-mensagens');

    mensagens.forEach((mensagem) => {
        const ehMinha = Number(mensagem.remetente_id) === Number(window.APP_USUARIO_ID);
        const bolha = document.createElement('div');
        bolha.className = 'chat-bolha ' + (ehMinha ? 'chat-bolha--minha' : 'chat-bolha--outra');
        bolha.textContent = mensagem.texto;
        painel.appendChild(bolha);

        ultimoIdMensagemRecebida = Math.max(ultimoIdMensagemRecebida, Number(mensagem.id));
    });

    if (mensagens.length > 0) {
        painel.scrollTop = painel.scrollHeight;
    }
}

/**
 * FUNÇÃO: buscarMensagensNovas()
 * O QUE FAZ: consulta apenas as mensagens posteriores à última já
 *            exibida (polling incremental — evita reprocessar a
 *            conversa inteira a cada consulta).
 * FIM DA FUNÇÃO
 */
async function buscarMensagensNovas() {
    if (!conversaAtualId) {
        return;
    }

    try {
        const resposta = await chamarApiChat('listar_mensagens', {
            conversa_id: conversaAtualId,
            depois_de: ultimoIdMensagemRecebida,
        });

        if (resposta.sucesso) {
            renderizarMensagens(resposta.mensagens);
        }
    } catch (erro) {
        // Falha de rede/servidor pontual: apenas ignora esta rodada de
        // polling, sem travar a tela — a próxima tentativa acontece
        // normalmente no próximo intervalo.
    }
}

/**
 * FUNÇÃO: abrirConversaComContato()
 * O QUE FAZ: obtém (ou cria) a conversa com um contato e a exibe.
 * FIM DA FUNÇÃO
 */
async function abrirConversaComContato(destinatarioId, nome, status) {
    const resposta = await chamarApiChat('abrir_conversa', { destinatario_id: destinatarioId }, true);

    if (!resposta.sucesso) {
        alert(resposta.mensagem);
        return;
    }

    abrirConversaPorId(resposta.conversa_id, nome, status);
}

/**
 * FUNÇÃO: abrirConversaPorId()
 * O QUE FAZ: troca a conversa ativa na tela, limpa a janela de
 *            mensagens e reinicia o polling incremental a partir do zero.
 * FIM DA FUNÇÃO
 */
function abrirConversaPorId(conversaId, nome, status) {
    conversaAtualId = conversaId;
    ultimoIdMensagemRecebida = 0;

    document.getElementById('chat-cabecalho-conversa').innerHTML =
        `${nome}${status ? `<div class="chat__status-texto">${status}</div>` : ''}`;
    document.getElementById('chat-mensagens').innerHTML = '';
    document.getElementById('chat-form-envio').style.display = 'flex';

    document.querySelectorAll('.chat-conversa').forEach((el) => el.classList.remove('chat-conversa--ativa'));
    const elementoConversa = document.querySelector(`.chat-conversa[data-conversa-id="${conversaId}"]`);
    if (elementoConversa) {
        elementoConversa.classList.add('chat-conversa--ativa');
    }

    buscarMensagensNovas();
}

/**
 * FUNÇÃO: inicializarChat()
 * O QUE FAZ: liga os eventos de clique (abrir conversa/contato) e
 *            de envio de mensagem, carrega os dados iniciais e liga
 *            o polling periódico de mensagens novas.
 * FIM DA FUNÇÃO
 */
function inicializarChat() {
    if (!document.getElementById('chat-lista-conversas')) {
        return;
    }

    carregarConversasEContatos();

    document.getElementById('chat-lista-conversas').addEventListener('click', (evento) => {
        const item = evento.target.closest('.chat-conversa');
        if (item) {
            abrirConversaPorId(item.dataset.conversaId, item.dataset.nome, item.dataset.status);
        }
    });

    document.getElementById('chat-lista-contatos').addEventListener('click', (evento) => {
        const item = evento.target.closest('.chat-contato');
        if (item) {
            abrirConversaComContato(item.dataset.destinatarioId, item.dataset.nome, item.dataset.status);
        }
    });

    document.getElementById('chat-form-envio').addEventListener('submit', async (evento) => {
        evento.preventDefault();
        const campoTexto = document.getElementById('chat-texto');
        const texto = campoTexto.value.trim();
        if (texto === '' || !conversaAtualId) {
            return;
        }

        campoTexto.value = '';
        await chamarApiChat('enviar_mensagem', { conversa_id: conversaAtualId, texto }, true);
        buscarMensagensNovas();
    });

    intervaloPollingMensagens = setInterval(buscarMensagensNovas, INTERVALO_POLLING_CHAT_MS);
}

document.addEventListener('DOMContentLoaded', inicializarChat);
