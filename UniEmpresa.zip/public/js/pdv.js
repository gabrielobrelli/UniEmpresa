/**
 * =============================================================
 * ARQUIVO: public/js/pdv.js
 * RESPONSABILIDADE: toda a interatividade da tela de PDV
 *                    (funcionario/nova-venda.php), conversando com
 *                    api/pdv.php via fetch(). Nenhuma biblioteca
 *                    externa é usada — JavaScript Vanilla puro,
 *                    conforme exigido no documento de requisitos.
 * =============================================================
 */

// Lista de pagamentos adicionados no modal, mantida em memória até a
// confirmação final (não é salva em nenhum storage do navegador).
let pagamentosAdicionados = [];

/**
 * FUNÇÃO: chamarApiPdv()
 * O QUE FAZ: centraliza toda chamada fetch() para api/pdv.php,
 *            já incluindo o token CSRF automaticamente.
 * COMO FAZ: monta um FormData com a ação e os parâmetros extras
 *           recebidos, envia via POST e devolve o JSON já
 *           convertido em objeto JavaScript.
 * FIM DA FUNÇÃO
 */
async function chamarApiPdv(acao, parametrosExtras = {}) {
    const dados = new FormData();
    dados.append('acao', acao);
    dados.append('csrf_token', window.PDV_CSRF_TOKEN);

    for (const chave in parametrosExtras) {
        dados.append(chave, parametrosExtras[chave]);
    }

    const resposta = await fetch('/api/pdv.php', {
        method: 'POST',
        body: dados,
    });

    return resposta.json();
}

/**
 * FUNÇÃO: formatarMoedaBR()
 * O QUE FAZ: formata um número para o padrão de moeda brasileira
 *            (ex.: 1234.5 -> "R$ 1.234,50"), espelhando no
 *            frontend o mesmo formato usado no backend PHP.
 * FIM DA FUNÇÃO
 */
function formatarMoedaBR(valor) {
    return 'R$ ' + valor.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * FUNÇÃO: exibirMensagem()
 * O QUE FAZ: mostra uma mensagem de sucesso/erro logo abaixo do
 *            campo de código do produto.
 * FIM DA FUNÇÃO
 */
function exibirMensagem(texto, tipo) {
    const caixa = document.getElementById('pdv-mensagem');
    caixa.textContent = texto;
    caixa.className = 'alerta alerta--' + tipo;
    caixa.style.display = 'block';

    // Some sozinha depois de alguns segundos, para não poluir a tela
    // durante um atendimento rápido.
    setTimeout(() => { caixa.style.display = 'none'; }, 4000);
}

/**
 * FUNÇÃO: redesenharCarrinho()
 * O QUE FAZ: recebe os dados de itens/total devolvidos pela API e
 *            redesenha a tabela do carrinho, sem precisar recarregar
 *            a página inteira.
 * FIM DA FUNÇÃO
 */
function redesenharCarrinho(dados) {
    const corpoTabela = document.getElementById('pdv-tabela-itens');
    corpoTabela.innerHTML = '';

    dados.itens.forEach((item) => {
        const linha = document.createElement('tr');
        linha.dataset.itemId = item.id;
        linha.innerHTML = `
            <td>${item.produto_nome}</td>
            <td>${item.quantidade}</td>
            <td>${formatarMoedaBR(item.preco_unitario)}</td>
            <td>${formatarMoedaBR(item.subtotal)}</td>
            <td><button type="button" class="pdv-remover-item" data-item-id="${item.id}"
                        style="color:var(--cor-erro); border:none; background:none; cursor:pointer;">Remover</button></td>
        `;
        corpoTabela.appendChild(linha);
    });

    document.getElementById('pdv-total').textContent = formatarMoedaBR(dados.total);
    window.PDV_TOTAL_ATUAL = dados.total;
}

/**
 * FUNÇÃO: adicionarProdutoAoCarrinho()
 * O QUE FAZ: lê o código e a quantidade digitados, chama a API para
 *            adicionar o item, e já limpa o campo de código para o
 *            próximo produto (fluxo rápido: código -> Enter -> repete).
 * FIM DA FUNÇÃO
 */
async function adicionarProdutoAoCarrinho() {
    const campoCodigo = document.getElementById('pdv-codigo');
    const campoQuantidade = document.getElementById('pdv-quantidade');

    const codigo = campoCodigo.value.trim();
    const quantidade = campoQuantidade.value.trim() || '1';

    if (codigo === '') {
        return;
    }

    // Primeiro localiza o produto pelo código para confirmar que
    // existe (e mostrar uma mensagem clara se não existir), depois
    // efetivamente adiciona ao carrinho.
    const buscaResultado = await chamarApiPdv('buscar_produto', { codigo });

    if (!buscaResultado.sucesso) {
        exibirMensagem(buscaResultado.mensagem, 'erro');
        campoCodigo.select();
        return;
    }

    const adicaoResultado = await chamarApiPdv('adicionar_item', {
        produto_id: buscaResultado.produto.id,
        quantidade,
    });

    if (!adicaoResultado.sucesso) {
        exibirMensagem(adicaoResultado.mensagem, 'erro');
        return;
    }

    redesenharCarrinho(adicaoResultado);
    campoCodigo.value = '';
    campoQuantidade.value = '1';
    campoCodigo.focus();
}

/**
 * FUNÇÃO: removerItemDoCarrinho()
 * O QUE FAZ: remove uma linha específica do carrinho pelo ID do item.
 * FIM DA FUNÇÃO
 */
async function removerItemDoCarrinho(itemId) {
    const resultado = await chamarApiPdv('remover_item', { item_id: itemId });
    if (resultado.sucesso) {
        redesenharCarrinho(resultado);
    }
}

/**
 * FUNÇÃO: abrirModalPagamento()
 * O QUE FAZ: reseta a lista de pagamentos e abre o modal de
 *            pagamento combinado, mostrando o total a pagar.
 * FIM DA FUNÇÃO
 */
function abrirModalPagamento() {
    if (window.PDV_TOTAL_ATUAL <= 0) {
        exibirMensagem('Adicione ao menos um produto antes de finalizar.', 'erro');
        return;
    }

    pagamentosAdicionados = [];
    atualizarListaPagamentosNoModal();

    document.getElementById('pdv-modal-total').textContent = formatarMoedaBR(window.PDV_TOTAL_ATUAL);
    document.getElementById('pdv-valor-pagamento').value = window.PDV_TOTAL_ATUAL.toFixed(2).replace('.', ',');
    document.getElementById('pdv-modal-pagamento').style.display = 'flex';
}

/**
 * FUNÇÃO: calcularRestante()
 * O QUE FAZ: calcula quanto ainda falta pagar, subtraindo a soma
 *            dos pagamentos já adicionados do total da venda.
 * FIM DA FUNÇÃO
 */
function calcularRestante() {
    const somaPagamentos = pagamentosAdicionados.reduce((soma, p) => soma + p.valor, 0);
    return window.PDV_TOTAL_ATUAL - somaPagamentos;
}

/**
 * FUNÇÃO: atualizarListaPagamentosNoModal()
 * O QUE FAZ: redesenha a lista de formas de pagamento já
 *            adicionadas dentro do modal, e atualiza o valor
 *            "restante a pagar" (seção 26 — pagamento combinado).
 * FIM DA FUNÇÃO
 */
function atualizarListaPagamentosNoModal() {
    const lista = document.getElementById('pdv-lista-pagamentos');
    lista.innerHTML = '';

    const rotulos = { dinheiro: 'Dinheiro', pix: 'Pix', debito: 'Débito', credito: 'Crédito', outro: 'Outro' };

    pagamentosAdicionados.forEach((pagamento, indice) => {
        const linha = document.createElement('div');
        linha.className = 'pdv-pagamento-linha';
        const parcelasTexto = pagamento.parcelas > 1 ? ` (${pagamento.parcelas}x)` : '';
        linha.innerHTML = `
            <span>${rotulos[pagamento.forma]}${parcelasTexto}</span>
            <span>${formatarMoedaBR(pagamento.valor)}
                <button type="button" data-indice="${indice}" class="pdv-remover-pagamento"
                        style="border:none;background:none;color:var(--cor-erro);cursor:pointer;">✕</button>
            </span>
        `;
        lista.appendChild(linha);
    });

    document.getElementById('pdv-restante').textContent = formatarMoedaBR(calcularRestante());
}

/**
 * FUNÇÃO: inicializarBuscaPorNome()
 * O QUE FAZ: liga o campo "buscar por nome" a um autocomplete simples
 *            — digita ao menos 2 letras, o sistema sugere produtos, e
 *            um clique na sugestão já adiciona o produto ao carrinho.
 * COMO FAZ: usa "debounce" (espera 300ms sem digitar) para não disparar
 *           uma requisição a cada tecla — importante em hospedagem
 *           compartilhada, onde cada requisição tem um custo.
 * FIM DA FUNÇÃO
 */
function inicializarBuscaPorNome() {
    const campoBusca = document.getElementById('pdv-busca-nome');
    const caixaSugestoes = document.getElementById('pdv-sugestoes');
    let temporizadorBusca = null;

    campoBusca.addEventListener('input', () => {
        clearTimeout(temporizadorBusca);
        const termo = campoBusca.value.trim();

        if (termo.length < 2) {
            caixaSugestoes.style.display = 'none';
            return;
        }

        temporizadorBusca = setTimeout(async () => {
            const resultado = await chamarApiPdv('sugerir_produtos', { termo }, true);
            if (!resultado.sucesso || resultado.produtos.length === 0) {
                caixaSugestoes.innerHTML = '<div class="pdv-sugestao-item">Nenhum produto encontrado.</div>';
                caixaSugestoes.style.display = 'block';
                return;
            }

            caixaSugestoes.innerHTML = resultado.produtos.map((produto) => `
                <div class="pdv-sugestao-item" data-produto-id="${produto.id}" data-nome="${produto.nome}">
                    <span>${produto.nome}${produto.codigo ? ' (' + produto.codigo + ')' : ''}</span>
                    <span class="pdv-sugestao-item__preco">${formatarMoedaBR(produto.preco_venda)}</span>
                </div>
            `).join('');
            caixaSugestoes.style.display = 'block';
        }, 300);
    });

    caixaSugestoes.addEventListener('click', async (evento) => {
        const item = evento.target.closest('.pdv-sugestao-item[data-produto-id]');
        if (!item) {
            return;
        }

        const quantidade = document.getElementById('pdv-quantidade').value.trim() || '1';
        const resultado = await chamarApiPdv('adicionar_item', { produto_id: item.dataset.produtoId, quantidade }, true);

        if (resultado.sucesso) {
            redesenharCarrinho(resultado);
            campoBusca.value = '';
        } else {
            exibirMensagem(resultado.mensagem, 'erro');
        }

        caixaSugestoes.style.display = 'none';
    });

    // Fecha a lista de sugestões ao clicar fora dela.
    document.addEventListener('click', (evento) => {
        if (evento.target !== campoBusca && !caixaSugestoes.contains(evento.target)) {
            caixaSugestoes.style.display = 'none';
        }
    });
}

/**
 * FUNÇÃO: inicializarNovoClienteRapido()
 * O QUE FAZ: liga o botão "+ Novo" ao lado do seletor de cliente —
 *            abre um miniformulário, salva via AJAX e já seleciona
 *            o cliente recém-criado na venda em andamento, sem
 *            precisar sair da tela de PDV.
 * FIM DA FUNÇÃO
 */
function inicializarNovoClienteRapido() {
    const botaoAbrir = document.getElementById('pdv-btn-novo-cliente');
    const formulario = document.getElementById('pdv-form-novo-cliente');
    const seletorCliente = document.getElementById('pdv-cliente');

    botaoAbrir.addEventListener('click', () => {
        formulario.style.display = formulario.style.display === 'none' ? 'block' : 'none';
    });

    document.getElementById('pdv-btn-cancelar-cliente').addEventListener('click', () => {
        formulario.style.display = 'none';
    });

    document.getElementById('pdv-btn-salvar-cliente').addEventListener('click', async () => {
        const nome = document.getElementById('pdv-cliente-nome').value.trim();
        const telefone = document.getElementById('pdv-cliente-telefone').value.trim();

        if (nome === '') {
            exibirMensagem('Informe o nome do cliente.', 'erro');
            return;
        }

        const resultado = await chamarApiPdv('criar_cliente', { nome, telefone }, true);

        if (!resultado.sucesso) {
            exibirMensagem(resultado.mensagem, 'erro');
            return;
        }

        const novaOpcao = document.createElement('option');
        novaOpcao.value = resultado.cliente.id;
        novaOpcao.textContent = resultado.cliente.nome;
        novaOpcao.selected = true;
        seletorCliente.appendChild(novaOpcao);

        await chamarApiPdv('vincular_cliente', { cliente_id: resultado.cliente.id }, true);

        formulario.style.display = 'none';
        document.getElementById('pdv-cliente-nome').value = '';
        document.getElementById('pdv-cliente-telefone').value = '';
    });
}

/**
 * FUNÇÃO: inicializarPdv()
 * O QUE FAZ: liga todos os eventos de clique/teclado da tela assim
 *            que o HTML termina de carregar.
 * FIM DA FUNÇÃO
 */
function inicializarPdv() {
    // Enter no campo de código já adiciona o produto, para o fluxo
    // "código -> Enter -> próximo produto" ficar bem rápido.
    document.getElementById('pdv-codigo').addEventListener('keydown', (evento) => {
        if (evento.key === 'Enter') {
            evento.preventDefault();
            adicionarProdutoAoCarrinho();
        }
    });

    document.getElementById('pdv-btn-adicionar').addEventListener('click', adicionarProdutoAoCarrinho);

    inicializarBuscaPorNome();
    inicializarNovoClienteRapido();

    // Delegação de evento: os botões "Remover" são recriados a cada
    // redesenho do carrinho, então o clique é escutado no elemento pai.
    document.getElementById('pdv-tabela-itens').addEventListener('click', (evento) => {
        if (evento.target.classList.contains('pdv-remover-item')) {
            removerItemDoCarrinho(evento.target.dataset.itemId);
        }
    });

    document.getElementById('pdv-cliente').addEventListener('change', (evento) => {
        chamarApiPdv('vincular_cliente', { cliente_id: evento.target.value });
    });

    document.getElementById('pdv-btn-finalizar').addEventListener('click', abrirModalPagamento);
    document.getElementById('pdv-btn-cancelar-pagamento').addEventListener('click', () => {
        document.getElementById('pdv-modal-pagamento').style.display = 'none';
    });

    document.getElementById('pdv-forma-pagamento').addEventListener('change', (evento) => {
        document.getElementById('pdv-campo-parcelas').style.display =
            evento.target.value === 'credito' ? 'block' : 'none';
    });

    document.getElementById('pdv-btn-add-pagamento').addEventListener('click', () => {
        const forma = document.getElementById('pdv-forma-pagamento').value;
        const valorTexto = document.getElementById('pdv-valor-pagamento').value.replace(',', '.');
        const valor = parseFloat(valorTexto);
        const parcelas = forma === 'credito' ? parseInt(document.getElementById('pdv-parcelas').value, 10) : null;

        if (isNaN(valor) || valor <= 0) {
            return;
        }

        pagamentosAdicionados.push({ forma, valor, parcelas });
        atualizarListaPagamentosNoModal();

        // Sugere automaticamente o valor restante no campo, para
        // agilizar quando o funcionário for adicionar a próxima forma
        // de pagamento (ex.: parte em dinheiro, parte no Pix).
        const restante = calcularRestante();
        document.getElementById('pdv-valor-pagamento').value = restante > 0 ? restante.toFixed(2).replace('.', ',') : '';
    });

    document.getElementById('pdv-lista-pagamentos').addEventListener('click', (evento) => {
        if (evento.target.classList.contains('pdv-remover-pagamento')) {
            pagamentosAdicionados.splice(parseInt(evento.target.dataset.indice, 10), 1);
            atualizarListaPagamentosNoModal();
        }
    });

    document.getElementById('pdv-btn-confirmar-pagamento').addEventListener('click', async () => {
        const restante = calcularRestante();

        // Tolerância de 1 centavo para evitar bloqueio por arredondamento
        // de ponto flutuante — a mesma tolerância usada no backend.
        if (Math.abs(restante) > 0.01) {
            exibirMensagem('A soma dos pagamentos precisa fechar com o total da venda.', 'erro');
            return;
        }

        const botao = document.getElementById('pdv-btn-confirmar-pagamento');
        // Desabilita o botão imediatamente para impedir duplo clique
        // gerando duas finalizações da mesma venda (seção 74/75).
        botao.disabled = true;

        const resultado = await chamarApiPdv('finalizar', {
            pagamentos: JSON.stringify(pagamentosAdicionados),
        });

        if (resultado.sucesso) {
            window.location.href = '/funcionario/venda-comprovante.php?id=' + resultado.venda_id;
        } else {
            exibirMensagem(resultado.mensagem, 'erro');
            botao.disabled = false;
        }
    });
}

document.addEventListener('DOMContentLoaded', inicializarPdv);
