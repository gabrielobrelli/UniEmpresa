/**
 * =============================================================
 * ARQUIVO: public/js/notificacoes.js
 * RESPONSABILIDADE: alimenta o sino de notificações presente no
 *                    topo de toda tela interna. Consulta
 *                    api/notificacoes.php periodicamente (polling),
 *                    já que o InfinityFree não suporta WebSocket.
 * =============================================================
 */

const INTERVALO_POLLING_NOTIFICACOES_MS = 45000; // 45 segundos — leve o suficiente para não sobrecarregar hospedagem gratuita

/**
 * FUNÇÃO: buscarNotificacoes()
 * O QUE FAZ: consulta a lista atual de notificações do usuário
 *            logado e atualiza o contador do sino.
 * FIM DA FUNÇÃO
 */
async function buscarNotificacoes() {
    let dados;
    try {
        const resposta = await fetch('/api/notificacoes.php?acao=listar');
        dados = await resposta.json();
    } catch (erro) {
        return; // falha pontual — tenta de novo no próximo intervalo
    }

    if (!dados.sucesso) {
        return;
    }

    const contador = document.getElementById('sino-contador');
    if (dados.nao_lidas > 0) {
        contador.textContent = dados.nao_lidas > 99 ? '99+' : dados.nao_lidas;
        contador.style.display = 'inline-block';
    } else {
        contador.style.display = 'none';
    }

    redesenharListaNotificacoes(dados.notificacoes);
}

/**
 * FUNÇÃO: redesenharListaNotificacoes()
 * O QUE FAZ: monta o HTML do dropdown de notificações, usando um
 *            ícone diferente por prioridade (verde/amarelo/vermelho)
 *            além da cor, para não depender só da cor (acessibilidade
 *            — seção 43 do documento).
 * FIM DA FUNÇÃO
 */
function redesenharListaNotificacoes(notificacoes) {
    const lista = document.getElementById('sino-lista');
    const iconePorPrioridade = { verde: 'ℹ️', amarelo: '⚠️', vermelho: '🔴' };

    if (notificacoes.length === 0) {
        lista.innerHTML = '<div class="notificacao-item">Nenhuma notificação por aqui.</div>';
        return;
    }

    lista.innerHTML = notificacoes.map((notificacao) => {
        const classeLida = notificacao.lida_em ? '' : 'notificacao-item--nao-lida';
        const icone = iconePorPrioridade[notificacao.prioridade] || 'ℹ️';
        return `
            <div class="notificacao-item ${classeLida}" data-id="${notificacao.id}">
                <div class="notificacao-item__titulo">${icone} ${notificacao.titulo}</div>
                <div>${notificacao.mensagem}</div>
            </div>
        `;
    }).join('');
}

/**
 * FUNÇÃO: inicializarSinoNotificacoes()
 * O QUE FAZ: liga o clique do sino (abre/fecha a lista) e o clique
 *            em cada notificação (marca como lida), e inicia o
 *            polling periódico.
 * FIM DA FUNÇÃO
 */
function inicializarSinoNotificacoes() {
    const botaoSino = document.getElementById('botao-sino');
    const lista = document.getElementById('sino-lista');

    if (!botaoSino) {
        // Esta página não usa o layout interno (ex.: telas de login) —
        // não há sino para inicializar.
        return;
    }

    botaoSino.addEventListener('click', () => {
        const estaAberta = lista.style.display === 'block';
        lista.style.display = estaAberta ? 'none' : 'block';
    });

    // Fecha o dropdown ao clicar fora dele.
    document.addEventListener('click', (evento) => {
        if (!document.getElementById('sino-notificacoes').contains(evento.target)) {
            lista.style.display = 'none';
        }
    });

    lista.addEventListener('click', async (evento) => {
        const item = evento.target.closest('.notificacao-item[data-id]');
        if (!item) {
            return;
        }

        const dados = new FormData();
        dados.append('acao', 'marcar_lida');
        dados.append('id', item.dataset.id);
        dados.append('csrf_token', window.APP_CSRF_TOKEN);

        await fetch('/api/notificacoes.php', { method: 'POST', body: dados });
        buscarNotificacoes();
    });

    buscarNotificacoes();
    setInterval(buscarNotificacoes, INTERVALO_POLLING_NOTIFICACOES_MS);
}

document.addEventListener('DOMContentLoaded', inicializarSinoNotificacoes);
