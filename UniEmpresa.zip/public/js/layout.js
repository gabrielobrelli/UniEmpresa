/**
 * =============================================================
 * ARQUIVO: public/js/layout.js
 * RESPONSABILIDADE: controlar a abertura/fechamento da sidebar em
 *                    formato de gaveta (drawer) nas telas pequenas.
 *                    Em telas grandes, a sidebar fica sempre visível
 *                    e este script não faz nada perceptível.
 * =============================================================
 */

/**
 * FUNÇÃO: inicializarMenuMobile()
 * O QUE FAZ: liga o clique do botão hambúrguer e do overlay para
 *            abrir/fechar a sidebar, e fecha automaticamente ao
 *            escolher um item do menu (comportamento esperado em
 *            apps mobile — não fica a gaveta aberta depois de navegar).
 * FIM DA FUNÇÃO
 */
function inicializarMenuMobile() {
    const botao = document.getElementById('botao-menu-mobile');
    const menu = document.getElementById('menu-lateral');
    const overlay = document.getElementById('overlay-menu-mobile');

    if (!botao || !menu || !overlay) {
        return;
    }

    function abrirMenu() {
        menu.classList.add('menu-lateral--aberta');
        overlay.classList.add('overlay-menu-mobile--visivel');
    }

    function fecharMenu() {
        menu.classList.remove('menu-lateral--aberta');
        overlay.classList.remove('overlay-menu-mobile--visivel');
    }

    botao.addEventListener('click', () => {
        const estaAberto = menu.classList.contains('menu-lateral--aberta');
        estaAberto ? fecharMenu() : abrirMenu();
    });

    overlay.addEventListener('click', fecharMenu);

    // Fecha a gaveta assim que o usuário toca em um link do menu,
    // para não precisar de um segundo toque para ver a página nova.
    menu.querySelectorAll('.menu-lateral__link, .menu-lateral__sair').forEach((link) => {
        link.addEventListener('click', fecharMenu);
    });
}

document.addEventListener('DOMContentLoaded', inicializarMenuMobile);
