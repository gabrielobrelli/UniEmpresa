<?php
/**
 * =============================================================
 * ARQUIVO: diagnostico.php
 * RESPONSABILIDADE: ferramenta temporária de diagnóstico — mostra,
 *                    em texto simples, o resultado de cada etapa que
 *                    o chat percorre (sessão, permissões, banco de
 *                    dados), para descobrir exatamente onde algo
 *                    quebra sem precisar abrir o DevTools do
 *                    navegador (útil especialmente pelo celular).
 *
 * COMO USAR: acesse /diagnostico.php logado com o usuário que está
 *            vendo o erro 403 no chat, e mande um print desta tela.
 *
 * IMPORTANTE: por ser uma ferramenta de diagnóstico, esta página
 * mostra mensagens de erro técnicas mesmo em produção — algo que o
 * resto do sistema evita de propósito (ver seção 73 do documento de
 * requisitos). É só um arquivo temporário: depois de resolvido o
 * problema, apague este arquivo do servidor.
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';

function linha(string $rotulo, $valor, bool $ok = true): string
{
    $cor = $ok ? '#16a34a' : '#dc2626';
    $simbolo = $ok ? '✅' : '❌';
    $valorTexto = is_bool($valor) ? ($valor ? 'sim' : 'não') : (string) $valor;
    return "<tr><td style='padding:6px 10px;border-bottom:1px solid #e2e8f0;'>{$simbolo} {$rotulo}</td>"
        . "<td style='padding:6px 10px;border-bottom:1px solid #e2e8f0;color:{$cor};font-family:monospace;'>"
        . htmlspecialchars($valorTexto, ENT_QUOTES, 'UTF-8') . "</td></tr>";
}

echo '<!DOCTYPE html><html lang="pt-BR"><head><meta charset="UTF-8">';
echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">';
echo '<title>Diagnóstico</title></head>';
echo '<body style="font-family: sans-serif; padding: 16px; background:#f1f5f9;">';
echo '<h2>Diagnóstico do sistema</h2>';
echo '<table style="width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden;">';

// --- 1) Sessão / login -------------------------------------------------
echo linha('PHP versão', phpversion());
echo linha('session_save_path em uso', session_save_path());
echo linha('Pasta de sessão é gravável', is_writable(session_save_path()));
echo linha('Sessão ativa (session_status)', session_status() === PHP_SESSION_ACTIVE);
echo linha('Usuário logado (usuarioLogado())', usuarioLogado(), usuarioLogado());

if (!usuarioLogado()) {
    echo '</table><p style="color:#dc2626;"><strong>Você não está logado.</strong> Faça login e acesse esta página de novo.</p>';
    echo '</body></html>';
    exit;
}

echo linha('usuarioId()', usuarioId());
echo linha('usuarioTipo()', usuarioTipo());
echo linha('usuarioEmpresaId()', usuarioEmpresaId() ?? 'null (correto p/ Mestre)');
echo linha('Nome na sessão', $_SESSION['nome'] ?? '(vazio)');

// --- 2) Extensões PHP necessárias --------------------------------------
echo linha('Extensão PDO MySQL', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql'));
echo linha('Extensão ZipArchive (usada no backup)', class_exists('ZipArchive'), class_exists('ZipArchive'));
echo linha('Extensão fileinfo (usada no upload)', extension_loaded('fileinfo'), extension_loaded('fileinfo'));

// --- 3) Teste de conexão com o banco ------------------------------------
try {
    $pdo = getPDO();
    echo linha('Conexão com o banco de dados', 'OK', true);
} catch (Throwable $e) {
    echo linha('Conexão com o banco de dados', $e->getMessage(), false);
    echo '</table></body></html>';
    exit;
}

// --- 4) Teste específico do CHAT, passo a passo -------------------------
require_once __DIR__ . '/app/models/Conversa.php';
require_once __DIR__ . '/app/models/Mensagem.php';

try {
    $contatos = Conversa::contatosPermitidos(usuarioId(), usuarioTipo(), usuarioEmpresaId());
    echo linha('Conversa::contatosPermitidos()', 'OK — ' . count($contatos) . ' contato(s) encontrado(s)', true);
} catch (Throwable $e) {
    echo linha('Conversa::contatosPermitidos()', get_class($e) . ': ' . $e->getMessage(), false);
}

try {
    $conversas = Conversa::listarConversasDoUsuario(usuarioId());
    echo linha('Conversa::listarConversasDoUsuario()', 'OK — ' . count($conversas) . ' conversa(s) encontrada(s)', true);
} catch (Throwable $e) {
    echo linha('Conversa::listarConversasDoUsuario()', get_class($e) . ': ' . $e->getMessage(), false);
}

// --- 5) Simula a chamada real que o navegador faz -----------------------
echo '</table><h3>Simulando a chamada que o chat faz de verdade</h3>';
echo '<p>Isso chama api/comunicacao.php internamente, do mesmo jeito que o navegador chamaria:</p>';

$contextoInterno = stream_context_create(['http' => ['ignore_errors' => true]]);
$cookieAtual = session_name() . '=' . session_id();

$urlChat = (!empty($_SERVER['HTTPS']) ? 'https://' : 'http://') . $_SERVER['HTTP_HOST'] . '/api/comunicacao.php?acao=inicializar';

$opcoes = [
    'http' => [
        'method' => 'GET',
        'header' => "Cookie: $cookieAtual\r\n",
        'ignore_errors' => true,
    ],
];
$contexto = stream_context_create($opcoes);
$resposta = @file_get_contents($urlChat, false, $contexto);
$statusHttp = $http_response_header[0] ?? '(sem resposta)';

echo '<table style="width:100%; border-collapse:collapse; background:#fff; border-radius:8px; overflow:hidden;">';
echo linha('Status HTTP retornado por api/comunicacao.php', $statusHttp, str_contains($statusHttp, '200'));
echo '</table>';
echo '<p><strong>Corpo da resposta:</strong></p>';
echo '<pre style="background:#0f172a; color:#e2e8f0; padding:12px; border-radius:8px; overflow-x:auto; font-size:12px;">'
    . htmlspecialchars((string) $resposta, ENT_QUOTES, 'UTF-8')
    . '</pre>';

echo '<p style="color:#64748b; font-size:13px; margin-top:24px;">Tire um print desta página inteira (role até o fim) e envie. Depois, apague este arquivo (diagnostico.php) do servidor.</p>';
echo '</body></html>';
