<?php
/**
 * =============================================================
 * ARQUIVO: admin/funcionario-form.php
 * RESPONSABILIDADE: administrador cadastra ou edita um funcionário
 *                    da própria empresa (seção 12). No cadastro,
 *                    define também a meta mínima de horas diárias
 *                    (seção 46), usada depois no controle de jornada.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$funcionarioId = isset($_GET['id']) ? (int) $_GET['id'] : null;
$funcionario = null;

if ($funcionarioId) {
    $funcionario = Usuario::buscarPorId($funcionarioId);
    // Confere que o funcionário pertence à empresa do admin logado —
    // sem essa checagem, um admin poderia editar ID de outra empresa
    // só trocando o número na URL.
    if (!$funcionario || (int) $funcionario['empresa_id'] !== $empresaId || $funcionario['tipo'] !== TIPO_FUNCIONARIO) {
        http_response_code(404);
        die('Funcionário não encontrado.');
    }
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $nome = limparEntrada($_POST['nome'] ?? '');
    $email = limparEntrada($_POST['email'] ?? '');
    $telefone = limparEntrada($_POST['telefone'] ?? '');
    $cargo = limparEntrada($_POST['cargo'] ?? '');
    $dataAdmissao = $_POST['data_admissao'] ?? null;
    $metaHoras = (float) str_replace(',', '.', $_POST['meta_horas'] ?? '8');
    $status = $_POST['status'] ?? 'ativo';
    $senha = (string) ($_POST['senha'] ?? '');

    if ($nome === '' || $email === '') {
        $erro = 'Nome e e-mail são obrigatórios.';
    } elseif (!$funcionarioId && strlen($senha) < 8) {
        $erro = 'A senha inicial deve ter pelo menos 8 caracteres.';
    } else {
        $emailExistente = Usuario::buscarPorEmail($email);
        if ($emailExistente && (!$funcionarioId || (int) $emailExistente['id'] !== $funcionarioId)) {
            $erro = 'Já existe um usuário cadastrado com este e-mail.';
        } else {
            if ($funcionarioId) {
                // Reaproveita Usuario::criar() não se aplica a update;
                // fazemos o update diretamente aqui, restrito aos campos
                // que o admin pode alterar de um funcionário.
                $pdo = getPDO();
                $pdo->prepare(
                    'UPDATE usuarios SET nome=:nome, email=:email, telefone=:telefone, cargo=:cargo,
                        data_admissao=:data_admissao, meta_minutos_diarios=:meta, status=:status, updated_at=NOW()
                     WHERE id=:id AND empresa_id=:empresa_id'
                )->execute([
                    ':nome' => $nome, ':email' => $email, ':telefone' => $telefone, ':cargo' => $cargo,
                    ':data_admissao' => $dataAdmissao ?: null, ':meta' => $metaHoras * 60,
                    ':status' => $status, ':id' => $funcionarioId, ':empresa_id' => $empresaId,
                ]);

                if ($senha !== '') {
                    Usuario::atualizarSenha($funcionarioId, $senha);
                }

                Auditoria::registrar('funcionario_atualizado', 'usuarios', $funcionarioId);
            } else {
                $funcionarioId = Usuario::criar([
                    'empresa_id' => $empresaId,
                    'tipo' => TIPO_FUNCIONARIO,
                    'nome' => $nome,
                    'email' => $email,
                    'senha' => $senha,
                    'telefone' => $telefone,
                    'cargo' => $cargo,
                    'data_admissao' => $dataAdmissao ?: null,
                    'meta_minutos_diarios' => $metaHoras * 60,
                    'perfil_completo' => 0, // obrigará a tela de primeiro acesso (seção 13)
                    'status' => $status,
                ]);

                Auditoria::registrar('funcionario_criado', 'usuarios', $funcionarioId, null, ['email' => $email]);
            }

            header('Location: /admin/funcionarios.php');
            exit;
        }
    }
}

$tituloPagina = $funcionarioId ? 'Editar funcionário' : 'Novo funcionário';
$itemMenuAtivo = 'funcionarios';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="/admin/funcionario-form.php<?= $funcionarioId ? '?id=' . $funcionarioId : '' ?>">
        <?= csrfCampoOculto() ?>

        <div class="campo">
            <label for="nome">Nome completo *</label>
            <input type="text" id="nome" name="nome" required value="<?= escapar($funcionario['nome'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="email">Usuário de acesso *</label>
            <input type="text" id="email" name="email" required value="<?= escapar($funcionario['email'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="senha"><?= $funcionarioId ? 'Nova senha (deixe em branco para manter a atual)' : 'Senha inicial *' ?></label>
            <input type="password" id="senha" name="senha" minlength="8" <?= $funcionarioId ? '' : 'required' ?>>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone" value="<?= escapar($funcionario['telefone'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="cargo">Cargo/função</label>
                <input type="text" id="cargo" name="cargo" value="<?= escapar($funcionario['cargo'] ?? '') ?>">
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="data_admissao">Data de admissão</label>
                <input type="date" id="data_admissao" name="data_admissao" value="<?= escapar($funcionario['data_admissao'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="meta_horas">Meta mínima de horas diárias</label>
                <input type="text" id="meta_horas" name="meta_horas"
                       value="<?= isset($funcionario['meta_minutos_diarios']) ? escapar((string) ($funcionario['meta_minutos_diarios'] / 60)) : '8' ?>">
            </div>
        </div>

        <div class="campo">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="ativo" <?= (($funcionario['status'] ?? 'ativo') === 'ativo') ? 'selected' : '' ?>>Ativo</option>
                <option value="inativo" <?= (($funcionario['status'] ?? '') === 'inativo') ? 'selected' : '' ?>>Inativo</option>
            </select>
        </div>

        <button type="submit" class="botao botao--primario"><?= $funcionarioId ? 'Salvar alterações' : 'Cadastrar funcionário' ?></button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
