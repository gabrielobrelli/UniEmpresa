<?php
/**
 * =============================================================
 * ARQUIVO: admin/unidades.php
 * RESPONSABILIDADE: cadastro das unidades de medida usadas pelos
 *                    produtos da empresa (Unidade, Caixa, Metro,
 *                    Quilograma... — seção 16). A empresa já ganha
 *                    um conjunto padrão automaticamente na primeira
 *                    vez que cadastra um produto, mas esta tela
 *                    permite ver, adicionar e remover livremente.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/UnidadeMedida.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

UnidadeMedida::garantirPadraoParaEmpresa($empresaId);

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'excluir') {
        $id = (int) ($_POST['id'] ?? 0);
        if (UnidadeMedida::estaEmUso($id, $empresaId)) {
            $erro = 'Esta unidade está em uso por algum produto e não pode ser excluída.';
        } else {
            UnidadeMedida::excluir($id, $empresaId);
        }
    } else {
        $nome = limparEntrada($_POST['nome'] ?? '');
        $sigla = limparEntrada($_POST['sigla'] ?? '');

        if ($nome === '' || $sigla === '') {
            $erro = 'Informe o nome e a sigla da unidade (ex.: Quilograma / KG).';
        } else {
            UnidadeMedida::criar($empresaId, $nome, $sigla);
        }
    }
}

$unidades = UnidadeMedida::listarPorEmpresa($empresaId);

$tituloPagina = 'Unidades de medida';
$itemMenuAtivo = 'unidades';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Nova unidade de medida</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/unidades.php">
            <?= csrfCampoOculto() ?>

            <div class="linha-campos">
                <div class="campo">
                    <label for="nome">Nome *</label>
                    <input type="text" id="nome" name="nome" placeholder="Ex.: Quilograma" required>
                </div>
                <div class="campo">
                    <label for="sigla">Sigla *</label>
                    <input type="text" id="sigla" name="sigla" placeholder="Ex.: KG" maxlength="10" required>
                </div>
            </div>

            <button type="submit" class="botao botao--primario">Adicionar</button>
        </form>
    </div>

    <div style="flex:2; min-width:280px;">
        <table class="tabela-padrao">
            <thead><tr><th>Nome</th><th>Sigla</th><th>Ações</th></tr></thead>
            <tbody>
                <?php foreach ($unidades as $u): ?>
                    <tr>
                        <td><?= escapar($u['nome']) ?></td>
                        <td><?= escapar($u['sigla']) ?></td>
                        <td>
                            <form method="POST" action="/admin/unidades.php" style="display:inline;" onsubmit="return confirm('Excluir esta unidade?');">
                                <?= csrfCampoOculto() ?>
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="id" value="<?= (int) $u['id'] ?>">
                                <button type="submit" class="botao--link" style="color:var(--cor-erro);">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($unidades)): ?>
                    <tr><td colspan="3">Nenhuma unidade cadastrada ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
