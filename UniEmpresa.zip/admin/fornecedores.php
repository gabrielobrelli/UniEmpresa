<?php
/**
 * =============================================================
 * ARQUIVO: admin/fornecedores.php
 * RESPONSABILIDADE: cadastro de fornecedores da empresa — usados
 *                    na hora de dar entrada em estoque (seção 19).
 *                    Antes só existia o model, sem nenhuma tela
 *                    para o admin realmente cadastrar um fornecedor.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Fornecedor.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'excluir') {
        Fornecedor::excluir((int) ($_POST['id'] ?? 0), $empresaId);
    } else {
        $nome = limparEntrada($_POST['nome'] ?? '');
        $telefone = limparEntrada($_POST['telefone'] ?? '');
        $email = limparEntrada($_POST['email'] ?? '');
        $observacao = limparEntrada($_POST['observacao'] ?? '');

        if ($nome === '') {
            $erro = 'Informe o nome do fornecedor.';
        } else {
            $novoId = Fornecedor::criar($empresaId, $nome, $telefone ?: null, $email ?: null, $observacao ?: null);
            Auditoria::registrar('fornecedor_criado', 'fornecedores', $novoId);
        }
    }
}

$fornecedores = Fornecedor::listarPorEmpresa($empresaId);

$tituloPagina = 'Fornecedores';
$itemMenuAtivo = 'fornecedores';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Novo fornecedor</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/fornecedores.php">
            <?= csrfCampoOculto() ?>

            <div class="campo">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone">
            </div>
            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email">
            </div>
            <div class="campo">
                <label for="observacao">Observação</label>
                <textarea id="observacao" name="observacao" rows="2"></textarea>
            </div>

            <button type="submit" class="botao botao--primario">Cadastrar fornecedor</button>
        </form>
    </div>

    <div style="flex:2; min-width:320px;">
        <?php if (empty($fornecedores)): ?>
            <?php $mensagemVazia = 'Nenhum fornecedor cadastrado ainda.'; ?>
            <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
        <?php else: ?>
            <table class="tabela-padrao">
                <thead><tr><th>Nome</th><th>Telefone</th><th>E-mail</th><th>Ações</th></tr></thead>
                <tbody>
                    <?php foreach ($fornecedores as $f): ?>
                        <tr>
                            <td><?= escapar($f['nome']) ?></td>
                            <td><?= escapar($f['telefone'] ?? '—') ?></td>
                            <td><?= escapar($f['email'] ?? '—') ?></td>
                            <td>
                                <form method="POST" action="/admin/fornecedores.php" style="display:inline;" onsubmit="return confirm('Excluir este fornecedor?');">
                                    <?= csrfCampoOculto() ?>
                                    <input type="hidden" name="acao" value="excluir">
                                    <input type="hidden" name="id" value="<?= (int) $f['id'] ?>">
                                    <button type="submit" class="botao--link" style="color:var(--cor-erro);">Excluir</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
