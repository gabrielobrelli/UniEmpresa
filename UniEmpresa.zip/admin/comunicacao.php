<?php
/**
 * =============================================================
 * ARQUIVO: admin/comunicacao.php
 * RESPONSABILIDADE: tela de chat do Administrador — conversa com
 *                    outros admins e funcionários da própria
 *                    empresa, e com o Mestre (seção 40).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_ADMIN);

$tituloPagina = 'Chat';
$itemMenuAtivo = 'chat';
require __DIR__ . '/../app/views/layout-inicio.php';
require __DIR__ . '/../app/views/comunicacao-corpo.php';
require __DIR__ . '/../app/views/layout-fim.php';
