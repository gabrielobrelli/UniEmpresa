<?php
/**
 * =============================================================
 * ARQUIVO: admin/jornada.php
 * RESPONSABILIDADE: o administrador controla a própria jornada
 *                    (seção 47 — ele também pode bater ponto) e
 *                    visualiza o status "trabalhando agora" de
 *                    todos os funcionários da empresa.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Jornada.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();
$usuario = Usuario::buscarPorId(usuarioId());

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    if (($_POST['acao'] ?? '') === 'iniciar') {
        Jornada::iniciar($empresaId, usuarioId());
    } elseif (($_POST['acao'] ?? '') === 'encerrar') {
        Jornada::encerrar(usuarioId());
    }

    header('Location: /admin/jornada.php');
    exit;
}

$jornadaAberta = Jornada::buscarAbertaDoUsuario(usuarioId());
$statusEquipe = Jornada::statusHojeTodosDaEmpresa($empresaId);

// Para cada funcionário, calcula um resumo rápido da semana atual,
// já sinalizando quem está abaixo da meta (seção 15: "funcionários
// abaixo da meta de horas").
$periodoSemana = resolverPeriodo('semana');
$resumosEquipe = [];
foreach ($statusEquipe as $membro) {
    $usuarioCompleto = Usuario::buscarPorId((int) $membro['id']);
    $resumosEquipe[$membro['id']] = Jornada::resumoPorUsuario(
        (int) $membro['id'],
        $periodoSemana['inicio'],
        $periodoSemana['fim'],
        (int) $usuarioCompleto['meta_minutos_diarios']
    );
}

$tituloPagina = 'Jornada';
$itemMenuAtivo = 'jornada';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario" style="text-align:center; margin-bottom:24px;">
    <h3 style="margin-top:0;">Minha jornada</h3>
    <?php if ($jornadaAberta): ?>
        <p>Sessão iniciada às <strong><?= formatarData($jornadaAberta['entrada'], true) ?></strong></p>
        <form method="POST" action="/admin/jornada.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="encerrar">
            <button type="submit" class="botao" style="background: var(--cor-erro); color:#fff;">Encerrar sessão</button>
        </form>
    <?php else: ?>
        <form method="POST" action="/admin/jornada.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="iniciar">
            <button type="submit" class="botao botao--primario">Iniciar sessão de serviço</button>
        </form>
    <?php endif; ?>
</div>

<h3>Equipe — status de hoje e resumo da semana</h3>
<table class="tabela-padrao">
    <thead>
        <tr><th>Funcionário</th><th>Cargo</th><th>Status agora</th><th>Horas na semana</th><th>Situação</th></tr>
    </thead>
    <tbody>
        <?php foreach ($statusEquipe as $membro): ?>
            <?php $resumo = $resumosEquipe[$membro['id']]; ?>
            <tr>
                <td><?= escapar($membro['nome']) ?></td>
                <td><?= escapar($membro['cargo'] ?? '—') ?></td>
                <td>
                    <?php if ($membro['entrada_aberta']): ?>
                        <span class="badge badge--verde">Trabalhando</span>
                    <?php else: ?>
                        <span class="badge badge--cinza">Fora do expediente</span>
                    <?php endif; ?>
                </td>
                <td><?= minutosParaHoras($resumo['minutos_trabalhados']) ?> / <?= minutosParaHoras($resumo['minutos_previstos']) ?></td>
                <td>
                    <?php if ($resumo['diferenca_minutos'] < 0): ?>
                        <span class="badge badge--amarelo">Abaixo da meta</span>
                    <?php else: ?>
                        <span class="badge badge--verde">Dentro da meta</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($statusEquipe)): ?>
            <tr><td colspan="5">Nenhum funcionário cadastrado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
