<?php
/**
 * =============================================================
 * ARQUIVO: admin/backup-download.php
 * RESPONSABILIDADE: liberar o download de um backup, SEMPRE
 *                    validando que o administrador logado pertence
 *                    à empresa dona do arquivo (seção 95: backup
 *                    nunca fica acessível por URL previsível/pública).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$nomeArquivo = basename($_GET['arquivo'] ?? '');

// basename() já remove qualquer tentativa de "../" no nome do arquivo,
// mas confirmamos explicitamente que o resultado não contém separador
// de diretório, como camada extra contra path traversal.
if ($nomeArquivo === '' || str_contains($nomeArquivo, '/') || str_contains($nomeArquivo, '\\')) {
    http_response_code(400);
    die('Arquivo inválido.');
}

$caminhoCompleto = __DIR__ . '/../storage/backups/empresas/' . $empresaId . '/' . $nomeArquivo;

// A pasta do backup é nomeada com o empresa_id da SESSÃO (nunca de um
// parâmetro da URL), então um admin da Empresa 1 fisicamente não
// consegue montar um caminho que aponte para a pasta da Empresa 2.
if (!is_file($caminhoCompleto)) {
    http_response_code(404);
    die('Backup não encontrado.');
}

Auditoria::registrar('backup_empresa_baixado', 'empresas', $empresaId, null, ['arquivo' => $nomeArquivo]);

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $nomeArquivo . '"');
header('Content-Length: ' . filesize($caminhoCompleto));
readfile($caminhoCompleto);
exit;
