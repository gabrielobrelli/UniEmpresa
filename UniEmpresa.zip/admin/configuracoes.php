<?php
/**
 * =============================================================
 * ARQUIVO: admin/configuracoes.php
 * RESPONSABILIDADE: central de configurações da empresa (seção 83)
 *                    — dados de contato do dia a dia, e atalhos para
 *                    as demais áreas de configuração já existentes
 *                    (personalização visual, funcionários, backup).
 *
 * Este arquivo estava referenciado no menu lateral, mas nunca havia
 * sido criado — é por isso que o link dava 404.
 *
 * Os dados cadastrais oficiais (razão social, CNPJ/CPF, segmento)
 * continuam só editáveis pelo Mestre em mestre/empresa-form.php —
 * aqui o admin ajusta apenas o contato usado no dia a dia.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $dados = [
        'telefone' => limparEntrada($_POST['telefone'] ?? ''),
        'whatsapp' => limparEntrada($_POST['whatsapp'] ?? ''),
        'email' => limparEntrada($_POST['email'] ?? ''),
        'endereco' => limparEntrada($_POST['endereco'] ?? ''),
        'cidade' => limparEntrada($_POST['cidade'] ?? ''),
        'estado' => strtoupper(limparEntrada($_POST['estado'] ?? '')),
        'cep' => limparEntrada($_POST['cep'] ?? ''),
    ];

    Empresa::atualizarContato($empresaId, $dados);
    Auditoria::registrar('configuracoes_contato_atualizadas', 'empresas', $empresaId);
    $sucesso = true;
}

$empresa = Empresa::buscarPorId($empresaId);

$tituloPagina = 'Configurações';
$itemMenuAtivo = 'configuracoes';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:300px;">
        <h3 style="margin-top:0;">Dados de contato</h3>
        <p style="font-size:13px; color:var(--cor-texto-suave); margin-top:-8px;">
            Razão social, nome fantasia e CNPJ/CPF são dados cadastrais oficiais e só podem
            ser alterados pelo suporte da plataforma. Aqui você atualiza apenas o contato do dia a dia.
        </p>

        <?php if ($sucesso): ?>
            <div class="alerta alerta--sucesso">Dados de contato atualizados com sucesso!</div>
        <?php endif; ?>

        <form method="POST" action="/admin/configuracoes.php">
            <?= csrfCampoOculto() ?>

            <div class="linha-campos">
                <div class="campo">
                    <label for="telefone">Telefone</label>
                    <input type="text" id="telefone" name="telefone" value="<?= escapar($empresa['telefone'] ?? '') ?>">
                </div>
                <div class="campo">
                    <label for="whatsapp">WhatsApp</label>
                    <input type="text" id="whatsapp" name="whatsapp" value="<?= escapar($empresa['whatsapp'] ?? '') ?>">
                </div>
            </div>

            <div class="campo">
                <label for="email">E-mail de contato</label>
                <input type="email" id="email" name="email" value="<?= escapar($empresa['email'] ?? '') ?>">
            </div>

            <div class="campo">
                <label for="endereco">Endereço</label>
                <input type="text" id="endereco" name="endereco" value="<?= escapar($empresa['endereco'] ?? '') ?>">
            </div>

            <div class="linha-campos">
                <div class="campo">
                    <label for="cidade">Cidade</label>
                    <input type="text" id="cidade" name="cidade" value="<?= escapar($empresa['cidade'] ?? '') ?>">
                </div>
                <div class="campo">
                    <label for="estado">UF</label>
                    <input type="text" id="estado" name="estado" maxlength="2" value="<?= escapar($empresa['estado'] ?? '') ?>">
                </div>
            </div>

            <div class="campo">
                <label for="cep">CEP</label>
                <input type="text" id="cep" name="cep" value="<?= escapar($empresa['cep'] ?? '') ?>">
            </div>

            <button type="submit" class="botao botao--primario">Salvar contato</button>
        </form>
    </div>

    <div style="flex:1; min-width:260px; display:flex; flex-direction:column; gap:16px;">
        <div class="cartao-formulario">
            <h3 style="margin-top:0;">Outras configurações</h3>
            <p style="font-size:14px;">
                <a href="/admin/personalizacao.php">🎨 Personalização visual (cores, logo, textos)</a>
            </p>
            <p style="font-size:14px;">
                <a href="/admin/funcionarios.php">👥 Funcionários e permissões</a>
            </p>
            <p style="font-size:14px;">
                <a href="/admin/categorias.php">🏷️ Categorias de produtos</a>
            </p>
            <p style="font-size:14px;">
                <a href="/admin/backup.php">💾 Backup dos dados da empresa</a>
            </p>
        </div>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
