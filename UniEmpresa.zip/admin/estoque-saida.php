<?php
/**
 * =============================================================
 * ARQUIVO: admin/estoque-saida.php
 * RESPONSABILIDADE: registrar saídas manuais de estoque que NÃO
 *                    vêm de uma venda (ajuste, perda, avaria, uso
 *                    interno, devolução ao fornecedor — seção 20).
 *                    A saída por venda é tratada automaticamente
 *                    dentro do fluxo do PDV, não nesta tela.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/MovimentacaoEstoque.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$produtoSelecionadoId = (int) ($_GET['produto_id'] ?? $_POST['produto_id'] ?? 0);
$erro = null;
$sucesso = false;

$motivosPermitidos = ['ajuste', 'perda', 'avaria', 'uso_interno', 'devolucao', 'outro'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $produtoId = (int) ($_POST['produto_id'] ?? 0);
    $quantidade = (float) str_replace(',', '.', $_POST['quantidade'] ?? '0');
    $motivo = $_POST['motivo'] ?? '';
    $observacao = limparEntrada($_POST['observacao'] ?? '');

    $produto = Produto::buscarPorId($produtoId, $empresaId);

    if (!$produto) {
        $erro = 'Produto não encontrado.';
    } elseif ($quantidade <= 0) {
        $erro = 'Informe uma quantidade maior que zero.';
    } elseif (!in_array($motivo, $motivosPermitidos, true)) {
        $erro = 'Selecione um motivo válido.';
    } else {
        try {
            MovimentacaoEstoque::registrarSaida(
                $produtoId,
                $empresaId,
                $quantidade,
                $motivo,
                usuarioId(),
                null,
                $observacao
            );

            Auditoria::registrar('estoque_saida', 'produtos', $produtoId, null, [
                'quantidade' => $quantidade,
                'motivo' => $motivo,
            ]);

            $sucesso = true;
        } catch (RuntimeException $e) {
            // Mensagem de negócio (ex.: estoque insuficiente) pode ser
            // exibida diretamente, pois já foi escrita pensando no usuário.
            $erro = $e->getMessage();
        } catch (Throwable $e) {
            $erro = 'Não foi possível registrar a saída. Tente novamente.';
            error_log('[estoque-saida] ' . $e->getMessage());
        }
    }
}

$produtos = Produto::listarPorEmpresa($empresaId, '', 1, 500);

$tituloPagina = 'Saída de estoque';
$itemMenuAtivo = 'estoque';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>
    <?php if ($sucesso): ?>
        <div class="alerta alerta--sucesso">Saída registrada e estoque atualizado com sucesso!</div>
    <?php endif; ?>

    <form method="POST" action="/admin/estoque-saida.php">
        <?= csrfCampoOculto() ?>

        <div class="campo">
            <label for="produto_id">Produto *</label>
            <select id="produto_id" name="produto_id" required>
                <option value="">— Selecione —</option>
                <?php foreach ($produtos as $produto): ?>
                    <option value="<?= (int) $produto['id'] ?>" <?= $produtoSelecionadoId == $produto['id'] ? 'selected' : '' ?>>
                        <?= escapar($produto['nome']) ?> (estoque atual: <?= rtrim(rtrim(number_format((float) $produto['estoque_atual'], 3, ',', '.'), '0'), ',') ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="quantidade">Quantidade *</label>
                <input type="text" id="quantidade" name="quantidade" required>
            </div>
            <div class="campo">
                <label for="motivo">Motivo *</label>
                <select id="motivo" name="motivo" required>
                    <option value="ajuste">Ajuste</option>
                    <option value="perda">Perda</option>
                    <option value="avaria">Avaria</option>
                    <option value="uso_interno">Uso interno</option>
                    <option value="devolucao">Devolução ao fornecedor</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
        </div>

        <div class="campo">
            <label for="observacao">Observação</label>
            <textarea id="observacao" name="observacao" rows="2"></textarea>
        </div>

        <button type="submit" class="botao" style="background: var(--cor-erro); color:#fff;">Registrar saída</button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
