<?php
/**
 * =============================================================
 * ARQUIVO: admin/backup.php
 * RESPONSABILIDADE: o administrador gera um backup contendo
 *                    APENAS o SQL dos dados da PRÓPRIA empresa
 *                    (seção 53) — diferente do backup global do
 *                    Mestre, aqui é somente o banco de dados,
 *                    filtrado por empresa_id, em um único arquivo
 *                    .sql (mais simples de guardar/reimportar).
 *                    O arquivo fica salvo fora da pasta pública
 *                    (em /storage, bloqueada por .htaccess) e só
 *                    pode ser baixado através de
 *                    admin/backup-download.php, que confere sessão
 *                    e propriedade do arquivo antes de liberá-lo.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$pastaBackups = __DIR__ . '/../storage/backups/empresas/' . $empresaId;
$erro = null;

/**
 * FUNÇÃO: tabelasDaEmpresa()
 * O QUE FAZ: lista as tabelas que compõem o backup de uma empresa
 *            — apenas as que possuem dado próprio da empresa
 *            (seção 53: administradores, funcionários, produtos,
 *            categorias, estoque, vendas, financeiro, jornada,
 *            configurações).
 * FIM DA FUNÇÃO
 */
function tabelasDaEmpresa(): array
{
    return [
        'usuarios', 'categorias', 'unidades_medida', 'fornecedores', 'produtos',
        'movimentacoes_estoque', 'clientes', 'vendas', 'venda_itens', 'venda_pagamentos',
        'movimentacoes_financeiras', 'jornadas', 'lembretes', 'feedbacks', 'configuracoes_empresa',
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'gerar') {
    csrfValidarOuFalhar();

    if (!is_dir($pastaBackups)) {
        mkdir($pastaBackups, 0755, true);
    }

    $pdo = getPDO();

    // Dados da própria empresa (linha única, sem filtro de empresa_id
    // porque a tabela `empresas` guarda uma empresa por linha).
    $stmt = $pdo->prepare('SELECT * FROM empresas WHERE id = :id');
    $stmt->execute([':id' => $empresaId]);
    $dadosEmpresa = $stmt->fetch();

    $dump = "-- Backup dos dados da empresa: " . $dadosEmpresa['nome_fantasia'] . "\n"
        . "-- Gerado em " . date('d/m/Y H:i:s') . "\n"
        . "-- Contém APENAS dados desta empresa — nenhuma outra empresa está incluída.\n\n";

    $dump .= "-- Dados cadastrais da empresa\n"
        . 'INSERT INTO `empresas` (`' . implode('`, `', array_keys($dadosEmpresa)) . '`) VALUES ('
        . implode(', ', array_map(fn($v) => $v === null ? 'NULL' : $pdo->quote((string) $v), $dadosEmpresa))
        . ");\n\n";

    // Uma tabela por vez, sempre filtrada por empresa_id — garante que
    // nenhum dado de outra empresa entre no arquivo.
    foreach (tabelasDaEmpresa() as $tabela) {
        $dump .= dumpTabelaComoSql($pdo, $tabela, $empresaId);
    }

    $nomeArquivo = 'backup_' . date('Y-m-d_His') . '.sql';
    file_put_contents($pastaBackups . '/' . $nomeArquivo, $dump);

    Auditoria::registrar('backup_empresa_gerado', 'empresas', $empresaId, null, ['arquivo' => $nomeArquivo]);
}

// Lista os backups já existentes, mais recente primeiro.
$backupsExistentes = [];
if (is_dir($pastaBackups)) {
    $arquivosNaPasta = scandir($pastaBackups, SCANDIR_SORT_DESCENDING);
    foreach ($arquivosNaPasta as $arquivo) {
        if ($arquivo !== '.' && $arquivo !== '..') {
            $backupsExistentes[] = $arquivo;
        }
    }
}

$tituloPagina = 'Backup';
$itemMenuAtivo = 'backup';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario" style="margin-bottom: 24px;">
    <p>Gera um único arquivo <strong>.sql</strong> contendo exclusivamente os dados da sua empresa. Nenhum dado de outra empresa é incluído.</p>
    <form method="POST" action="/admin/backup.php">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="acao" value="gerar">
        <button type="submit" class="botao botao--primario">Gerar novo backup</button>
    </form>
</div>

<table class="tabela-padrao">
    <thead><tr><th>Arquivo</th><th>Ações</th></tr></thead>
    <tbody>
        <?php foreach ($backupsExistentes as $arquivo): ?>
            <tr>
                <td><?= escapar($arquivo) ?></td>
                <td><a href="/admin/backup-download.php?arquivo=<?= urlencode($arquivo) ?>">Baixar</a></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($backupsExistentes)): ?>
            <tr><td colspan="2">Nenhum backup gerado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
