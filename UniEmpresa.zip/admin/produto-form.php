<?php
/**
 * =============================================================
 * ARQUIVO: admin/produto-form.php
 * RESPONSABILIDADE: uma única tela para CRIAR ou EDITAR um produto
 *                    da empresa do administrador logado.
 * IMPORTANTE: este formulário NUNCA altera `estoque_atual` — a
 *             quantidade em estoque só muda através das telas de
 *             entrada/saída (app/models/MovimentacaoEstoque.php),
 *             para que toda alteração gere histórico.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/Categoria.php';
require_once __DIR__ . '/../app/models/UnidadeMedida.php';
require_once __DIR__ . '/../app/models/Fornecedor.php';
require_once __DIR__ . '/../app/models/MovimentacaoEstoque.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

// Garante que a empresa tenha ao menos as unidades de medida padrão
// na primeira vez que um admin acessa o cadastro de produtos.
UnidadeMedida::garantirPadraoParaEmpresa($empresaId);

$produtoId = isset($_GET['id']) ? (int) $_GET['id'] : null;
$produto = $produtoId ? Produto::buscarPorId($produtoId, $empresaId) : null;

if ($produtoId && !$produto) {
    http_response_code(404);
    die('Produto não encontrado.');
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $dados = [
        'categoria_id' => (int) ($_POST['categoria_id'] ?? 0) ?: null,
        'unidade_id' => (int) ($_POST['unidade_id'] ?? 0) ?: null,
        'fornecedor_id' => (int) ($_POST['fornecedor_id'] ?? 0) ?: null,
        'codigo' => limparEntrada($_POST['codigo'] ?? ''),
        'codigo_barras' => limparEntrada($_POST['codigo_barras'] ?? ''),
        'nome' => limparEntrada($_POST['nome'] ?? ''),
        'descricao' => limparEntrada($_POST['descricao'] ?? ''),
        'preco_custo' => (float) str_replace(',', '.', $_POST['preco_custo'] ?? '0'),
        'preco_venda' => (float) str_replace(',', '.', $_POST['preco_venda'] ?? '0'),
        'estoque_minimo' => (float) str_replace(',', '.', $_POST['estoque_minimo'] ?? '0'),
        'estoque_maximo' => $_POST['estoque_maximo'] !== '' ? (float) str_replace(',', '.', $_POST['estoque_maximo']) : null,
        'permite_estoque_negativo' => !empty($_POST['permite_estoque_negativo']),
        'status' => $_POST['status'] ?? 'ativo',
    ];

    // Só existe no formulário de CADASTRO (produto novo) — permite dar
    // entrada no estoque já no mesmo passo, sem precisar ir depois em
    // "Estoque > Entrada de estoque" separadamente.
    $estoqueInicial = (float) str_replace(',', '.', $_POST['estoque_inicial'] ?? '0');

    if ($dados['nome'] === '') {
        $erro = 'O nome do produto é obrigatório.';
    } else {
        try {
            if ($produtoId) {
                Produto::atualizar($produtoId, $empresaId, $dados);
                Auditoria::registrar('produto_atualizado', 'produtos', $produtoId, null, $dados);
            } else {
                $produtoId = Produto::criar($empresaId, $dados);
                Auditoria::registrar('produto_criado', 'produtos', $produtoId, null, $dados);

                // Estoque inicial informado no próprio cadastro — evita
                // o admin precisar ir numa segunda tela só para isso.
                if ($estoqueInicial > 0) {
                    MovimentacaoEstoque::registrarEntrada(
                        $produtoId,
                        $empresaId,
                        $estoqueInicial,
                        $dados['preco_custo'] ?: null,
                        usuarioId(),
                        $dados['fornecedor_id'],
                        'Estoque inicial informado no cadastro do produto'
                    );
                }
            }

            if (!empty($_FILES['foto']['name'])) {
                $caminhoFoto = salvarImagemEnviada($_FILES['foto'], 'produtos/' . $empresaId);
                if ($caminhoFoto) {
                    Produto::atualizarFoto($produtoId, $empresaId, $caminhoFoto);
                }
            }

            header('Location: /admin/produtos.php');
            exit;
        } catch (RuntimeException $e) {
            $erro = $e->getMessage();
        }
    }

    $produto = array_merge($produto ?? [], $dados);
}

$categorias = Categoria::listarPorEmpresa($empresaId);
$unidades = UnidadeMedida::listarPorEmpresa($empresaId);
$fornecedores = Fornecedor::listarPorEmpresa($empresaId);

$tituloPagina = $produtoId ? 'Editar produto' : 'Novo produto';
$itemMenuAtivo = 'produtos';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario" style="max-width: 720px;">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>

    <form method="POST" action="/admin/produto-form.php<?= $produtoId ? '?id=' . $produtoId : '' ?>" enctype="multipart/form-data">
        <?= csrfCampoOculto() ?>

        <div class="campo">
            <label for="nome">Nome do produto *</label>
            <input type="text" id="nome" name="nome" required value="<?= escapar($produto['nome'] ?? '') ?>">
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="codigo">Código interno</label>
                <input type="text" id="codigo" name="codigo" value="<?= escapar($produto['codigo'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="codigo_barras">Código de barras</label>
                <input type="text" id="codigo_barras" name="codigo_barras" value="<?= escapar($produto['codigo_barras'] ?? '') ?>">
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="categoria_id">Categoria</label>
                <select id="categoria_id" name="categoria_id">
                    <option value="">— Nenhuma —</option>
                    <?php foreach ($categorias as $cat): ?>
                        <option value="<?= (int) $cat['id'] ?>" <?= (($produto['categoria_id'] ?? null) == $cat['id']) ? 'selected' : '' ?>>
                            <?= $cat['categoria_pai_id'] ? '— ' : '' ?><?= escapar($cat['nome']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="unidade_id">Unidade de medida</label>
                <select id="unidade_id" name="unidade_id">
                    <?php foreach ($unidades as $un): ?>
                        <option value="<?= (int) $un['id'] ?>" <?= (($produto['unidade_id'] ?? null) == $un['id']) ? 'selected' : '' ?>>
                            <?= escapar($un['nome']) ?> (<?= escapar($un['sigla']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="campo">
            <label for="fornecedor_id">Fornecedor</label>
            <select id="fornecedor_id" name="fornecedor_id">
                <option value="">— Nenhum —</option>
                <?php foreach ($fornecedores as $forn): ?>
                    <option value="<?= (int) $forn['id'] ?>" <?= (($produto['fornecedor_id'] ?? null) == $forn['id']) ? 'selected' : '' ?>>
                        <?= escapar($forn['nome']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="preco_custo">Preço de custo (R$)</label>
                <input type="text" id="preco_custo" name="preco_custo" value="<?= escapar((string) ($produto['preco_custo'] ?? '0')) ?>">
            </div>
            <div class="campo">
                <label for="preco_venda">Preço de venda (R$)</label>
                <input type="text" id="preco_venda" name="preco_venda" value="<?= escapar((string) ($produto['preco_venda'] ?? '0')) ?>">
            </div>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="estoque_minimo">Estoque mínimo</label>
                <input type="text" id="estoque_minimo" name="estoque_minimo" value="<?= escapar((string) ($produto['estoque_minimo'] ?? '0')) ?>">
            </div>
            <div class="campo">
                <label for="estoque_maximo">Estoque máximo (opcional)</label>
                <input type="text" id="estoque_maximo" name="estoque_maximo" value="<?= escapar((string) ($produto['estoque_maximo'] ?? '')) ?>">
            </div>
        </div>

        <?php if ($produtoId): ?>
            <div class="alerta alerta--info" style="font-size:13px;">
                Estoque atual: <strong><?= escapar((string) $produto['estoque_atual']) ?></strong>.
                Para adicionar ou remover quantidade, use
                <a href="/admin/estoque-entrada.php?produto_id=<?= $produtoId ?>">+ Entrada de estoque</a>
                ou <a href="/admin/estoque-saida.php?produto_id=<?= $produtoId ?>">− Saída de estoque</a>.
            </div>
        <?php else: ?>
            <div class="linha-campos" style="background:#f0fdf4; padding:14px; border-radius:var(--raio-padrao); margin-bottom:16px;">
                <div class="campo" style="margin-bottom:0;">
                    <label for="estoque_inicial">Quantidade inicial em estoque (opcional)</label>
                    <input type="text" id="estoque_inicial" name="estoque_inicial" placeholder="Ex.: 10">
                </div>
                <div class="campo" style="margin-bottom:0;">
                    <label>&nbsp;</label>
                    <span style="font-size:12.5px; color:var(--cor-texto-suave);">
                        Se preencher, já entra automaticamente no estoque ao salvar — sem precisar de uma segunda tela.
                    </span>
                </div>
            </div>
        <?php endif; ?>

        <div class="campo">
            <label>
                <input type="checkbox" name="permite_estoque_negativo" value="1" <?= !empty($produto['permite_estoque_negativo']) ? 'checked' : '' ?>>
                Permitir estoque negativo para este produto
            </label>
        </div>

        <div class="campo">
            <label for="descricao">Descrição</label>
            <textarea id="descricao" name="descricao" rows="3"><?= escapar($produto['descricao'] ?? '') ?></textarea>
        </div>

        <div class="campo">
            <label for="foto">Foto do produto</label>
            <input type="file" id="foto" name="foto" accept=".jpg,.jpeg,.png,.webp">
        </div>

        <div class="campo">
            <label for="status">Status</label>
            <select id="status" name="status">
                <option value="ativo" <?= (($produto['status'] ?? 'ativo') === 'ativo') ? 'selected' : '' ?>>Ativo</option>
                <option value="inativo" <?= (($produto['status'] ?? '') === 'inativo') ? 'selected' : '' ?>>Inativo</option>
            </select>
        </div>

        <button type="submit" class="botao botao--primario"><?= $produtoId ? 'Salvar alterações' : 'Cadastrar produto' ?></button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
