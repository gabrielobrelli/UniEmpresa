<?php
/**
 * =============================================================
 * ARQUIVO: admin/clientes.php
 * RESPONSABILIDADE: cadastro de clientes da empresa (seção 27) —
 *                    listar, criar, editar e excluir (soft delete).
 *                    Este arquivo estava referenciado no menu
 *                    lateral, mas nunca havia sido criado.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Cliente.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;
$editando = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();
    $acao = $_POST['acao'] ?? '';

    if ($acao === 'excluir') {
        Cliente::excluir((int) ($_POST['id'] ?? 0), $empresaId);
        Auditoria::registrar('cliente_excluido', 'clientes', (int) $_POST['id']);
    } else {
        $dados = [
            'nome' => limparEntrada($_POST['nome'] ?? ''),
            'cpf_cnpj' => limparEntrada($_POST['cpf_cnpj'] ?? ''),
            'telefone' => limparEntrada($_POST['telefone'] ?? ''),
            'email' => limparEntrada($_POST['email'] ?? ''),
            'observacao' => limparEntrada($_POST['observacao'] ?? ''),
        ];

        if ($dados['nome'] === '') {
            $erro = 'Informe o nome do cliente.';
        } elseif ($acao === 'editar') {
            $clienteId = (int) ($_POST['id'] ?? 0);
            Cliente::atualizar($clienteId, $empresaId, $dados);
            Auditoria::registrar('cliente_atualizado', 'clientes', $clienteId);
        } else {
            $novoId = Cliente::criar($empresaId, $dados);
            Auditoria::registrar('cliente_criado', 'clientes', $novoId);
        }
    }
}

if (isset($_GET['editar'])) {
    $editando = Cliente::buscarPorId((int) $_GET['editar'], $empresaId);
}

$busca = limparEntrada($_GET['busca'] ?? '');
$clientes = Cliente::listarPorEmpresa($empresaId, $busca);

$tituloPagina = 'Clientes';
$itemMenuAtivo = 'clientes';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;"><?= $editando ? 'Editar cliente' : 'Novo cliente' ?></h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/clientes.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="<?= $editando ? 'editar' : 'criar' ?>">
            <?php if ($editando): ?>
                <input type="hidden" name="id" value="<?= (int) $editando['id'] ?>">
            <?php endif; ?>

            <div class="campo">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" required value="<?= escapar($editando['nome'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="cpf_cnpj">CPF/CNPJ</label>
                <input type="text" id="cpf_cnpj" name="cpf_cnpj" value="<?= escapar($editando['cpf_cnpj'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="telefone">Telefone</label>
                <input type="text" id="telefone" name="telefone" value="<?= escapar($editando['telefone'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="email">E-mail</label>
                <input type="email" id="email" name="email" value="<?= escapar($editando['email'] ?? '') ?>">
            </div>
            <div class="campo">
                <label for="observacao">Observação</label>
                <textarea id="observacao" name="observacao" rows="2"><?= escapar($editando['observacao'] ?? '') ?></textarea>
            </div>

            <button type="submit" class="botao botao--primario"><?= $editando ? 'Salvar alterações' : 'Cadastrar cliente' ?></button>
            <?php if ($editando): ?>
                <a href="/admin/clientes.php" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Cancelar</a>
            <?php endif; ?>
        </form>
    </div>

    <div style="flex:2; min-width:320px;">
        <form method="GET" action="/admin/clientes.php" class="barra-filtros" style="margin-bottom:16px;">
            <input type="text" name="busca" placeholder="Buscar por nome ou CPF/CNPJ" value="<?= escapar($busca) ?>" class="barra-filtros__busca">
            <button type="submit" class="botao botao--primario">Buscar</button>
        </form>

        <?php if (empty($clientes)): ?>
            <?php $mensagemVazia = $busca ? 'Nenhum cliente encontrado para essa busca.' : 'Nenhum cliente cadastrado ainda.'; ?>
            <?php require __DIR__ . '/../app/views/estado-vazio.php'; ?>
        <?php else: ?>
            <table class="tabela-padrao">
                <thead><tr><th>Nome</th><th>Telefone</th><th>CPF/CNPJ</th><th>Ações</th></tr></thead>
                <tbody>
                    <?php foreach ($clientes as $cliente): ?>
                        <tr>
                            <td><?= escapar($cliente['nome']) ?></td>
                            <td><?= escapar($cliente['telefone'] ?? '—') ?></td>
                            <td><?= escapar($cliente['cpf_cnpj'] ?? '—') ?></td>
                            <td>
                                <a href="/admin/clientes.php?editar=<?= (int) $cliente['id'] ?>">Editar</a>
                                &nbsp;|&nbsp;
                                <form method="POST" action="/admin/clientes.php" style="display:inline;" onsubmit="return confirm('Excluir este cliente?');">
                                    <?= csrfCampoOculto() ?>
                                    <input type="hidden" name="acao" value="excluir">
                                    <input type="hidden" name="id" value="<?= (int) $cliente['id'] ?>">
                                    <button type="submit" style="border:none;background:none;color:var(--cor-erro);cursor:pointer;padding:0;">Excluir</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
