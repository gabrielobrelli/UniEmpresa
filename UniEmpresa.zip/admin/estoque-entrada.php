<?php
/**
 * =============================================================
 * ARQUIVO: admin/estoque-entrada.php
 * RESPONSABILIDADE: registrar entrada de produtos no estoque
 *                    (compra, ajuste positivo, devolução recebida
 *                    etc. — seção 19 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/Fornecedor.php';
require_once __DIR__ . '/../app/models/MovimentacaoEstoque.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$produtoSelecionadoId = (int) ($_GET['produto_id'] ?? $_POST['produto_id'] ?? 0);
$erro = null;
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $produtoId = (int) ($_POST['produto_id'] ?? 0);
    $quantidade = (float) str_replace(',', '.', $_POST['quantidade'] ?? '0');
    $valorUnitario = $_POST['valor_unitario'] !== '' ? (float) str_replace(',', '.', $_POST['valor_unitario']) : null;
    $fornecedorId = (int) ($_POST['fornecedor_id'] ?? 0) ?: null;
    $observacao = limparEntrada($_POST['observacao'] ?? '');

    $produto = Produto::buscarPorId($produtoId, $empresaId);

    if (!$produto) {
        $erro = 'Produto não encontrado.';
    } elseif ($quantidade <= 0) {
        $erro = 'Informe uma quantidade maior que zero.';
    } else {
        try {
            MovimentacaoEstoque::registrarEntrada(
                $produtoId,
                $empresaId,
                $quantidade,
                $valorUnitario,
                usuarioId(),
                $fornecedorId,
                $observacao
            );

            Auditoria::registrar('estoque_entrada', 'produtos', $produtoId, null, [
                'quantidade' => $quantidade,
                'valor_unitario' => $valorUnitario,
            ]);

            $sucesso = true;
        } catch (Throwable $e) {
            $erro = 'Não foi possível registrar a entrada. Tente novamente.';
            error_log('[estoque-entrada] ' . $e->getMessage());
        }
    }
}

$produtos = Produto::listarPorEmpresa($empresaId, '', 1, 500);
$fornecedores = Fornecedor::listarPorEmpresa($empresaId);

$tituloPagina = 'Entrada de estoque';
$itemMenuAtivo = 'estoque';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="cartao-formulario">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>
    <?php if ($sucesso): ?>
        <div class="alerta alerta--sucesso">Entrada registrada e estoque atualizado com sucesso!</div>
    <?php endif; ?>

    <form method="POST" action="/admin/estoque-entrada.php">
        <?= csrfCampoOculto() ?>

        <div class="campo">
            <label for="produto_id">Produto *</label>
            <select id="produto_id" name="produto_id" required>
                <option value="">— Selecione —</option>
                <?php foreach ($produtos as $produto): ?>
                    <option value="<?= (int) $produto['id'] ?>" <?= $produtoSelecionadoId == $produto['id'] ? 'selected' : '' ?>>
                        <?= escapar($produto['nome']) ?> (estoque atual: <?= rtrim(rtrim(number_format((float) $produto['estoque_atual'], 3, ',', '.'), '0'), ',') ?>)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="linha-campos">
            <div class="campo">
                <label for="quantidade">Quantidade *</label>
                <input type="text" id="quantidade" name="quantidade" required>
            </div>
            <div class="campo">
                <label for="valor_unitario">Valor unitário de custo (R$)</label>
                <input type="text" id="valor_unitario" name="valor_unitario">
            </div>
        </div>

        <div class="campo">
            <label for="fornecedor_id">Fornecedor</label>
            <select id="fornecedor_id" name="fornecedor_id">
                <option value="">— Nenhum —</option>
                <?php foreach ($fornecedores as $forn): ?>
                    <option value="<?= (int) $forn['id'] ?>"><?= escapar($forn['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="campo">
            <label for="observacao">Observação</label>
            <textarea id="observacao" name="observacao" rows="2"></textarea>
        </div>

        <button type="submit" class="botao botao--primario">Registrar entrada</button>
    </form>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
