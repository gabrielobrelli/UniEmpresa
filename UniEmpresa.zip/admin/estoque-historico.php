<?php
/**
 * =============================================================
 * ARQUIVO: admin/estoque-historico.php
 * RESPONSABILIDADE: exibir o histórico de todas as movimentações
 *                    de estoque da empresa, com filtros por produto
 *                    e período (seção 21 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/MovimentacaoEstoque.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$produtoFiltro = (int) ($_GET['produto_id'] ?? 0) ?: null;
$dataInicio = limparEntrada($_GET['data_inicio'] ?? '');
$dataFim = limparEntrada($_GET['data_fim'] ?? '');

$movimentacoes = MovimentacaoEstoque::historico(
    $empresaId,
    $produtoFiltro,
    $dataInicio ?: null,
    $dataFim ?: null
);

$produtos = Produto::listarPorEmpresa($empresaId, '', 1, 500);

$tituloPagina = 'Histórico de estoque';
$itemMenuAtivo = 'estoque';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<form method="GET" action="/admin/estoque-historico.php" class="linha-campos nao-imprimir" style="margin-bottom: 20px; align-items:end;">
    <div class="campo">
        <label for="produto_id">Produto</label>
        <select id="produto_id" name="produto_id">
            <option value="">Todos</option>
            <?php foreach ($produtos as $produto): ?>
                <option value="<?= (int) $produto['id'] ?>" <?= $produtoFiltro == $produto['id'] ? 'selected' : '' ?>>
                    <?= escapar($produto['nome']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="campo">
        <label for="data_inicio">De</label>
        <input type="date" id="data_inicio" name="data_inicio" value="<?= escapar($dataInicio) ?>">
    </div>
    <div class="campo">
        <label for="data_fim">Até</label>
        <input type="date" id="data_fim" name="data_fim" value="<?= escapar($dataFim) ?>">
    </div>
    <div class="campo">
        <button type="submit" class="botao botao--primario">Filtrar</button>
    </div>
</form>

<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Data/hora</th>
            <th>Produto</th>
            <th>Tipo</th>
            <th>Motivo</th>
            <th>Qtd. anterior</th>
            <th>Qtd. movimentada</th>
            <th>Qtd. posterior</th>
            <th>Usuário</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($movimentacoes as $mov): ?>
            <tr>
                <td><?= formatarData($mov['created_at'], true) ?></td>
                <td><?= escapar($mov['produto_nome']) ?></td>
                <td>
                    <?php if ($mov['tipo'] === 'entrada'): ?>
                        <span class="badge badge--verde">Entrada</span>
                    <?php else: ?>
                        <span class="badge badge--vermelho">Saída</span>
                    <?php endif; ?>
                </td>
                <td><?= escapar($mov['motivo']) ?></td>
                <td><?= rtrim(rtrim(number_format((float) $mov['quantidade_anterior'], 3, ',', '.'), '0'), ',') ?></td>
                <td><?= rtrim(rtrim(number_format((float) $mov['quantidade_movimentada'], 3, ',', '.'), '0'), ',') ?></td>
                <td><?= rtrim(rtrim(number_format((float) $mov['quantidade_posterior'], 3, ',', '.'), '0'), ',') ?></td>
                <td><?= escapar($mov['usuario_nome']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($movimentacoes)): ?>
            <tr><td colspan="8">Nenhuma movimentação encontrada para o filtro selecionado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
