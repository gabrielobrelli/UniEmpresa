<?php
/**
 * =============================================================
 * ARQUIVO: admin/estoque.php
 * RESPONSABILIDADE: painel geral do estoque — lista todos os
 *                    produtos com sua quantidade atual e destaca
 *                    os que estão com estoque baixo ou esgotado.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$produtosEstoqueBaixo = Produto::listarEstoqueBaixo($empresaId);
$todosProdutos = Produto::listarPorEmpresa($empresaId, '', 1, 100);

$tituloPagina = 'Estoque';
$itemMenuAtivo = 'estoque';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; justify-content: flex-end; gap: 12px; margin-bottom: 20px;">
    <a href="/admin/estoque-entrada.php" class="botao botao--primario">+ Entrada de estoque</a>
    <a href="/admin/estoque-saida.php" class="botao" style="background: var(--cor-erro); color:#fff;">− Saída de estoque</a>
    <a href="/admin/estoque-historico.php" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Histórico</a>
</div>

<?php if (!empty($produtosEstoqueBaixo)): ?>
    <div class="alerta alerta--erro">
        <strong><?= count($produtosEstoqueBaixo) ?> produto(s) com estoque baixo ou esgotado.</strong>
    </div>
<?php endif; ?>

<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Produto</th>
            <th>Código</th>
            <th>Estoque atual</th>
            <th>Estoque mínimo</th>
            <th>Situação</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($todosProdutos as $produto): ?>
            <?php $baixo = $produto['estoque_atual'] <= $produto['estoque_minimo']; ?>
            <tr>
                <td><?= escapar($produto['nome']) ?></td>
                <td><?= escapar($produto['codigo'] ?? '—') ?></td>
                <td><?= rtrim(rtrim(number_format((float) $produto['estoque_atual'], 3, ',', '.'), '0'), ',') ?></td>
                <td><?= rtrim(rtrim(number_format((float) $produto['estoque_minimo'], 3, ',', '.'), '0'), ',') ?></td>
                <td>
                    <?php if ((float) $produto['estoque_atual'] <= 0): ?>
                        <span class="badge badge--vermelho">Esgotado</span>
                    <?php elseif ($baixo): ?>
                        <span class="badge badge--amarelo">Baixo</span>
                    <?php else: ?>
                        <span class="badge badge--verde">Normal</span>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($todosProdutos)): ?>
            <tr><td colspan="5">Nenhum produto cadastrado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
