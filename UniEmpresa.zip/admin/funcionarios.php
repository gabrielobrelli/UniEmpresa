<?php
/**
 * =============================================================
 * ARQUIVO: admin/funcionarios.php
 * RESPONSABILIDADE: listar os funcionários da empresa do
 *                    administrador logado (seção 12).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$funcionarios = Usuario::listarPorEmpresaETipo($empresaId, TIPO_FUNCIONARIO);

$tituloPagina = 'Funcionários';
$itemMenuAtivo = 'funcionarios';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; justify-content:flex-end; margin-bottom:16px;">
    <a href="/admin/funcionario-form.php" class="botao botao--primario">+ Novo funcionário</a>
</div>

<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Cargo</th>
            <th>Meta diária</th>
            <th>Perfil</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($funcionarios as $funcionario): ?>
            <tr>
                <td><?= escapar($funcionario['nome']) ?></td>
                <td><?= escapar($funcionario['email']) ?></td>
                <td><?= escapar($funcionario['cargo'] ?? '—') ?></td>
                <td><?= minutosParaHoras((int) $funcionario['meta_minutos_diarios']) ?></td>
                <td><?= $funcionario['perfil_completo'] ? '<span class="badge badge--verde">Completo</span>' : '<span class="badge badge--amarelo">Pendente</span>' ?></td>
                <td><?= $funcionario['status'] === 'ativo' ? '<span class="badge badge--verde">Ativo</span>' : '<span class="badge badge--cinza">Inativo</span>' ?></td>
                <td>
                    <a href="/admin/funcionario-form.php?id=<?= (int) $funcionario['id'] ?>">Editar</a>
                    &nbsp;|&nbsp;
                    <a href="/admin/funcionario-feedback.php?id=<?= (int) $funcionario['id'] ?>">Feedback</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($funcionarios)): ?>
            <tr><td colspan="7">Nenhum funcionário cadastrado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
