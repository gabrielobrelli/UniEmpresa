<?php
/**
 * =============================================================
 * ARQUIVO: admin/index.php
 * RESPONSABILIDADE: dashboard do administrador — resumo do
 *                    negócio no dia a dia (seção 15 do documento).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';
require_once __DIR__ . '/../app/models/Financeiro.php';
require_once __DIR__ . '/../app/models/Jornada.php';
require_once __DIR__ . '/../app/models/Venda.php';
require_once __DIR__ . '/../app/models/ConfiguracaoEmpresa.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$textoBoasVindas = ConfiguracaoEmpresa::obter($empresaId, 'texto_boas_vindas');

$pdo = getPDO();

$hoje = resolverPeriodo('hoje');
$mes = resolverPeriodo('mes');

$totaisHoje = Financeiro::totaisPorPeriodo($empresaId, $hoje['inicio'], $hoje['fim']);
$totaisMes = Financeiro::totaisPorPeriodo($empresaId, $mes['inicio'], $mes['fim']);

$vendasHoje = $pdo->prepare(
    "SELECT COUNT(*) AS total FROM vendas
     WHERE empresa_id = :empresa_id AND status = 'finalizada' AND DATE(finalizada_em) = CURDATE()"
);
$vendasHoje->execute([':empresa_id' => $empresaId]);
$totalVendasHoje = (int) $vendasHoje->fetch()['total'];

$produtosEstoqueBaixo = Produto::listarEstoqueBaixo($empresaId);
$statusEquipe = Jornada::statusHojeTodosDaEmpresa($empresaId);
$funcionariosTrabalhando = count(array_filter($statusEquipe, fn($m) => $m['entrada_aberta'] !== null));

$vendasAbertas = Venda::listarPorEmpresa($empresaId, 'aberta');

// Ranking rápido de vendedores do mês, direto aqui no dashboard
// (a tela completa de ranking vem na etapa de relatórios).
$rankingMes = $pdo->prepare(
    "SELECT u.nome, COUNT(v.id) AS total_vendas, COALESCE(SUM(v.total), 0) AS valor_total
     FROM vendas v
     JOIN usuarios u ON u.id = v.funcionario_id
     WHERE v.empresa_id = :empresa_id AND v.status = 'finalizada'
       AND MONTH(v.finalizada_em) = MONTH(CURDATE()) AND YEAR(v.finalizada_em) = YEAR(CURDATE())
     GROUP BY v.funcionario_id
     ORDER BY valor_total DESC LIMIT 5"
);
$rankingMes->execute([':empresa_id' => $empresaId]);
$ranking = $rankingMes->fetchAll();

$tituloPagina = 'Dashboard';
$itemMenuAtivo = 'dashboard';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<?php if ($textoBoasVindas): ?>
    <div class="alerta alerta--info"><?= escapar($textoBoasVindas) ?></div>
<?php endif; ?>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Vendas hoje</div>
        <div class="card-indicador__valor"><?= $totalVendasHoje ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Entradas financeiras hoje</div>
        <div class="card-indicador__valor"><?= formatarMoeda($totaisHoje['entrada']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Saldo do mês</div>
        <div class="card-indicador__valor"><?= formatarMoeda($totaisMes['saldo']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Produtos com estoque baixo</div>
        <div class="card-indicador__valor" style="color: <?= count($produtosEstoqueBaixo) > 0 ? 'var(--cor-erro)' : 'inherit' ?>;">
            <?= count($produtosEstoqueBaixo) ?>
        </div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Funcionários trabalhando agora</div>
        <div class="card-indicador__valor"><?= $funcionariosTrabalhando ?> / <?= count($statusEquipe) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Vendas em aberto</div>
        <div class="card-indicador__valor"><?= count($vendasAbertas) ?></div>
    </div>
</div>

<div style="display:flex; gap:24px; flex-wrap:wrap;">
    <div style="flex:1; min-width:300px;">
        <h3>Ranking de vendedores (mês)</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Funcionário</th><th>Vendas</th><th>Total vendido</th></tr></thead>
            <tbody>
                <?php foreach ($ranking as $linha): ?>
                    <tr>
                        <td><?= escapar($linha['nome']) ?></td>
                        <td><?= (int) $linha['total_vendas'] ?></td>
                        <td><?= formatarMoeda((float) $linha['valor_total']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($ranking)): ?>
                    <tr><td colspan="3">Nenhuma venda finalizada este mês ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="flex:1; min-width:300px;">
        <h3>Produtos com estoque baixo</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Produto</th><th>Estoque atual</th><th>Mínimo</th></tr></thead>
            <tbody>
                <?php foreach (array_slice($produtosEstoqueBaixo, 0, 8) as $produto): ?>
                    <tr>
                        <td><?= escapar($produto['nome']) ?></td>
                        <td><?= rtrim(rtrim(number_format((float) $produto['estoque_atual'], 3, ',', '.'), '0'), ',') ?></td>
                        <td><?= rtrim(rtrim(number_format((float) $produto['estoque_minimo'], 3, ',', '.'), '0'), ',') ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($produtosEstoqueBaixo)): ?>
                    <tr><td colspan="3">Nenhum produto com estoque baixo. 🎉</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
