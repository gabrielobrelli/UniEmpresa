<?php
/**
 * =============================================================
 * ARQUIVO: admin/funcionario-feedback.php
 * RESPONSABILIDADE: administrador registra feedbacks (positivo,
 *                    ponto de atenção, observação) para um
 *                    funcionário e vê o histórico já registrado
 *                    (seção 49 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Usuario.php';
require_once __DIR__ . '/../app/models/Feedback.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$funcionarioId = (int) ($_GET['id'] ?? $_POST['funcionario_id'] ?? 0);
$funcionario = Usuario::buscarPorId($funcionarioId);

if (!$funcionario || (int) $funcionario['empresa_id'] !== $empresaId || $funcionario['tipo'] !== TIPO_FUNCIONARIO) {
    http_response_code(404);
    die('Funcionário não encontrado.');
}

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $tipo = $_POST['tipo'] ?? '';
    $descricao = limparEntrada($_POST['descricao'] ?? '');

    if (!in_array($tipo, ['positivo', 'atencao', 'observacao'], true) || $descricao === '') {
        $erro = 'Selecione o tipo e escreva a descrição do feedback.';
    } else {
        Feedback::registrar($empresaId, $funcionarioId, usuarioId(), $tipo, $descricao);
        Auditoria::registrar('feedback_registrado', 'feedbacks', $funcionarioId, null, ['tipo' => $tipo]);
    }
}

$feedbacks = Feedback::listarPorFuncionario($funcionarioId, $empresaId);

$rotulosTipo = ['positivo' => 'Positivo', 'atencao' => 'Ponto de atenção', 'observacao' => 'Observação'];
$classeBadge = ['positivo' => 'badge--verde', 'atencao' => 'badge--amarelo', 'observacao' => 'badge--cinza'];

$tituloPagina = 'Feedback — ' . $funcionario['nome'];
$itemMenuAtivo = 'funcionarios';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Novo feedback</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/funcionario-feedback.php?id=<?= $funcionarioId ?>">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="funcionario_id" value="<?= $funcionarioId ?>">

            <div class="campo">
                <label for="tipo">Tipo *</label>
                <select id="tipo" name="tipo" required>
                    <option value="positivo">Positivo</option>
                    <option value="atencao">Ponto de atenção</option>
                    <option value="observacao">Observação</option>
                </select>
            </div>
            <div class="campo">
                <label for="descricao">Descrição *</label>
                <textarea id="descricao" name="descricao" rows="4" required></textarea>
            </div>

            <button type="submit" class="botao botao--primario">Registrar feedback</button>
        </form>
    </div>

    <div style="flex:2; min-width:320px;">
        <table class="tabela-padrao">
            <thead>
                <tr><th>Data</th><th>Tipo</th><th>Descrição</th><th>Registrado por</th></tr>
            </thead>
            <tbody>
                <?php foreach ($feedbacks as $fb): ?>
                    <tr>
                        <td><?= formatarData($fb['created_at'], true) ?></td>
                        <td><span class="badge <?= $classeBadge[$fb['tipo']] ?>"><?= $rotulosTipo[$fb['tipo']] ?></span></td>
                        <td><?= escapar($fb['descricao']) ?></td>
                        <td><?= escapar($fb['admin_nome']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($feedbacks)): ?>
                    <tr><td colspan="4">Nenhum feedback registrado ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
