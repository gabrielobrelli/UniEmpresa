<?php
/**
 * =============================================================
 * ARQUIVO: admin/relatorios.php
 * RESPONSABILIDADE: central de relatórios com filtro de período
 *                    (seção 33), gráfico simples de vendas por dia
 *                    (seção 36, em CSS puro — sem biblioteca pesada)
 *                    e exportação em CSV (seção 37).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Relatorio.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$atalho = $_GET['periodo'] ?? 'ultimos_30_dias';
$periodo = resolverPeriodo($atalho, $_GET['data_inicio'] ?? null, $_GET['data_fim'] ?? null);

$vendasPorDia = Relatorio::vendasPorDia($empresaId, $periodo['inicio'], $periodo['fim']);
$produtosMaisVendidos = Relatorio::produtosMaisVendidos($empresaId, $periodo['inicio'], $periodo['fim']);
$vendasPorCategoria = Relatorio::vendasPorCategoria($empresaId, $periodo['inicio'], $periodo['fim']);
$formasPagamento = Relatorio::formasPagamentoUtilizadas($empresaId, $periodo['inicio'], $periodo['fim']);

// --- Exportação CSV -----------------------------------------------
// Quando ?formato=csv é passado, a página não desenha HTML: apenas
// gera o arquivo e encerra (ver app/helpers/exportacao.php).
if (($_GET['formato'] ?? '') === 'csv') {
    $linhasCsv = array_map(
        static fn($linha) => [$linha['dia'], $linha['quantidade'], number_format((float) $linha['total'], 2, ',', '.')],
        $vendasPorDia
    );
    exportarCsvEEncerrar('vendas_' . $periodo['inicio'] . '_a_' . $periodo['fim'] . '.csv', ['Data', 'Qtd. vendas', 'Total (R$)'], $linhasCsv);
}

// Maior valor do período, usado para calcular a altura proporcional
// das barras do gráfico (0 a 100%).
$maiorValorDia = 0.0;
foreach ($vendasPorDia as $linha) {
    $maiorValorDia = max($maiorValorDia, (float) $linha['total']);
}

$tituloPagina = 'Relatórios';
$itemMenuAtivo = 'relatorios';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<form method="GET" action="/admin/relatorios.php" class="linha-campos nao-imprimir" style="margin-bottom:20px; align-items:end;">
    <div class="campo">
        <label for="periodo">Período</label>
        <select id="periodo" name="periodo" onchange="this.form.submit()">
            <?php
            $opcoes = [
                'hoje' => 'Hoje', 'ontem' => 'Ontem', 'ultimos_7_dias' => 'Últimos 7 dias',
                'ultimos_30_dias' => 'Últimos 30 dias', 'semana' => 'Semana', 'mes' => 'Mês',
                'trimestre' => 'Trimestre', 'semestre' => 'Semestre', 'ano' => 'Ano', 'personalizado' => 'Personalizado',
            ];
            foreach ($opcoes as $valor => $rotulo): ?>
                <option value="<?= $valor ?>" <?= $atalho === $valor ? 'selected' : '' ?>><?= $rotulo ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php if ($atalho === 'personalizado'): ?>
        <div class="campo"><label for="data_inicio">De</label><input type="date" id="data_inicio" name="data_inicio" value="<?= escapar($periodo['inicio']) ?>"></div>
        <div class="campo"><label for="data_fim">Até</label><input type="date" id="data_fim" name="data_fim" value="<?= escapar($periodo['fim']) ?>"></div>
        <div class="campo"><button type="submit" class="botao botao--primario">Aplicar</button></div>
    <?php endif; ?>
    <div class="campo">
        <a href="?periodo=<?= $atalho ?>&formato=csv" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Exportar CSV</a>
    </div>
    <div class="campo">
        <button type="button" onclick="window.print()" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Imprimir</button>
    </div>
</form>

<h3>Vendas por dia</h3>
<div class="grafico-barras">
    <?php foreach ($vendasPorDia as $linha): ?>
        <?php $altura = $maiorValorDia > 0 ? max(4, round(((float) $linha['total'] / $maiorValorDia) * 100)) : 0; ?>
        <div class="grafico-barras__coluna">
            <div class="grafico-barras__valor"><?= formatarMoeda((float) $linha['total']) ?></div>
            <div class="grafico-barras__barra" style="height: <?= $altura ?>%;"></div>
            <div class="grafico-barras__rotulo"><?= formatarData($linha['dia']) ?></div>
        </div>
    <?php endforeach; ?>
    <?php if (empty($vendasPorDia)): ?>
        <p>Nenhuma venda finalizada no período selecionado.</p>
    <?php endif; ?>
</div>

<div style="display:flex; gap:24px; flex-wrap:wrap; margin-top:32px;">

    <div style="flex:1; min-width:280px;">
        <h3>Produtos mais vendidos</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Produto</th><th>Qtd. vendida</th><th>Valor total</th></tr></thead>
            <tbody>
                <?php foreach ($produtosMaisVendidos as $p): ?>
                    <tr>
                        <td><?= escapar($p['nome']) ?></td>
                        <td><?= rtrim(rtrim(number_format((float) $p['quantidade_vendida'], 3, ',', '.'), '0'), ',') ?></td>
                        <td><?= formatarMoeda((float) $p['valor_total']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($produtosMaisVendidos)): ?><tr><td colspan="3">Sem dados no período.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>

    <div style="flex:1; min-width:280px;">
        <h3>Vendas por categoria</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Categoria</th><th>Valor total</th></tr></thead>
            <tbody>
                <?php foreach ($vendasPorCategoria as $c): ?>
                    <tr><td><?= escapar($c['categoria']) ?></td><td><?= formatarMoeda((float) $c['valor_total']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (empty($vendasPorCategoria)): ?><tr><td colspan="2">Sem dados no período.</td></tr><?php endif; ?>
            </tbody>
        </table>

        <h3 style="margin-top:24px;">Formas de pagamento</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Forma</th><th>Qtd.</th><th>Valor total</th></tr></thead>
            <tbody>
                <?php
                $rotulosPagamento = ['dinheiro' => 'Dinheiro', 'pix' => 'Pix', 'debito' => 'Débito', 'credito' => 'Crédito', 'outro' => 'Outro'];
                foreach ($formasPagamento as $fp): ?>
                    <tr>
                        <td><?= escapar($rotulosPagamento[$fp['forma']] ?? $fp['forma']) ?></td>
                        <td><?= (int) $fp['quantidade'] ?></td>
                        <td><?= formatarMoeda((float) $fp['valor_total']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($formasPagamento)): ?><tr><td colspan="3">Sem dados no período.</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
