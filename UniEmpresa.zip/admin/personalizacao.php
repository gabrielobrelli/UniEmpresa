<?php
/**
 * =============================================================
 * ARQUIVO: admin/personalizacao.php
 * RESPONSABILIDADE: administrador personaliza a aparência do
 *                    ambiente da própria empresa — nome exibido,
 *                    slogan, logo, cores e texto de boas-vindas
 *                    (seção 38/91). Inclui uma prévia ao vivo para
 *                    o admin ver o resultado antes de salvar.
 *
 * Nada aqui afeta outras empresas: cada alteração é gravada com o
 * empresa_id do escopo atual.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Empresa.php';
require_once __DIR__ . '/../app/models/ConfiguracaoEmpresa.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;
$sucesso = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $nomeExibido = limparEntrada($_POST['nome_exibido'] ?? '');
    $slogan = limparEntrada($_POST['slogan'] ?? '');
    $corPrimaria = limparEntrada($_POST['cor_primaria'] ?? '#2563eb');
    $corSecundaria = limparEntrada($_POST['cor_secundaria'] ?? '#1e293b');
    $corDestaque = limparEntrada($_POST['cor_destaque'] ?? '#f59e0b');
    $textoBoasVindas = limparEntrada($_POST['texto_boas_vindas'] ?? '');
    $rodape = limparEntrada($_POST['rodape'] ?? '');

    $padraoHex = '/^#[0-9A-Fa-f]{6}$/';
    if (!preg_match($padraoHex, $corPrimaria) || !preg_match($padraoHex, $corSecundaria) || !preg_match($padraoHex, $corDestaque)) {
        $erro = 'As cores devem estar no formato hexadecimal (ex.: #2563EB).';
    } elseif ($nomeExibido === '') {
        $erro = 'Informe o nome exibido para os usuários da empresa.';
    } else {
        try {
            Empresa::atualizarNomeExibido($empresaId, $nomeExibido);
            Empresa::atualizarCores($empresaId, $corPrimaria, $corSecundaria, $corDestaque);
            ConfiguracaoEmpresa::definir($empresaId, 'texto_boas_vindas', $textoBoasVindas);
            ConfiguracaoEmpresa::definir($empresaId, 'slogan', $slogan);
            ConfiguracaoEmpresa::definir($empresaId, 'rodape', $rodape);

            if (!empty($_FILES['logo']['name'])) {
                $caminhoLogo = salvarImagemEnviada($_FILES['logo'], 'empresas/' . $empresaId);
                if ($caminhoLogo) {
                    Empresa::atualizarLogo($empresaId, $caminhoLogo);
                }
            }

            Auditoria::registrar('personalizacao_atualizada', 'empresas', $empresaId);
            $sucesso = true;
        } catch (RuntimeException $e) {
            $erro = $e->getMessage();
        }
    }
}

$empresa = Empresa::buscarPorId($empresaId);
$textoBoasVindas = ConfiguracaoEmpresa::obter($empresaId, 'texto_boas_vindas');
$slogan = ConfiguracaoEmpresa::obter($empresaId, 'slogan');
$rodape = ConfiguracaoEmpresa::obter($empresaId, 'rodape');

$tituloPagina = 'Personalização';
$itemMenuAtivo = 'personalizacao';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<p style="color:var(--cor-texto-suave); max-width:640px; margin-top:-8px;">
    Deixe o sistema com a cara da sua empresa: seu logo aparece na barra lateral, na aba do
    navegador e nos comprovantes de venda; as cores escolhidas aqui substituem o azul padrão
    em toda a área de administração e dos funcionários.
</p>

<div style="display:flex; gap:24px; flex-wrap:wrap; align-items:flex-start;">

    <div class="cartao-formulario" style="flex:1; min-width:320px;">
        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>
        <?php if ($sucesso): ?>
            <div class="alerta alerta--sucesso">Personalização salva! O novo visual já está sendo aplicado.</div>
        <?php endif; ?>

        <form method="POST" action="/admin/personalizacao.php" enctype="multipart/form-data" id="form-personalizacao">
            <?= csrfCampoOculto() ?>

            <div class="campo">
                <label for="nome_exibido">Nome exibido para sua equipe</label>
                <input type="text" id="nome_exibido" name="nome_exibido" required value="<?= escapar($empresa['nome_fantasia']) ?>">
            </div>

            <div class="campo">
                <label for="slogan">Slogan/frase curta (aparece embaixo do nome na barra lateral)</label>
                <input type="text" id="slogan" name="slogan" maxlength="60" placeholder="Ex.: Qualidade que você confia" value="<?= escapar($slogan) ?>">
            </div>

            <div class="campo">
                <label for="logo">Logo (aparece na barra lateral, aba do navegador e comprovantes)</label>
                <?php if (!empty($empresa['logo'])): ?>
                    <div><img src="<?= escapar($empresa['logo']) ?>" alt="Logo atual" style="max-height:48px; margin-bottom:8px; border-radius:6px;"></div>
                <?php endif; ?>
                <input type="file" id="logo" name="logo" accept=".jpg,.jpeg,.png,.webp">
            </div>

            <div class="linha-campos">
                <div class="campo">
                    <label for="cor_primaria">Cor principal (marca)</label>
                    <input type="color" id="cor_primaria" name="cor_primaria" value="<?= escapar($empresa['cor_primaria']) ?>">
                </div>
                <div class="campo">
                    <label for="cor_secundaria">Cor secundária</label>
                    <input type="color" id="cor_secundaria" name="cor_secundaria" value="<?= escapar($empresa['cor_secundaria']) ?>">
                </div>
                <div class="campo">
                    <label for="cor_destaque">Cor de destaque</label>
                    <input type="color" id="cor_destaque" name="cor_destaque" value="<?= escapar($empresa['cor_destaque']) ?>">
                </div>
            </div>

            <div class="campo">
                <label for="texto_boas_vindas">Mensagem de boas-vindas (aparece no topo dos dashboards)</label>
                <textarea id="texto_boas_vindas" name="texto_boas_vindas" rows="2" placeholder="Ex.: Bem-vindo ao sistema da Loja do João!"><?= escapar($textoBoasVindas) ?></textarea>
            </div>

            <div class="campo">
                <label for="rodape">Texto de rodapé (aparece no fim da barra lateral)</label>
                <input type="text" id="rodape" name="rodape" maxlength="80" placeholder="Ex.: © 2026 Loja do João" value="<?= escapar($rodape) ?>">
            </div>

            <button type="submit" class="botao botao--primario">Salvar personalização</button>
        </form>
    </div>

    <!-- Prévia ao vivo: uma mini-sidebar e um mini-botão que mudam de
         cor em tempo real conforme o admin escolhe as cores, sem
         precisar salvar para ver o resultado. Puro JS, sem biblioteca. -->
    <div style="flex:1; min-width:280px; position:sticky; top:90px;">
        <p style="font-size:12.5px; font-weight:700; color:var(--cor-texto-suave); text-transform:uppercase; letter-spacing:0.05em; margin-bottom:8px;">
            Prévia ao vivo
        </p>
        <div id="previa-container" style="border-radius:var(--raio-grande); overflow:hidden; box-shadow:var(--sombra-media); border:1px solid var(--cor-borda);">
            <div id="previa-sidebar" style="padding:16px; color:#fff; display:flex; align-items:center; gap:10px;">
                <div id="previa-logo" style="width:32px; height:32px; border-radius:7px; background:rgba(255,255,255,.2); display:flex; align-items:center; justify-content:center; font-size:14px; overflow:hidden;">
                    <?php if (!empty($empresa['logo'])): ?>
                        <img src="<?= escapar($empresa['logo']) ?>" style="width:100%; height:100%; object-fit:cover;">
                    <?php else: ?>🏪<?php endif; ?>
                </div>
                <div>
                    <div id="previa-nome" style="font-weight:700; font-size:14px;"><?= escapar($empresa['nome_fantasia']) ?></div>
                    <div id="previa-slogan" style="font-size:11px; opacity:.75;"><?= escapar($slogan ?: 'Seu slogan aqui') ?></div>
                </div>
            </div>
            <div style="background:#f8fafc; padding:20px;">
                <div id="previa-boasvindas" style="background:#eff6ff; color:#1d4ed8; padding:10px 12px; border-radius:8px; font-size:13px; margin-bottom:14px;">
                    <?= escapar($textoBoasVindas ?: 'Aqui aparece sua mensagem de boas-vindas.') ?>
                </div>
                <button type="button" id="previa-botao" style="border:none; padding:9px 16px; border-radius:8px; color:#fff; font-weight:600; font-size:13px; cursor:default;">
                    Botão de exemplo
                </button>
                <span id="previa-destaque" style="display:inline-block; margin-left:8px; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:700; color:#fff;">
                    Destaque
                </span>
            </div>
        </div>
    </div>

</div>

<script>
    // Atualiza a prévia em tempo real conforme o admin mexe nos campos,
    // sem precisar salvar o formulário para ver o resultado.
    function atualizarPrevia() {
        const primaria = document.getElementById('cor_primaria').value;
        const secundaria = document.getElementById('cor_secundaria').value;
        const destaque = document.getElementById('cor_destaque').value;

        document.getElementById('previa-sidebar').style.background = secundaria;
        document.getElementById('previa-botao').style.background = primaria;
        document.getElementById('previa-destaque').style.background = destaque;
        document.getElementById('previa-nome').textContent = document.getElementById('nome_exibido').value || 'Nome da empresa';
        document.getElementById('previa-slogan').textContent = document.getElementById('slogan').value || 'Seu slogan aqui';
        document.getElementById('previa-boasvindas').textContent =
            document.getElementById('texto_boas_vindas').value || 'Aqui aparece sua mensagem de boas-vindas.';
    }

    ['cor_primaria', 'cor_secundaria', 'cor_destaque', 'nome_exibido', 'slogan', 'texto_boas_vindas'].forEach((id) => {
        document.getElementById(id).addEventListener('input', atualizarPrevia);
    });

    atualizarPrevia();
</script>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
