<?php
/**
 * =============================================================
 * ARQUIVO: admin/produtos.php
 * RESPONSABILIDADE: listar os produtos da empresa do administrador
 *                    logado, com busca por nome/código, e indicar
 *                    visualmente produtos com estoque baixo.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Produto.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$busca = limparEntrada($_GET['busca'] ?? '');
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));

$produtos = Produto::listarPorEmpresa($empresaId, $busca, $pagina);

$tituloPagina = 'Produtos';
$itemMenuAtivo = 'produtos';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="barra-filtros" style="justify-content: space-between; margin-bottom: 20px;">
    <form method="GET" action="/admin/produtos.php" class="barra-filtros" style="flex: 1 1 260px;">
        <input type="text" name="busca" placeholder="Buscar por nome ou código"
               value="<?= escapar($busca) ?>" class="barra-filtros__busca">
        <button type="submit" class="botao botao--primario">Buscar</button>
    </form>

    <a href="/admin/produto-form.php" class="botao botao--primario">+ Novo produto</a>
</div>

<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Código</th>
            <th>Produto</th>
            <th>Categoria</th>
            <th>Unidade</th>
            <th>Preço venda</th>
            <th>Estoque</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($produtos as $produto): ?>
            <?php $estoqueBaixo = $produto['estoque_atual'] <= $produto['estoque_minimo']; ?>
            <tr>
                <td><?= escapar($produto['codigo'] ?? '—') ?></td>
                <td><?= escapar($produto['nome']) ?></td>
                <td><?= escapar($produto['categoria_nome'] ?? '—') ?></td>
                <td><?= escapar($produto['unidade_sigla'] ?? '—') ?></td>
                <td><?= formatarMoeda((float) $produto['preco_venda']) ?></td>
                <td>
                    <?= rtrim(rtrim(number_format((float) $produto['estoque_atual'], 3, ',', '.'), '0'), ',') ?>
                    <?php if ($estoqueBaixo): ?>
                        <span class="badge badge--vermelho" title="Estoque igual ou abaixo do mínimo">Baixo</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="/admin/produto-form.php?id=<?= (int) $produto['id'] ?>">Editar</a>
                    &nbsp;|&nbsp;
                    <a href="/admin/estoque-entrada.php?produto_id=<?= (int) $produto['id'] ?>">+ Estoque</a>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($produtos)): ?>
            <tr><td colspan="7">Nenhum produto encontrado.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
