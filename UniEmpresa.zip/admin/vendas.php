<?php
/**
 * =============================================================
 * ARQUIVO: admin/vendas.php
 * RESPONSABILIDADE: o administrador acompanha todas as vendas da
 *                    empresa (abertas e finalizadas — seção 23) e
 *                    pode cancelar uma venda quando necessário
 *                    (seção 29), com estorno automático de estoque.
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Venda.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['acao'] ?? '') === 'cancelar') {
    csrfValidarOuFalhar();

    $vendaId = (int) ($_POST['venda_id'] ?? 0);
    $motivo = limparEntrada($_POST['motivo'] ?? '');

    if ($motivo === '') {
        $erro = 'Informe o motivo do cancelamento.';
    } else {
        try {
            Venda::cancelar($vendaId, $empresaId, $motivo, usuarioId());
            Auditoria::registrar('venda_cancelada', 'vendas', $vendaId, null, ['motivo' => $motivo]);
        } catch (RuntimeException $e) {
            $erro = $e->getMessage();
        }
    }
}

$statusFiltro = $_GET['status'] ?? null;
$vendas = Venda::listarPorEmpresa($empresaId, $statusFiltro ?: null);

$tituloPagina = 'Vendas';
$itemMenuAtivo = 'vendas';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<?php if ($erro): ?>
    <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
<?php endif; ?>

<div class="nao-imprimir" style="margin-bottom:16px;">
    <a href="/admin/vendas.php" class="botao <?= !$statusFiltro ? 'botao--primario' : '' ?>" style="<?= $statusFiltro ? 'background:#fff;border:1px solid var(--cor-borda);' : '' ?>">Todas</a>
    <a href="/admin/vendas.php?status=aberta" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Abertas</a>
    <a href="/admin/vendas.php?status=finalizada" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Finalizadas</a>
    <a href="/admin/vendas.php?status=cancelada" class="botao" style="background:#fff;border:1px solid var(--cor-borda);">Canceladas</a>
</div>

<table class="tabela-padrao">
    <thead>
        <tr>
            <th>Nº</th>
            <th>Funcionário</th>
            <th>Cliente</th>
            <th>Total</th>
            <th>Status</th>
            <th>Data</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($vendas as $venda): ?>
            <tr>
                <td>#<?= escapar($venda['numero_venda']) ?></td>
                <td><?= escapar($venda['funcionario_nome']) ?></td>
                <td><?= escapar($venda['cliente_nome'] ?? '—') ?></td>
                <td><?= formatarMoeda((float) $venda['total']) ?></td>
                <td>
                    <?php
                        $mapaBadge = [
                            'aberta' => 'badge--amarelo',
                            'finalizada' => 'badge--verde',
                            'cancelada' => 'badge--vermelho',
                            'devolvida' => 'badge--vermelho',
                            'parcial_devolvida' => 'badge--amarelo',
                        ];
                        $classe = $mapaBadge[$venda['status']] ?? 'badge--cinza';
                    ?>
                    <span class="badge <?= $classe ?>"><?= escapar(ucfirst($venda['status'])) ?></span>
                </td>
                <td><?= formatarData($venda['created_at'], true) ?></td>
                <td>
                    <a href="/funcionario/venda-comprovante.php?id=<?= (int) $venda['id'] ?>">Ver comprovante</a>
                    <?php if ($venda['status'] === 'finalizada'): ?>
                        &nbsp;|&nbsp;
                        <button type="button" class="botao-cancelar-venda" data-venda-id="<?= (int) $venda['id'] ?>"
                                style="border:none; background:none; color:var(--cor-erro); cursor:pointer; padding:0;">
                            Cancelar
                        </button>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($vendas)): ?>
            <tr><td colspan="7">Nenhuma venda encontrada.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<!-- Formulário oculto reutilizado para o cancelamento, preenchido via JS -->
<form method="POST" action="/admin/vendas.php<?= $statusFiltro ? '?status=' . escapar($statusFiltro) : '' ?>" id="form-cancelar-venda" style="display:none;">
    <?= csrfCampoOculto() ?>
    <input type="hidden" name="acao" value="cancelar">
    <input type="hidden" name="venda_id" id="input-venda-id-cancelar">
    <input type="hidden" name="motivo" id="input-motivo-cancelar">
</form>

<script>
    // Pequeno script inline: pede o motivo via prompt() e envia o
    // formulário oculto acima. Mantido simples propositalmente, já
    // que é uma ação pontual do admin, não parte do fluxo do PDV.
    document.querySelectorAll('.botao-cancelar-venda').forEach(function (botao) {
        botao.addEventListener('click', function () {
            const motivo = prompt('Informe o motivo do cancelamento desta venda:');
            if (!motivo) {
                return;
            }
            document.getElementById('input-venda-id-cancelar').value = botao.dataset.vendaId;
            document.getElementById('input-motivo-cancelar').value = motivo;
            document.getElementById('form-cancelar-venda').submit();
        });
    });
</script>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
