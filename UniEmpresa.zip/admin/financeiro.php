<?php
/**
 * =============================================================
 * ARQUIVO: admin/financeiro.php
 * RESPONSABILIDADE: fluxo de caixa (entradas/saídas/saldo) com
 *                    filtro de período, lançamento manual de
 *                    movimentações e indicadores do balanço
 *                    operacional (seções 30-32 e 82).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Financeiro.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $dados = [
        'tipo' => $_POST['tipo'] ?? '',
        'categoria' => limparEntrada($_POST['categoria'] ?? ''),
        'descricao' => limparEntrada($_POST['descricao'] ?? ''),
        'valor' => (float) str_replace(',', '.', $_POST['valor'] ?? '0'),
        'forma_pagamento' => $_POST['forma_pagamento'] ?? '',
        'observacao' => limparEntrada($_POST['observacao'] ?? ''),
        'data_movimentacao' => $_POST['data_movimentacao'] ?? date('Y-m-d'),
    ];

    if (!in_array($dados['tipo'], ['entrada', 'saida'], true) || $dados['descricao'] === '' || $dados['valor'] <= 0) {
        $erro = 'Preencha tipo, descrição e um valor maior que zero.';
    } else {
        $novoId = Financeiro::registrarManual($empresaId, $dados, usuarioId());
        Auditoria::registrar('financeiro_lancamento', 'movimentacoes_financeiras', $novoId, null, $dados);
    }
}

$atalho = $_GET['periodo'] ?? 'mes';
$periodo = resolverPeriodo($atalho, $_GET['data_inicio'] ?? null, $_GET['data_fim'] ?? null);

$movimentacoes = Financeiro::listarPorPeriodo($empresaId, $periodo['inicio'], $periodo['fim']);
$totais = Financeiro::totaisPorPeriodo($empresaId, $periodo['inicio'], $periodo['fim']);
$balanco = Financeiro::balancoOperacional($empresaId);

$tituloPagina = 'Financeiro';
$itemMenuAtivo = 'financeiro';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div class="grade-cards">
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Entradas no período</div>
        <div class="card-indicador__valor" style="color:var(--cor-sucesso);"><?= formatarMoeda($totais['entrada']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Saídas no período</div>
        <div class="card-indicador__valor" style="color:var(--cor-erro);"><?= formatarMoeda($totais['saida']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Saldo do período</div>
        <div class="card-indicador__valor"><?= formatarMoeda($totais['saldo']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Capital investido em estoque (custo)</div>
        <div class="card-indicador__valor"><?= formatarMoeda($balanco['capital_investido_estoque']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Valor estimado do estoque (venda)</div>
        <div class="card-indicador__valor"><?= formatarMoeda($balanco['valor_estimado_estoque']) ?></div>
    </div>
    <div class="card-indicador">
        <div class="card-indicador__rotulo">Total vendido no mês</div>
        <div class="card-indicador__valor"><?= formatarMoeda($balanco['total_vendas_mes']) ?></div>
    </div>
</div>
<p style="color: var(--cor-texto-suave); font-size: 13px; margin-top: -12px;">
    Estes valores são indicadores de custo, receita e estoque — não representam o lucro real, que depende também de despesas não cadastradas aqui.
</p>

<form method="GET" action="/admin/financeiro.php" class="linha-campos nao-imprimir" style="margin: 20px 0; align-items:end;">
    <div class="campo">
        <label for="periodo">Período</label>
        <select id="periodo" name="periodo" onchange="this.form.submit()">
            <?php
            $opcoes = [
                'hoje' => 'Hoje', 'ontem' => 'Ontem', 'ultimos_7_dias' => 'Últimos 7 dias',
                'ultimos_30_dias' => 'Últimos 30 dias', 'semana' => 'Semana', 'mes' => 'Mês',
                'trimestre' => 'Trimestre', 'semestre' => 'Semestre', 'ano' => 'Ano',
                'dois_anos' => 'Dois anos', 'personalizado' => 'Personalizado',
            ];
            foreach ($opcoes as $valor => $rotulo): ?>
                <option value="<?= $valor ?>" <?= $atalho === $valor ? 'selected' : '' ?>><?= $rotulo ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <?php if ($atalho === 'personalizado'): ?>
        <div class="campo">
            <label for="data_inicio">De</label>
            <input type="date" id="data_inicio" name="data_inicio" value="<?= escapar($periodo['inicio']) ?>">
        </div>
        <div class="campo">
            <label for="data_fim">Até</label>
            <input type="date" id="data_fim" name="data_fim" value="<?= escapar($periodo['fim']) ?>">
        </div>
        <div class="campo"><button type="submit" class="botao botao--primario">Aplicar</button></div>
    <?php endif; ?>
</form>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div style="flex:2; min-width:340px;">
        <table class="tabela-padrao">
            <thead>
                <tr><th>Data</th><th>Tipo</th><th>Categoria</th><th>Descrição</th><th>Valor</th><th>Responsável</th></tr>
            </thead>
            <tbody>
                <?php foreach ($movimentacoes as $mov): ?>
                    <tr>
                        <td><?= formatarData($mov['data_movimentacao']) ?></td>
                        <td><?= $mov['tipo'] === 'entrada' ? '<span class="badge badge--verde">Entrada</span>' : '<span class="badge badge--vermelho">Saída</span>' ?></td>
                        <td><?= escapar($mov['categoria']) ?></td>
                        <td><?= escapar($mov['descricao']) ?></td>
                        <td><?= formatarMoeda((float) $mov['valor']) ?></td>
                        <td><?= escapar($mov['responsavel_nome']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($movimentacoes)): ?>
                    <tr><td colspan="6">Nenhuma movimentação no período selecionado.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="cartao-formulario nao-imprimir" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Novo lançamento manual</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/financeiro.php">
            <?= csrfCampoOculto() ?>

            <div class="campo">
                <label for="tipo">Tipo *</label>
                <select id="tipo" name="tipo" required>
                    <option value="entrada">Entrada</option>
                    <option value="saida">Saída</option>
                </select>
            </div>
            <div class="campo">
                <label for="categoria">Categoria *</label>
                <input type="text" id="categoria" name="categoria" placeholder="Ex.: Aluguel, Energia, Outras receitas" required>
            </div>
            <div class="campo">
                <label for="descricao">Descrição *</label>
                <input type="text" id="descricao" name="descricao" required>
            </div>
            <div class="linha-campos">
                <div class="campo">
                    <label for="valor">Valor (R$) *</label>
                    <input type="text" id="valor" name="valor" required>
                </div>
                <div class="campo">
                    <label for="data_movimentacao">Data</label>
                    <input type="date" id="data_movimentacao" name="data_movimentacao" value="<?= date('Y-m-d') ?>">
                </div>
            </div>
            <div class="campo">
                <label for="forma_pagamento">Forma de pagamento</label>
                <select id="forma_pagamento" name="forma_pagamento">
                    <option value="">—</option>
                    <option value="dinheiro">Dinheiro</option>
                    <option value="pix">Pix</option>
                    <option value="debito">Débito</option>
                    <option value="credito">Crédito</option>
                    <option value="transferencia">Transferência</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
            <div class="campo">
                <label for="observacao">Observação</label>
                <textarea id="observacao" name="observacao" rows="2"></textarea>
            </div>

            <button type="submit" class="botao botao--primario">Registrar lançamento</button>
        </form>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
