<?php
/**
 * =============================================================
 * ARQUIVO: admin/ranking.php
 * RESPONSABILIDADE: ranking completo de funcionários por valor
 *                    vendido, quantidade de vendas e produtos
 *                    vendidos, respeitando o período selecionado
 *                    (seção 35 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Relatorio.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$atalho = $_GET['periodo'] ?? 'mes';
$periodo = resolverPeriodo($atalho, $_GET['data_inicio'] ?? null, $_GET['data_fim'] ?? null);

$ranking = Relatorio::rankingFuncionarios($empresaId, $periodo['inicio'], $periodo['fim']);

if (($_GET['formato'] ?? '') === 'csv') {
    $linhasCsv = array_map(
        static fn($linha, $posicao) => [
            $posicao + 1,
            $linha['nome'],
            (int) $linha['total_vendas'],
            number_format((float) $linha['valor_total'], 2, ',', '.'),
            (int) $linha['quantidade_produtos'],
        ],
        $ranking,
        array_keys($ranking)
    );
    exportarCsvEEncerrar(
        'ranking_' . $periodo['inicio'] . '_a_' . $periodo['fim'] . '.csv',
        ['Posição', 'Funcionário', 'Qtd. vendas', 'Valor total (R$)', 'Produtos vendidos'],
        $linhasCsv
    );
}

$tituloPagina = 'Ranking de funcionários';
$itemMenuAtivo = 'ranking';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<form method="GET" action="/admin/ranking.php" class="linha-campos nao-imprimir" style="margin-bottom:20px; align-items:end;">
    <div class="campo">
        <label for="periodo">Período</label>
        <select id="periodo" name="periodo" onchange="this.form.submit()">
            <?php foreach (['hoje' => 'Hoje', 'semana' => 'Semana', 'mes' => 'Mês', 'trimestre' => 'Trimestre', 'ano' => 'Ano'] as $valor => $rotulo): ?>
                <option value="<?= $valor ?>" <?= $atalho === $valor ? 'selected' : '' ?>><?= $rotulo ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="campo">
        <a href="?periodo=<?= $atalho ?>&formato=csv" class="botao" style="background:#fff; border:1px solid var(--cor-borda);">Exportar CSV</a>
    </div>
</form>

<table class="tabela-padrao">
    <thead>
        <tr><th>#</th><th>Funcionário</th><th>Vendas</th><th>Valor total</th><th>Produtos vendidos</th></tr>
    </thead>
    <tbody>
        <?php foreach ($ranking as $posicao => $linha): ?>
            <tr>
                <td><?= $posicao + 1 ?><?= $posicao === 0 && $linha['total_vendas'] > 0 ? ' 🏆' : '' ?></td>
                <td><?= escapar($linha['nome']) ?></td>
                <td><?= (int) $linha['total_vendas'] ?></td>
                <td><?= formatarMoeda((float) $linha['valor_total']) ?></td>
                <td><?= rtrim(rtrim(number_format((float) $linha['quantidade_produtos'], 3, ',', '.'), '0'), ',') ?></td>
            </tr>
        <?php endforeach; ?>
        <?php if (empty($ranking)): ?>
            <tr><td colspan="5">Nenhum funcionário cadastrado ainda.</td></tr>
        <?php endif; ?>
    </tbody>
</table>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
