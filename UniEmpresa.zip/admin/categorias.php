<?php
/**
 * =============================================================
 * ARQUIVO: admin/categorias.php
 * RESPONSABILIDADE: listar, criar e excluir categorias e
 *                    subcategorias da empresa do administrador
 *                    logado (seção 17 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Categoria.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $acao = $_POST['acao'] ?? '';

    if ($acao === 'criar') {
        $nome = limparEntrada($_POST['nome'] ?? '');
        $categoriaPaiId = !empty($_POST['categoria_pai_id']) ? (int) $_POST['categoria_pai_id'] : null;

        if ($nome === '') {
            $erro = 'Informe o nome da categoria.';
        } else {
            $novoId = Categoria::criar($empresaId, $nome, $categoriaPaiId);
            Auditoria::registrar('categoria_criada', 'categorias', $novoId, null, ['nome' => $nome]);
        }
    } elseif ($acao === 'excluir') {
        $id = (int) ($_POST['id'] ?? 0);
        Categoria::excluir($id, $empresaId);
        Auditoria::registrar('categoria_excluida', 'categorias', $id);
    }
}

$categorias = Categoria::listarPorEmpresa($empresaId);
$categoriasPrincipais = Categoria::listarPrincipais($empresaId);

$tituloPagina = 'Categorias';
$itemMenuAtivo = 'categorias';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap: wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Nova categoria/subcategoria</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/categorias.php">
            <?= csrfCampoOculto() ?>
            <input type="hidden" name="acao" value="criar">

            <div class="campo">
                <label for="nome">Nome *</label>
                <input type="text" id="nome" name="nome" required placeholder="Ex.: Roupas, Cimento, Bebidas...">
            </div>

            <div class="campo">
                <label for="categoria_pai_id">Categoria-pai (deixe em branco para categoria principal)</label>
                <select id="categoria_pai_id" name="categoria_pai_id">
                    <option value="">— Categoria principal —</option>
                    <?php foreach ($categoriasPrincipais as $cat): ?>
                        <option value="<?= (int) $cat['id'] ?>"><?= escapar($cat['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="botao botao--primario">Adicionar</button>
        </form>
    </div>

    <div style="flex:2; min-width:320px;">
        <table class="tabela-padrao">
            <thead>
                <tr><th>Nome</th><th>Tipo</th><th>Ações</th></tr>
            </thead>
            <tbody>
                <?php foreach ($categorias as $cat): ?>
                    <tr>
                        <td><?= $cat['categoria_pai_id'] ? '— ' . escapar($cat['nome']) : '<strong>' . escapar($cat['nome']) . '</strong>' ?></td>
                        <td><?= $cat['categoria_pai_id'] ? 'Subcategoria' : 'Principal' ?></td>
                        <td>
                            <form method="POST" action="/admin/categorias.php" onsubmit="return confirm('Excluir esta categoria?');" style="display:inline;">
                                <?= csrfCampoOculto() ?>
                                <input type="hidden" name="acao" value="excluir">
                                <input type="hidden" name="id" value="<?= (int) $cat['id'] ?>">
                                <button type="submit" class="botao" style="background:none; color:var(--cor-erro); padding:0;">Excluir</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($categorias)): ?>
                    <tr><td colspan="3">Nenhuma categoria cadastrada ainda.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
