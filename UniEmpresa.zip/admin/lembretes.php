<?php
/**
 * =============================================================
 * ARQUIVO: admin/lembretes.php
 * RESPONSABILIDADE: administrador cria lembretes para funcionários
 *                    específicos e visualiza lembretes recebidos
 *                    de funcionários (seção 44 do documento).
 * =============================================================
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../app/models/Lembrete.php';
require_once __DIR__ . '/../app/models/Usuario.php';

Auth::exigirTipo(TIPO_ADMIN);
$empresaId = Auth::empresaIdEscopo();

$erro = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    if (($_POST['acao'] ?? '') === 'concluir') {
        Lembrete::marcarComoConcluido((int) $_POST['lembrete_id'], usuarioId());
    } else {
        $destinatarioId = (int) ($_POST['destinatario_id'] ?? 0);
        $titulo = limparEntrada($_POST['titulo'] ?? '');
        $descricao = limparEntrada($_POST['descricao'] ?? '');
        $prioridade = $_POST['prioridade'] ?? 'verde';

        $destinatario = Usuario::buscarPorId($destinatarioId);
        $valido = $destinatario && (int) $destinatario['empresa_id'] === $empresaId && $destinatario['tipo'] === TIPO_FUNCIONARIO;

        if (!$valido || $titulo === '') {
            $erro = 'Selecione um funcionário válido e informe o título do lembrete.';
        } else {
            Lembrete::criar($empresaId, usuarioId(), $destinatarioId, $titulo, $descricao, $prioridade);
        }
    }
}

$funcionarios = Usuario::listarPorEmpresaETipo($empresaId, TIPO_FUNCIONARIO);
$recebidos = Lembrete::listarRecebidos(usuarioId());
$enviados = Lembrete::listarEnviados(usuarioId());

$classeBadge = ['verde' => 'badge--verde', 'amarelo' => 'badge--amarelo', 'vermelho' => 'badge--vermelho'];

$tituloPagina = 'Lembretes';
$itemMenuAtivo = 'lembretes';
require __DIR__ . '/../app/views/layout-inicio.php';
?>

<div style="display:flex; gap:24px; flex-wrap:wrap;">

    <div class="cartao-formulario" style="flex:1; min-width:280px;">
        <h3 style="margin-top:0;">Novo lembrete para funcionário</h3>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <form method="POST" action="/admin/lembretes.php">
            <?= csrfCampoOculto() ?>

            <div class="campo">
                <label for="destinatario_id">Funcionário *</label>
                <select id="destinatario_id" name="destinatario_id" required>
                    <?php foreach ($funcionarios as $f): ?>
                        <option value="<?= (int) $f['id'] ?>"><?= escapar($f['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="campo">
                <label for="titulo">Título *</label>
                <input type="text" id="titulo" name="titulo" required>
            </div>
            <div class="campo">
                <label for="descricao">Descrição</label>
                <textarea id="descricao" name="descricao" rows="3"></textarea>
            </div>
            <div class="campo">
                <label for="prioridade">Prioridade</label>
                <select id="prioridade" name="prioridade">
                    <option value="verde">Normal</option>
                    <option value="amarelo">Atenção</option>
                    <option value="vermelho">Urgente</option>
                </select>
            </div>

            <button type="submit" class="botao botao--primario">Enviar lembrete</button>
        </form>
    </div>

    <div style="flex:2; min-width:320px;">
        <h3 style="margin-top:0;">Lembretes recebidos de funcionários</h3>
        <table class="tabela-padrao">
            <thead><tr><th>De</th><th>Título</th><th>Prioridade</th><th>Status</th><th>Data</th></tr></thead>
            <tbody>
                <?php foreach ($recebidos as $l): ?>
                    <tr>
                        <td><?= escapar($l['criador_nome']) ?></td>
                        <td><?= escapar($l['titulo']) ?><br><small style="color:var(--cor-texto-suave);"><?= escapar($l['descricao']) ?></small></td>
                        <td><span class="badge <?= $classeBadge[$l['prioridade']] ?>"><?= ucfirst($l['prioridade']) ?></span></td>
                        <td>
                            <?php if ($l['status'] === 'pendente'): ?>
                                <form method="POST" action="/admin/lembretes.php" style="display:inline;">
                                    <?= csrfCampoOculto() ?>
                                    <input type="hidden" name="acao" value="concluir">
                                    <input type="hidden" name="lembrete_id" value="<?= (int) $l['id'] ?>">
                                    <button type="submit" class="botao" style="background:none;color:var(--primary-color);padding:0;border:none;">Marcar concluído</button>
                                </form>
                            <?php else: ?>
                                <span class="badge badge--verde">Concluído</span>
                            <?php endif; ?>
                        </td>
                        <td><?= formatarData($l['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($recebidos)): ?>
                    <tr><td colspan="5">Nenhum lembrete recebido.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <h3 style="margin-top:24px;">Lembretes que você enviou</h3>
        <table class="tabela-padrao">
            <thead><tr><th>Para</th><th>Título</th><th>Status</th><th>Data</th></tr></thead>
            <tbody>
                <?php foreach ($enviados as $l): ?>
                    <tr>
                        <td><?= escapar($l['destinatario_nome']) ?></td>
                        <td><?= escapar($l['titulo']) ?></td>
                        <td><?= $l['status'] === 'concluido' ? '<span class="badge badge--verde">Concluído</span>' : '<span class="badge badge--amarelo">Pendente</span>' ?></td>
                        <td><?= formatarData($l['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
                <?php if (empty($enviados)): ?>
                    <tr><td colspan="4">Você ainda não enviou lembretes.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php require __DIR__ . '/../app/views/layout-fim.php'; ?>
