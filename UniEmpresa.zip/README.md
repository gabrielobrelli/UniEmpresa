# UniEmpresa

Plataforma SaaS multiempresa de gestão comercial — PHP puro, MySQL
(PDO) e JavaScript Vanilla, desenvolvida para rodar em hospedagem
compartilhada (InfinityFree).

Um único Login Mestre administra várias empresas independentes.
Cada empresa tem seus próprios administradores, funcionários,
produtos, estoque, vendas, financeiro, jornada, chat e
configurações — nenhuma empresa acessa dados de outra.

## Stack

HTML5, CSS3, JavaScript Vanilla, PHP (PDO), MySQL. Sem frameworks
(sem React/Vue/Angular/Laravel/Bootstrap/Tailwind/Node.js).

## Estrutura de diretórios

```
/
├── index.php, login.php, logout.php, recuperar-senha.php, redefinir-senha.php
├── bootstrap.php            → ponto único de inicialização (incluído por toda página)
├── config/                  → configuração de banco, app e constantes (bloqueado por .htaccess)
├── app/
│   ├── models/               → acesso a dados (uma classe por entidade)
│   ├── middleware/Auth.php   → autenticação, permissões e isolamento por empresa
│   ├── helpers/               → sessão, CSRF, segurança, formatação, upload, backup, exportação
│   └── views/                 → layout compartilhado (sidebar/topo) e trechos reaproveitados (chat)
├── mestre/                    → telas do Login Mestre
├── admin/                     → telas do Administrador
├── funcionario/                → telas do Funcionário
├── api/                        → endpoints AJAX (PDV, chat, notificações)
├── install/instalar.php        → cria o primeiro Login Mestre (apagar após uso)
├── database/schema.sql         → estrutura completa do banco
├── storage/                    → arquivos internos (rate limiting, backups) — bloqueado por .htaccess
└── public/                     → CSS, JS e uploads de usuários
```

## Instalação no InfinityFree

1. **Criar o banco de dados MySQL** no painel do InfinityFree e anotar:
   nome do banco, usuário, senha e host MySQL (ex.: `sql306.infinityfree.com`).
2. **Abrir o phpMyAdmin** do painel e importar `database/schema.sql`
   (aba "Importar" → selecionar o arquivo → Executar).
3. **Configurar as credenciais** em `config/database.php`:
   ```php
   define('DB_HOST', 'seu-host-mysql');
   define('DB_NAME', 'nome-real-do-banco');
   define('DB_USER', 'seu-usuario');
   define('DB_PASS', 'sua-senha');
   ```
4. **Configurar a URL base** em `config/app.php` (constante `APP_URL_BASE`) com o domínio real do site.
5. **Enviar todos os arquivos** do projeto para a pasta pública do
   InfinityFree (geralmente `htdocs/`), mantendo a estrutura de pastas.
6. **Conferir permissões de pasta**: `storage/` e `public/uploads/`
   precisam de permissão de escrita (geralmente 755 já é suficiente
   no InfinityFree).
7. **Acessar o instalador** pelo navegador: `https://seu-dominio/install/instalar.php`
   — isso cria o primeiro Login Mestre.
8. **Apagar a pasta `install/` do servidor** imediatamente após o passo anterior.
9. **Acessar o sistema** em `https://seu-dominio/login.php` com as
   credenciais do Mestre e trocar a senha pelo próprio sistema assim que possível.

## Credenciais iniciais (ambiente desta implantação)

- **Usuário Mestre:** `gabrielobrelli@gmail.com`
- **Senha inicial:** definida no momento da instalação — troque assim que possível.
- **MySQL:** usuário `if0_42757432`, host `sql306.infinityfree.com`; nome do banco e senha devem ser conferidos/preenchidos em `config/database.php` conforme o painel do InfinityFree no momento da implantação.

Nenhuma senha de usuário é armazenada em texto puro — apenas o hash
gerado por `password_hash()`.

## Documentação complementar

- `SECURITY_CHECKLIST.md` — testes de segurança realizados (isolamento entre empresas, CSRF, XSS, SQL Injection, etc.).
- `DEPLOYMENT_CHECKLIST.md` — checklist final antes de considerar o sistema em produção.

## Código comentado

Todo arquivo PHP/JS do projeto segue o mesmo padrão de comentário:
cada função tem um bloco explicando o que ela faz e como faz, com
marcação de início/fim, para facilitar manutenção futura mesmo sem
conhecimento prévio do projeto.
