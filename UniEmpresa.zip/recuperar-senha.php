<?php
/**
 * =============================================================
 * ARQUIVO: recuperar-senha.php
 * RESPONSABILIDADE: primeira etapa da recuperação de senha —
 *                    o usuário informa o e-mail e recebe um link
 *                    com token válido por 30 minutos.
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/app/models/Usuario.php';
require_once __DIR__ . '/app/models/TokenRecuperacao.php';

$mensagem = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $ip = $_SERVER['REMOTE_ADDR'] ?? 'desconhecido';

    if (limiteDeTentativasExcedido('recuperar-senha:' . $ip, 5, 900)) {
        $mensagem = 'Muitas solicitações. Aguarde alguns minutos antes de tentar novamente.';
    } else {
        registrarTentativa('recuperar-senha:' . $ip, 900);

        $email = limparEntrada($_POST['email'] ?? '');
        $usuario = Usuario::buscarPorEmail($email);

        // IMPORTANTE: a mensagem exibida é SEMPRE a mesma, exista ou não
        // o e-mail no sistema. Isso evita que alguém use este formulário
        // para descobrir quais e-mails estão cadastrados na plataforma.
        if ($usuario) {
            $token = TokenRecuperacao::gerar((int) $usuario['id']);
            $link = rtrim(APP_URL_BASE, '/') . '/redefinir-senha.php?token=' . urlencode($token);

            // Em produção, este é o ponto de integração com um serviço de
            // e-mail (mail(), PHPMailer via SMTP, ou uma API de e-mail
            // transacional). O InfinityFree tem suporte limitado a mail(),
            // então o envio é tentado, mas o link também fica registrado
            // no log do servidor para o administrador conseguir recuperá-lo
            // manualmente caso o e-mail não chegue.
            $assunto = 'Recuperação de senha — ' . APP_NOME;
            $corpo = "Você solicitou a redefinição de senha.\n\n"
                . "Clique no link abaixo para criar uma nova senha (válido por 30 minutos):\n"
                . $link . "\n\n"
                . "Se você não solicitou isso, ignore este e-mail.";

            @mail($usuario['email'], $assunto, $corpo);
            error_log('[recuperacao-senha] link gerado para usuario_id=' . $usuario['id'] . ': ' . $link);
        }

        $mensagem = 'Se o e-mail informado estiver cadastrado, um link de recuperação foi enviado.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar senha — <?= escapar(APP_NOME) ?></title>
    <link rel="icon" type="image/png" href="/assets/img/empresa.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
</head>
<body class="pagina-login">

    <main class="cartao-login">
        <img src="/assets/img/empresa.png" alt="<?= escapar(APP_NOME) ?>" class="cartao-login__logo">
        <h1 class="cartao-login__titulo">Recuperar senha</h1>
        <p class="cartao-login__subtitulo">Informe seu e-mail de acesso</p>

        <?php if ($mensagem): ?>
            <div class="alerta alerta--info"><?= escapar($mensagem) ?></div>
        <?php else: ?>
            <form method="POST" action="/recuperar-senha.php" class="formulario-login">
                <?= csrfCampoOculto() ?>

                <label for="email">Usuário</label>
                <input type="text" id="email" name="email" required autofocus>

                <button type="submit" class="botao botao--primario">Enviar link de recuperação</button>
            </form>
        <?php endif; ?>

        <a href="/login.php" class="link-secundario">Voltar para o login</a>
    </main>

</body>
</html>
