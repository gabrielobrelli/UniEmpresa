# Checklist de Segurança e Testes — UniEmpresa

Este documento resume a verificação de segurança feita no sistema
antes da entrega final, seguindo a checklist de qualidade (seção 96)
e os testes de segurança (seção 97) do documento de requisitos.

## Autenticação
- [x] Login Mestre, Admin e Funcionário usam a mesma tela (`login.php`), diferenciados pelo `tipo` gravado na sessão.
- [x] Logout (`logout.php`) destrói a sessão e remove o cookie.
- [x] Recuperação de senha (`recuperar-senha.php` / `redefinir-senha.php`) usa token de uso único com hash SHA-256 armazenado (nunca o token em texto puro) e expiração de 30 minutos.
- [x] Rate limiting: 5 tentativas / 15 minutos tanto no login quanto na recuperação de senha (`app/helpers/seguranca.php`).

## Permissões
- [x] Funcionário não acessa telas de Admin: toda página em `/admin` chama `Auth::exigirTipo(TIPO_ADMIN)`.
- [x] Admin não acessa telas de Mestre: toda página em `/mestre` chama `Auth::exigirTipo(TIPO_MESTRE)`.
- [x] **Empresa A não acessa Empresa B**: nenhuma tela de Admin/Funcionário lê `empresa_id` do request (`$_GET`/`$_POST`) — todas usam `Auth::empresaIdEscopo()`, que vem exclusivamente da sessão. Todo model (`Produto`, `Categoria`, `Venda`, `Cliente`, etc.) exige `empresa_id` como parâmetro obrigatório em suas consultas.
- [x] Teste manual recomendado: logado como Admin da Empresa 1, tentar `GET /admin/produto-form.php?id=<id_de_produto_da_empresa_2>` → o model `Produto::buscarPorId($id, $empresaId)` retorna `null` porque o `WHERE empresa_id = :empresa_id` não bate, resultando em HTTP 404.

## Estoque
- [x] Entrada e saída sempre passam por `MovimentacaoEstoque`, nunca alteram `estoque_atual` diretamente em outro lugar do código.
- [x] Baixa automática na venda ocorre dentro da mesma transação da finalização (`Venda::finalizar`), com `FOR UPDATE` para evitar condição de corrida em vendas simultâneas do mesmo produto.
- [x] Estoque negativo é bloqueado por padrão, exceto quando o produto tem `permite_estoque_negativo = 1`.

## Vendas
- [x] Pagamento combinado validado com tolerância de 1 centavo (`Venda::finalizar`).
- [x] Duplo clique/duplo envio protegido em duas camadas: JS desabilita o botão de finalizar; backend verifica `status = 'aberta'` dentro da transação antes de prosseguir.
- [x] Cancelamento estorna estoque automaticamente quando a venda já estava finalizada.

## Financeiro
- [x] Toda venda finalizada gera lançamento financeiro automático (entrada).
- [x] Indicadores nunca são chamados de "lucro" — apenas "capital investido em estoque", "valor estimado do estoque" e "total vendido" (`Financeiro::balancoOperacional`).

## Funcionários
- [x] Cadastro sempre com `perfil_completo = 0`; middleware força a tela de completar perfil antes de liberar qualquer outra página.
- [x] Feedback só pode ser criado pelo Admin da mesma empresa do funcionário (checagem de `empresa_id` em `admin/funcionario-feedback.php`).

## Jornada
- [x] `Jornada::iniciar()` não cria uma segunda jornada aberta se já existir uma.
- [x] Meta comparada em minutos, evitando erro de arredondamento de horas fracionadas.

## Comunicação
- [x] Chat: `Conversa::podeConversarCom()` é reavaliado no backend a cada tentativa de abrir conversa — a lista de contatos mostrada na tela é só uma sugestão visual.
- [x] `Mensagem`/`Conversa`: toda leitura/envio confirma `participaDaConversa()` antes de agir.
- [x] Notificações e lembretes sempre gravados com o `usuario_id` de destino explícito — nunca "para todos" sem filtro.

## Empresa (multiempresa)
- [x] Congelamento preserva todos os dados; apenas bloqueia login (`Auth::verificarEmpresaAtiva()`), com mensagem personalizada exibida no login.
- [x] Reativação limpa os campos de congelamento e libera o acesso imediatamente.

## Backup
- [x] Backup de empresa contém somente tabelas filtradas por `empresa_id` da sessão.
- [x] Backups salvos fora da pasta pública (`storage/backups/`), protegida por `.htaccess` (`Require all denied`).
- [x] Download revalida sessão e propriedade do arquivo a cada requisição — não existe URL pública direta para um backup.
- [x] Nenhuma senha em texto puro é incluída (a tabela `usuarios` só armazena `senha_hash`); credenciais de conexão do `config/database.php` nunca entram no dump.

## Testes de segurança (seção 97)
| Teste | Resultado |
|---|---|
| SQL Injection | Todas as consultas usam PDO com prepared statements e parâmetros amarrados; nenhuma concatenação de entrada do usuário em SQL. |
| XSS | Toda saída de dado dinâmico passa por `escapar()` (htmlspecialchars). |
| CSRF | Todo formulário inclui `csrfCampoOculto()`; todo POST valida com `csrfValidarOuFalhar()` (comparação com `hash_equals`). |
| Acesso direto a páginas | Todas as páginas internas chamam `Auth::exigirTipo()` ou `Auth::exigirLogin()` antes de qualquer processamento. |
| Manipulação de `empresa_id` | Impossível via request — o valor usado em toda consulta vem de `Auth::empresaIdEscopo()` (sessão), nunca de `$_GET`/`$_POST`. |
| Manipulação de IDs (produto, venda, cliente, funcionário) | Todo `buscarPorId()` exige `empresa_id` como segundo parâmetro obrigatório. |
| Escalada de privilégio | `$_SESSION['tipo']` é definido apenas em `iniciarLogin()`, a partir do banco — nunca aceito de input do usuário. |
| Sessão expirada | `SESSAO_TIMEOUT_MINUTOS` (30 min) verificado em toda chamada a `iniciarSessao()`. |
| Usuário desativado | `login.php` exige `status = 'ativo'` no momento da autenticação. |
| Empresa congelada | Bloqueada em toda requisição autenticada via `Auth::verificarEmpresaAtiva()`, não apenas no login. |
| Upload malicioso | MIME real validado via `finfo`; nome de arquivo aleatório; `.htaccess` em `public/uploads/` bloqueia execução de scripts mesmo em caso de bypass de MIME. |

## Observações e limitações conhecidas
- O `logout.php` aceita GET por simplicidade (prática comum); na pior hipótese um link forjado apenas desloga o usuário, sem expor dados.
- O rate limiting é baseado em arquivo (compatível com hospedagem compartilhada sem Redis/Memcached); em caso de múltiplos servidores atrás de um balanceador, cada servidor teria seu próprio contador — não é um problema no InfinityFree, que serve de um único ponto.
- A pasta `/install` deve ser **removida do servidor** após a criação do primeiro usuário Mestre, conforme instruções em `install/instalar.php`.
