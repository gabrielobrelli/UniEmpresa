<?php
/**
 * Configurações gerais da aplicação.
 */

date_default_timezone_set('America/Sao_Paulo');

define('APP_NOME', 'UniEmpresa');
define('APP_AMBIENTE', 'producao'); // 'desenvolvimento' | 'producao'
define('APP_URL_BASE', 'https://SEU_DOMINIO_AQUI');
define('APP_MOEDA', 'BRL');
define('APP_LOCALE', 'pt_BR');

// Exibição de erros: nunca exibir detalhes técnicos em produção.
if (APP_AMBIENTE === 'desenvolvimento') {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(E_ALL);
}

// Sessão segura
ini_set('session.cookie_httponly', '1');
ini_set('session.use_strict_mode', '1');
if (!empty($_SERVER['HTTPS'])) {
    ini_set('session.cookie_secure', '1');
}

// IMPORTANTE: usamos uma pasta de sessão PRÓPRIA, dentro do projeto,
// em vez do /tmp padrão do servidor. Em hospedagens compartilhadas
// gratuitas (como o InfinityFree), a pasta temporária padrão é
// dividida entre MUITAS contas diferentes e costuma ter uma limpeza
// automática agressiva — o que pode apagar o arquivo de sessão de um
// usuário no meio do uso, fazendo-o "perder o login" do nada e
// esbarrar em checagens de permissão (ex.: 403) sem motivo aparente.
// Com uma pasta exclusiva do próprio projeto, isso deixa de depender
// da limpeza alheia.
$pastaSessoes = __DIR__ . '/../storage/sessions';
if (!is_dir($pastaSessoes)) {
    mkdir($pastaSessoes, 0755, true);
}
session_save_path($pastaSessoes);

define('SESSAO_TIMEOUT_MINUTOS', 30);
