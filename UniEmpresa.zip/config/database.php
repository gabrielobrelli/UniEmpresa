<?php
/**
 * Configuração central de conexão com o banco de dados.
 * Nenhum outro arquivo do sistema deve conter credenciais de banco:
 * tudo passa por aqui e por getPDO().
 */

define('DB_HOST', 'sql306.infinityfree.com');
define('DB_NAME', 'if0_42757432_uniempresa');
define('DB_USER', 'if0_42757432');
define('DB_PASS', 'idn78910');
define('DB_CHARSET', 'utf8mb4');

/**
 * Retorna a conexão PDO ativa, criando-a apenas uma vez por requisição.
 */
function getPDO(): PDO
{
    static $pdo = null;

    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ]);
        } catch (PDOException $e) {
            // Nunca expor detalhes de conexão ao usuário final.
            error_log('Falha na conexão com o banco: ' . $e->getMessage());
            http_response_code(500);
            die('Não foi possível conectar ao sistema no momento. Tente novamente em instantes.');
        }
    }

    return $pdo;
}
