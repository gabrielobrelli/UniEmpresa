<?php
/**
 * Constantes de níveis de acesso e status.
 * Usar sempre estas constantes em vez de strings soltas no código.
 */

// Níveis de usuário
const TIPO_MESTRE = 'mestre';
const TIPO_ADMIN = 'admin';
const TIPO_FUNCIONARIO = 'funcionario';

// Status de empresa
const EMPRESA_ATIVA = 'ativa';
const EMPRESA_CONGELADA = 'congelada';
const EMPRESA_INATIVA = 'inativa';

// Status de venda
const VENDA_ABERTA = 'aberta';
const VENDA_FINALIZADA = 'finalizada';
const VENDA_CANCELADA = 'cancelada';
const VENDA_DEVOLVIDA = 'devolvida';
const VENDA_PARCIAL_DEVOLVIDA = 'parcial_devolvida';

// Prioridades de notificação/lembrete
const PRIORIDADE_VERDE = 'verde';
const PRIORIDADE_AMARELO = 'amarelo';
const PRIORIDADE_VERMELHO = 'vermelho';

// Formas de pagamento
const PAGAMENTO_DINHEIRO = 'dinheiro';
const PAGAMENTO_PIX = 'pix';
const PAGAMENTO_DEBITO = 'debito';
const PAGAMENTO_CREDITO = 'credito';
const PAGAMENTO_OUTRO = 'outro';
