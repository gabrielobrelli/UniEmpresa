<?php
/**
 * =============================================================
 * ARQUIVO: app/views/comunicacao-corpo.php
 * RESPONSABILIDADE: HTML da tela de chat, compartilhado pelas
 *                    três áreas (mestre/comunicacao.php, admin/comunicacao.php,
 *                    funcionario/comunicacao.php). A lista de contatos
 *                    exibida já vem filtrada pelo backend
 *                    (Conversa::contatosPermitidos), então a
 *                    interface não precisa (e não deve) reaplicar
 *                    nenhuma regra de permissão — ela só mostra o
 *                    que a API decidiu que é permitido.
 * =============================================================
 */
?>
<div class="chat">
    <aside class="chat__contatos">
        <h3 style="margin-top:0;">Conversas</h3>
        <div id="chat-lista-conversas"></div>

        <h3>Iniciar nova conversa</h3>
        <div id="chat-lista-contatos"></div>
    </aside>

    <section class="chat__janela">
        <div id="chat-cabecalho-conversa" class="chat__cabecalho">Selecione uma conversa</div>
        <div id="chat-mensagens" class="chat__mensagens"></div>
        <form id="chat-form-envio" class="chat__envio" style="display:none;">
            <input type="text" id="chat-texto" placeholder="Digite sua mensagem..." autocomplete="off">
            <button type="submit" class="botao botao--primario">Enviar</button>
        </form>
    </section>
</div>

<link rel="stylesheet" href="/public/css/comunicacao.css">
<script src="/public/js/comunicacao.js"></script>
