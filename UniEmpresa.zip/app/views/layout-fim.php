        </main>
    </div>
</div>
<script>
    window.APP_CSRF_TOKEN = <?= json_encode(csrfToken()) ?>;
    window.APP_USUARIO_ID = <?= json_encode(usuarioId()) ?>;
</script>
<script src="/public/js/notificacoes.js"></script>
<script src="/public/js/layout.js"></script>
</body>
</html>
