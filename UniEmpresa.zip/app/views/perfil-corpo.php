<?php
/**
 * =============================================================
 * ARQUIVO: app/views/perfil-corpo.php
 * RESPONSABILIDADE: HTML do formulário de "meu perfil", compartilhado
 *                    pelas três áreas (mestre/perfil.php,
 *                    admin/perfil.php, funcionario/perfil.php).
 *
 * Variáveis esperadas antes do include:
 *   $usuario (array com os dados atuais), $erro, $sucesso
 * =============================================================
 */
?>

<div class="cartao-formulario">
    <?php if ($erro): ?>
        <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
    <?php endif; ?>
    <?php if ($sucesso): ?>
        <div class="alerta alerta--sucesso">Perfil atualizado com sucesso!</div>
    <?php endif; ?>

    <div style="display:flex; align-items:center; gap:16px; margin-bottom:20px;">
        <div style="width:72px; height:72px; border-radius:50%; overflow:hidden; background:var(--primary-color); display:flex; align-items:center; justify-content:center; flex-shrink:0;">
            <?php if (!empty($usuario['foto'])): ?>
                <img src="<?= escapar($usuario['foto']) ?>" alt="Foto de perfil" style="width:100%; height:100%; object-fit:cover;">
            <?php else: ?>
                <span style="color:#fff; font-size:26px; font-weight:700;"><?= escapar(mb_strtoupper(mb_substr($usuario['nome'], 0, 1))) ?></span>
            <?php endif; ?>
        </div>
        <div>
            <div style="font-weight:700; font-size:16px;"><?= escapar($usuario['nome']) ?></div>
            <div style="color:var(--cor-texto-suave); font-size:13px;"><?= escapar(ucfirst($usuario['tipo'])) ?></div>
        </div>
    </div>

    <form method="POST" action="" enctype="multipart/form-data">
        <?= csrfCampoOculto() ?>

        <div class="campo">
            <label for="foto">Foto de perfil</label>
            <input type="file" id="foto" name="foto" accept=".jpg,.jpeg,.png,.webp">
        </div>

        <div class="campo">
            <label for="nome">Nome completo *</label>
            <input type="text" id="nome" name="nome" required value="<?= escapar($usuario['nome']) ?>">
        </div>

        <div class="campo">
            <label for="email">E-mail de acesso (usado para login) *</label>
            <input type="text" id="email" name="email" required value="<?= escapar($usuario['email']) ?>">
        </div>

        <div class="campo">
            <label for="telefone">Telefone</label>
            <input type="text" id="telefone" name="telefone" value="<?= escapar($usuario['telefone'] ?? '') ?>">
        </div>

        <div class="campo">
            <label for="bio">Bio/descrição curta</label>
            <textarea id="bio" name="bio" rows="3" placeholder="Fale um pouco sobre você (opcional)"><?= escapar($usuario['observacoes'] ?? '') ?></textarea>
        </div>

        <button type="submit" class="botao botao--primario">Salvar alterações</button>
    </form>
</div>

<div class="cartao-formulario">
    <h3 style="margin-top:0;">Alterar senha</h3>

    <form method="POST" action="">
        <?= csrfCampoOculto() ?>
        <input type="hidden" name="acao" value="trocar_senha">

        <div class="linha-campos">
            <div class="campo">
                <label for="senha_nova">Nova senha</label>
                <input type="password" id="senha_nova" name="senha_nova" minlength="8">
            </div>
            <div class="campo">
                <label for="senha_confirmacao">Confirme a nova senha</label>
                <input type="password" id="senha_confirmacao" name="senha_confirmacao" minlength="8">
            </div>
        </div>

        <button type="submit" class="botao botao--secundario">Trocar senha</button>
    </form>
</div>
