<?php
/**
 * =============================================================
 * ARQUIVO: app/views/layout-inicio.php
 * RESPONSABILIDADE: abrir o HTML comum a todas as telas internas
 *                    (logadas) do sistema — cabeçalho, sidebar e
 *                    início do conteúdo principal.
 *
 * COMO USAR: cada página define duas variáveis antes de incluir
 *            este arquivo:
 *   $tituloPagina = 'Empresas';       // aparece na aba do navegador
 *   $itemMenuAtivo = 'empresas';      // destaca o item correto do menu
 * e no final da página inclui app/views/layout-fim.php.
 *
 * O menu exibido muda de acordo com usuarioTipo() — Mestre,
 * Administrador e Funcionário veem opções diferentes (seção 84
 * do documento de requisitos).
 * =============================================================
 */

$tituloPagina = $tituloPagina ?? APP_NOME;
$itemMenuAtivo = $itemMenuAtivo ?? '';

/**
 * BLOCO: personalização visual por empresa (seção 38/91)
 * O QUE FAZ: se o usuário logado pertence a uma empresa (admin ou
 *            funcionário), busca as cores/textos configurados por ela
 *            e monta um bloco <style> que sobrescreve as variáveis
 *            CSS padrão definidas em base.css, além de usar o logo da
 *            empresa como favicon e o nome dela no título da aba — a
 *            ideia é que o painel realmente pareça pertencer à
 *            empresa, não a um sistema genérico. O Mestre não tem
 *            empresa, então sempre vê o tema padrão da plataforma.
 * FIM DO BLOCO
 */
$estiloPersonalizado = '';
$nomeExibidoNoMenu = APP_NOME;
$logoEmpresa = null;
$sloganEmpresa = '';
$rodapeEmpresa = '';

if (usuarioEmpresaId() !== null) {
    $pdo = getPDO();
    $stmt = $pdo->prepare('SELECT nome_fantasia, logo, cor_primaria, cor_secundaria, cor_destaque FROM empresas WHERE id = :id');
    $stmt->execute([':id' => usuarioEmpresaId()]);
    $empresaAtual = $stmt->fetch();

    if ($empresaAtual) {
        $nomeExibidoNoMenu = $empresaAtual['nome_fantasia'];
        $logoEmpresa = $empresaAtual['logo'];
        $estiloPersonalizado = sprintf(
            ':root { --primary-color: %s; --secondary-color: %s; --accent-color: %s; }',
            escapar($empresaAtual['cor_primaria']),
            escapar($empresaAtual['cor_secundaria']),
            escapar($empresaAtual['cor_destaque'])
        );

        require_once __DIR__ . '/../models/ConfiguracaoEmpresa.php';
        $sloganEmpresa = ConfiguracaoEmpresa::obter(usuarioEmpresaId(), 'slogan');
        $rodapeEmpresa = ConfiguracaoEmpresa::obter(usuarioEmpresaId(), 'rodape');
    }
}

$faviconAtual = $logoEmpresa ?: '/assets/img/empresa.png';
$tituloAba = $nomeExibidoNoMenu !== APP_NOME
    ? $tituloPagina . ' — ' . $nomeExibidoNoMenu
    : $tituloPagina . ' — ' . APP_NOME;

/**
 * FUNÇÃO: itemMenu()
 * O QUE FAZ: monta o HTML de um item de menu, com ícone e marcação
 *            de item ativo (destaca a página atual na navegação).
 * FIM DA FUNÇÃO
 */
function itemMenu(string $chave, string $rotulo, string $href, string $ativo, string $icone = ''): string
{
    $classe = $chave === $ativo ? 'menu-lateral__link menu-lateral__link--ativo' : 'menu-lateral__link';
    $spanIcone = $icone !== '' ? '<span class="menu-lateral__icone">' . $icone . '</span>' : '';
    return '<a href="' . escapar($href) . '" class="' . $classe . '">' . $spanIcone . escapar($rotulo) . '</a>';
}

/**
 * FUNÇÃO: secaoMenu()
 * O QUE FAZ: imprime um pequeno rótulo de seção dentro da sidebar
 *            (ex.: "CADASTROS", "OPERAÇÃO"), para organizar visualmente
 *            um menu com muitos itens em grupos fáceis de escanear.
 * FIM DA FUNÇÃO
 */
function secaoMenu(string $titulo): string
{
    return '<div class="menu-lateral__secao">' . escapar($titulo) . '</div>';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= escapar($tituloAba) ?></title>
    <link rel="icon" type="image/png" href="<?= escapar($faviconAtual) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/layout.css">
    <?php if ($estiloPersonalizado): ?>
        <style><?= $estiloPersonalizado /* já escapado campo a campo acima */ ?></style>
    <?php endif; ?>
</head>
<body>
<div class="layout">

    <div id="overlay-menu-mobile" class="overlay-menu-mobile"></div>

    <aside class="menu-lateral" id="menu-lateral">
        <div class="menu-lateral__marca">
            <img src="<?= escapar($logoEmpresa ?: '/assets/img/empresa.png') ?>" alt="Logo" class="menu-lateral__logo">
            <div>
                <div class="menu-lateral__nome-empresa"><?= escapar($nomeExibidoNoMenu) ?></div>
                <?php if ($sloganEmpresa): ?>
                    <div class="menu-lateral__slogan"><?= escapar($sloganEmpresa) ?></div>
                <?php endif; ?>
            </div>
        </div>

        <nav class="menu-lateral__nav">
            <?php if (usuarioTipo() === TIPO_MESTRE): ?>
                <?= itemMenu('dashboard', 'Dashboard', '/mestre/index.php', $itemMenuAtivo, '📊') ?>
                <?= secaoMenu('Plataforma') ?>
                <?= itemMenu('empresas', 'Empresas', '/mestre/empresas.php', $itemMenuAtivo, '🏢') ?>
                <?= itemMenu('administradores', 'Administradores', '/mestre/administradores.php', $itemMenuAtivo, '👤') ?>
                <?= secaoMenu('Comunicação') ?>
                <?= itemMenu('chat', 'Chat', '/mestre/comunicacao.php', $itemMenuAtivo, '💬') ?>
                <?= itemMenu('notificacoes', 'Notificações', '/mestre/notificacoes.php', $itemMenuAtivo, '🔔') ?>
                <?= secaoMenu('Sistema') ?>
                <?= itemMenu('backup', 'Backup', '/mestre/backup.php', $itemMenuAtivo, '💾') ?>
                <?= secaoMenu('Conta') ?>
                <?= itemMenu('perfil', 'Meu perfil', '/mestre/perfil.php', $itemMenuAtivo, '🙍') ?>
            <?php elseif (usuarioTipo() === TIPO_ADMIN): ?>
                <?= itemMenu('dashboard', 'Dashboard', '/admin/index.php', $itemMenuAtivo, '📊') ?>
                <?= secaoMenu('Vendas') ?>
                <?= itemMenu('vendas', 'Vendas', '/admin/vendas.php', $itemMenuAtivo, '🧾') ?>
                <?= itemMenu('clientes', 'Clientes', '/admin/clientes.php', $itemMenuAtivo, '🙋') ?>
                <?= itemMenu('ranking', 'Ranking', '/admin/ranking.php', $itemMenuAtivo, '🏆') ?>
                <?= secaoMenu('Cadastros') ?>
                <?= itemMenu('produtos', 'Produtos', '/admin/produtos.php', $itemMenuAtivo, '📦') ?>
                <?= itemMenu('categorias', 'Categorias', '/admin/categorias.php', $itemMenuAtivo, '🏷️') ?>
                <?= itemMenu('fornecedores', 'Fornecedores', '/admin/fornecedores.php', $itemMenuAtivo, '🚚') ?>
                <?= itemMenu('unidades', 'Unidades de medida', '/admin/unidades.php', $itemMenuAtivo, '📏') ?>
                <?= secaoMenu('Operação') ?>
                <?= itemMenu('estoque', 'Estoque', '/admin/estoque.php', $itemMenuAtivo, '📥') ?>
                <?= itemMenu('financeiro', 'Financeiro', '/admin/financeiro.php', $itemMenuAtivo, '💰') ?>
                <?= itemMenu('jornada', 'Jornada', '/admin/jornada.php', $itemMenuAtivo, '⏱️') ?>
                <?= itemMenu('relatorios', 'Relatórios', '/admin/relatorios.php', $itemMenuAtivo, '📈') ?>
                <?= secaoMenu('Equipe') ?>
                <?= itemMenu('funcionarios', 'Funcionários', '/admin/funcionarios.php', $itemMenuAtivo, '👥') ?>
                <?= secaoMenu('Comunicação') ?>
                <?= itemMenu('chat', 'Chat', '/admin/comunicacao.php', $itemMenuAtivo, '💬') ?>
                <?= itemMenu('lembretes', 'Lembretes', '/admin/lembretes.php', $itemMenuAtivo, '📌') ?>
                <?= secaoMenu('Empresa') ?>
                <?= itemMenu('personalizacao', 'Personalização', '/admin/personalizacao.php', $itemMenuAtivo, '🎨') ?>
                <?= itemMenu('configuracoes', 'Configurações', '/admin/configuracoes.php', $itemMenuAtivo, '⚙️') ?>
                <?= itemMenu('backup', 'Backup', '/admin/backup.php', $itemMenuAtivo, '💾') ?>
                <?= secaoMenu('Conta') ?>
                <?= itemMenu('perfil', 'Meu perfil', '/admin/perfil.php', $itemMenuAtivo, '🙍') ?>
            <?php elseif (usuarioTipo() === TIPO_FUNCIONARIO): ?>
                <?= itemMenu('jornada', 'Minha jornada', '/funcionario/jornada.php', $itemMenuAtivo, '⏱️') ?>
                <?= itemMenu('dashboard', 'Dashboard', '/funcionario/index.php', $itemMenuAtivo, '📊') ?>
                <?= secaoMenu('Vendas') ?>
                <?= itemMenu('nova-venda', 'Nova venda', '/funcionario/nova-venda.php', $itemMenuAtivo, '🧾') ?>
                <?= itemMenu('minhas-vendas', 'Minhas vendas', '/funcionario/minhas-vendas.php', $itemMenuAtivo, '📋') ?>
                <?= itemMenu('desempenho', 'Meu desempenho', '/funcionario/desempenho.php', $itemMenuAtivo, '📈') ?>
                <?= secaoMenu('Comunicação') ?>
                <?= itemMenu('chat', 'Chat', '/funcionario/comunicacao.php', $itemMenuAtivo, '💬') ?>
                <?= itemMenu('lembretes', 'Lembretes', '/funcionario/lembretes.php', $itemMenuAtivo, '📌') ?>
                <?= secaoMenu('Conta') ?>
                <?= itemMenu('perfil', 'Meu perfil', '/funcionario/perfil.php', $itemMenuAtivo, '🙍') ?>
            <?php endif; ?>
        </nav>

        <?php if ($rodapeEmpresa): ?>
            <div style="padding: 0 20px 10px; font-size: 11px; color: rgba(255,255,255,0.55);">
                <?= escapar($rodapeEmpresa) ?>
            </div>
        <?php endif; ?>
        <a href="/logout.php" class="menu-lateral__sair">↩ Sair</a>
    </aside>

    <div class="area-principal">
        <header class="topo">
            <div style="display:flex; align-items:center; gap:14px;">
                <button type="button" id="botao-menu-mobile" class="botao-menu-mobile" aria-label="Abrir menu">☰</button>
                <h1 class="topo__titulo"><?= escapar($tituloPagina) ?></h1>
            </div>
            <div style="display:flex; align-items:center; gap:20px;">
                <div class="sino-notificacoes" id="sino-notificacoes">
                    <button type="button" id="botao-sino" class="sino-notificacoes__botao" title="Notificações">
                        🔔<span id="sino-contador" class="sino-notificacoes__contador" style="display:none;">0</span>
                    </button>
                    <div id="sino-lista" class="sino-notificacoes__lista" style="display:none;"></div>
                </div>
                <div class="topo__usuario">
                    <span class="topo__avatar"><?= escapar(mb_strtoupper(mb_substr($_SESSION['nome'] ?? '?', 0, 1))) ?></span>
                    <?= escapar($_SESSION['nome'] ?? '') ?>
                </div>
            </div>
        </header>

        <main class="conteudo">
