<?php
/**
 * =============================================================
 * ARQUIVO: app/views/estado-vazio.php
 * RESPONSABILIDADE: bloco visual reaproveitável para quando uma
 *                    listagem não tem nenhum resultado (nenhuma
 *                    empresa cadastrada, nenhum cliente, etc.).
 *
 * COMO USAR: definir $mensagemVazia antes de incluir este arquivo:
 *
 *     $mensagemVazia = 'Nenhum cliente cadastrado ainda.';
 *     require __DIR__ . '/../app/views/estado-vazio.php';
 * =============================================================
 */

$mensagemVazia = $mensagemVazia ?? 'Nada foi encontrado.';
?>
<div class="estado-vazio">
    <img src="/assets/img/nadaencontrado.png" alt="" class="estado-vazio__imagem" onerror="this.style.display='none'">
    <p class="estado-vazio__texto"><?= escapar($mensagemVazia) ?></p>
</div>
