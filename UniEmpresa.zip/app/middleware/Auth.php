<?php
/**
 * =============================================================
 * ARQUIVO: app/middleware/Auth.php
 * RESPONSABILIDADE: concentrar todas as verificações de "quem
 *                    pode fazer o quê" no sistema. Nenhuma tela
 *                    (admin, funcionário, mestre) deve confiar em
 *                    esconder botões — a permissão de verdade é
 *                    sempre checada aqui, no servidor.
 *
 * COMO USAR: no topo de qualquer página protegida, logo após o
 * require do bootstrap.php:
 *
 *     Auth::exigirLogin();                 // qualquer usuário logado
 *     Auth::exigirTipo(TIPO_ADMIN);        // só administradores
 *     Auth::exigirTipo([TIPO_ADMIN, TIPO_FUNCIONARIO]); // um dos dois
 * =============================================================
 */

class Auth
{
    /**
     * FUNÇÃO: exigirLogin()
     * O QUE FAZ: garante que existe um usuário autenticado na sessão.
     *            Caso não exista, redireciona para a tela de login.
     * COMO FAZ: usa usuarioLogado() (helper de sessão). Se a checagem
     *           falhar, chama exit para impedir que o restante da
     *           página protegida seja executado.
     * FIM DA FUNÇÃO
     */
    public static function exigirLogin(): void
    {
        if (!usuarioLogado()) {
            header('Location: /login.php');
            exit;
        }

        // Usuário autenticado: aproveita para verificar se a empresa
        // dele (quando houver) continua ativa.
        self::verificarEmpresaAtiva();

        // Funcionário com perfil incompleto é obrigado a completá-lo
        // antes de usar qualquer outra tela do sistema (seção 13).
        self::verificarPerfilCompleto();

        // Atualiza o "carimbo" de última atividade, usado para o
        // indicador online/offline (seção 50 do documento).
        Usuario::atualizarUltimaAtividade(usuarioId());
    }

    /**
     * FUNÇÃO: verificarPerfilCompleto()
     * O QUE FAZ: se o usuário logado tiver perfil_completo = 0,
     *            força o redirecionamento para a tela de completar
     *            perfil (seção 13), exceto quando ele já está nessa
     *            tela ou está saindo do sistema — o que causaria um
     *            loop infinito de redirecionamentos.
     * FIM DA FUNÇÃO
     */
    private static function verificarPerfilCompleto(): void
    {
        if (empty($_SESSION['perfil_completo_pendente'])) {
            return;
        }

        $scriptAtual = $_SERVER['SCRIPT_NAME'] ?? '';
        $telasPermitidas = ['completar-perfil.php', 'logout.php'];

        foreach ($telasPermitidas as $telaPermitida) {
            if (str_ends_with($scriptAtual, $telaPermitida)) {
                return;
            }
        }

        header('Location: /funcionario/completar-perfil.php');
        exit;
    }

    /**
     * FUNÇÃO: exigirTipo()
     * O QUE FAZ: além de exigir login, garante que o usuário logado
     *            é de um dos tipos permitidos para aquela página.
     * PARÂMETROS: $tiposPermitidos pode ser uma string única
     *             ('admin') ou um array (['admin', 'funcionario']).
     * COMO FAZ: normaliza para array e verifica se usuarioTipo()
     *           está na lista; caso contrário, devolve HTTP 403 e
     *           encerra a execução.
     * FIM DA FUNÇÃO
     */
    public static function exigirTipo($tiposPermitidos): void
    {
        self::exigirLogin();

        $tiposPermitidos = is_array($tiposPermitidos) ? $tiposPermitidos : [$tiposPermitidos];

        if (!in_array(usuarioTipo(), $tiposPermitidos, true)) {
            http_response_code(403);
            die('Acesso negado: você não tem permissão para acessar esta página.');
        }
    }

    /**
     * FUNÇÃO: verificarEmpresaAtiva()
     * O QUE FAZ: se o usuário logado pertence a uma empresa (ou seja,
     *            não é o Mestre), verifica o status dessa empresa.
     *            Caso esteja congelada ou inativa, encerra a sessão e
     *            mostra a mensagem configurada pelo Mestre no momento
     *            do congelamento.
     * COMO FAZ: consulta a tabela `empresas` pelo empresa_id da
     *           sessão. Esta é uma verificação de servidor, então
     *           mesmo que o usuário tenha uma sessão válida, ele é
     *           barrado assim que a empresa muda de status.
     * FIM DA FUNÇÃO
     */
    private static function verificarEmpresaAtiva(): void
    {
        $empresaId = usuarioEmpresaId();

        // Login Mestre não pertence a nenhuma empresa — nada a checar.
        if ($empresaId === null) {
            return;
        }

        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT status, mensagem_congelamento FROM empresas WHERE id = :id LIMIT 1');
        $stmt->execute([':id' => $empresaId]);
        $empresa = $stmt->fetch();

        if (!$empresa || $empresa['status'] !== EMPRESA_ATIVA) {
            $mensagem = $empresa['mensagem_congelamento']
                ?? 'O acesso da sua empresa está temporariamente bloqueado. Entre em contato com o suporte.';

            encerrarSessao();
            iniciarSessao();
            $_SESSION['mensagem_bloqueio'] = $mensagem;

            header('Location: /login.php?bloqueado=1');
            exit;
        }
    }

    /**
     * FUNÇÃO: empresaIdEscopo()
     * O QUE FAZ: devolve o empresa_id que DEVE ser usado em qualquer
     *            consulta feita pelo usuário logado (admin ou
     *            funcionário). O Mestre não usa esta função, pois
     *            acessa todas as empresas.
     * POR QUE EXISTE: centraliza a regra "nunca confie no empresa_id
     *                 vindo do formulário/query string" — todo model
     *                 de dados operacionais deve chamar esta função
     *                 em vez de ler $_POST['empresa_id'] ou similar.
     * FIM DA FUNÇÃO
     */
    public static function empresaIdEscopo(): int
    {
        $empresaId = usuarioEmpresaId();

        if ($empresaId === null) {
            // Um usuário sem empresa tentando acessar uma rota que
            // exige escopo de empresa é sempre um erro de fluxo/uso
            // indevido — bloqueia por segurança.
            http_response_code(403);
            die('Acesso negado.');
        }

        return $empresaId;
    }
}
