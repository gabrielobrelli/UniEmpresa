<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/csrf.php
 * RESPONSABILIDADE: proteger formulários e requisições POST/AJAX
 *                    contra ataques CSRF (Cross-Site Request Forgery).
 *
 * A ideia geral: cada sessão recebe um token aleatório único.
 * Esse token é incluído em todo formulário (campo escondido) e em
 * todo cabeçalho de requisição AJAX. No backend, antes de processar
 * qualquer ação que altere dados, comparamos o token recebido com
 * o token da sessão. Se forem diferentes (ou ausentes), a
 * requisição é rejeitada.
 * =============================================================
 */

/**
 * FUNÇÃO: csrfToken()
 * O QUE FAZ: devolve o token CSRF da sessão atual, criando um novo
 *            caso ainda não exista.
 * COMO FAZ: usa random_bytes() (gerador criptograficamente seguro)
 *           e converte para hexadecimal para poder colocar em HTML.
 * FIM DA FUNÇÃO
 */
function csrfToken(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/**
 * FUNÇÃO: csrfCampoOculto()
 * O QUE FAZ: gera o HTML de um <input type="hidden"> pronto para
 *            ser inserido dentro de qualquer <form> do sistema.
 * FIM DA FUNÇÃO
 */
function csrfCampoOculto(): string
{
    $token = htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8');
    return '<input type="hidden" name="csrf_token" value="' . $token . '">';
}

/**
 * FUNÇÃO: csrfValidarOuFalhar()
 * O QUE FAZ: verifica se o token enviado pelo cliente (via POST
 *            'csrf_token' ou cabeçalho 'X-CSRF-Token') bate com o
 *            token da sessão. Se não bater, interrompe a execução
 *            imediatamente com HTTP 419 (token expirado/inválido).
 * COMO FAZ: usa hash_equals() em vez de '===' para comparar os
 *           tokens — isso evita ataques de "timing attack", em que
 *           um atacante mede o tempo de resposta para descobrir o
 *           token caractere por caractere.
 * FIM DA FUNÇÃO
 */
function csrfValidarOuFalhar(): void
{
    $tokenEnviado = $_POST['csrf_token']
        ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');

    $tokenSessao = $_SESSION['csrf_token'] ?? '';

    if ($tokenSessao === '' || !hash_equals($tokenSessao, $tokenEnviado)) {
        http_response_code(419);
        die('Sessão expirada ou inválida. Atualize a página e tente novamente.');
    }
}
