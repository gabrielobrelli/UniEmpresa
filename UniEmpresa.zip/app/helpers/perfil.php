<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/perfil.php
 * RESPONSABILIDADE: processar o formulário de "meu perfil" — dados
 *                    pessoais, foto e troca de senha. A mesma lógica
 *                    vale para Mestre, Admin e Funcionário, então
 *                    fica centralizada aqui em vez de duplicada nos
 *                    três arquivos de tela.
 * =============================================================
 */

/**
 * FUNÇÃO: processarFormularioPerfil()
 * O QUE FAZ: lê o POST da tela de perfil (dados pessoais OU troca de
 *            senha, dependendo do formulário enviado) e aplica as
 *            alterações para o usuário atualmente logado.
 * DEVOLVE: ['erro' => string|null, 'sucesso' => bool]
 * FIM DA FUNÇÃO
 */
function processarFormularioPerfil(): array
{
    $erro = null;
    $sucesso = false;

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return ['erro' => $erro, 'sucesso' => $sucesso];
    }

    csrfValidarOuFalhar();

    if (($_POST['acao'] ?? '') === 'trocar_senha') {
        $novaSenha = (string) ($_POST['senha_nova'] ?? '');
        $confirmacao = (string) ($_POST['senha_confirmacao'] ?? '');

        if (strlen($novaSenha) < 8) {
            $erro = 'A nova senha deve ter pelo menos 8 caracteres.';
        } elseif ($novaSenha !== $confirmacao) {
            $erro = 'A confirmação de senha não confere.';
        } else {
            Usuario::atualizarSenha(usuarioId(), $novaSenha);
            Auditoria::registrar('senha_alterada_pelo_proprio_usuario', 'usuarios', usuarioId());
            $sucesso = true;
        }

        return ['erro' => $erro, 'sucesso' => $sucesso];
    }

    // Formulário de dados pessoais.
    $nome = limparEntrada($_POST['nome'] ?? '');
    $email = limparEntrada($_POST['email'] ?? '');
    $telefone = limparEntrada($_POST['telefone'] ?? '');
    $bio = limparEntrada($_POST['bio'] ?? '');

    if ($nome === '' || $email === '') {
        $erro = 'Nome e e-mail são obrigatórios.';
        return ['erro' => $erro, 'sucesso' => $sucesso];
    }

    // Confere se o e-mail já pertence a OUTRO usuário antes de trocar
    // (o próprio usuário pode "atualizar" para o mesmo e-mail que já tem).
    $usuarioComEsseEmail = Usuario::buscarPorEmail($email);
    if ($usuarioComEsseEmail && (int) $usuarioComEsseEmail['id'] !== usuarioId()) {
        $erro = 'Já existe um usuário cadastrado com este e-mail.';
        return ['erro' => $erro, 'sucesso' => $sucesso];
    }

    try {
        if (!empty($_FILES['foto']['name'])) {
            $caminhoFoto = salvarImagemEnviada($_FILES['foto'], 'usuarios/' . usuarioId());
            if ($caminhoFoto) {
                Usuario::atualizarFoto(usuarioId(), $caminhoFoto);
            }
        }

        Usuario::atualizarPerfilProprio(usuarioId(), [
            'nome' => $nome,
            'email' => $email,
            'telefone' => $telefone,
            'bio' => $bio,
        ]);

        // O nome exibido no topo/sidebar vem da sessão — atualiza na
        // hora, sem precisar logar de novo para ver a mudança.
        $_SESSION['nome'] = $nome;

        Auditoria::registrar('perfil_atualizado', 'usuarios', usuarioId());
        $sucesso = true;
    } catch (RuntimeException $e) {
        $erro = $e->getMessage();
    }

    return ['erro' => $erro, 'sucesso' => $sucesso];
}
