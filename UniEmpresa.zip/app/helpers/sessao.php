<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/sessao.php
 * RESPONSABILIDADE: gerenciar o ciclo de vida da sessão PHP.
 *
 * Este arquivo cuida de:
 *   - Iniciar a sessão de forma segura (uma única vez).
 *   - Verificar o timeout de inatividade e encerrar sessões
 *     paradas há muito tempo.
 *   - Oferecer funções auxiliares para ler dados do usuário
 *     logado sem espalhar $_SESSION['...'] pelo sistema todo.
 * =============================================================
 */

/**
 * FUNÇÃO: iniciarSessao()
 * O QUE FAZ: inicia a sessão PHP apenas se ela ainda não tiver
 *            sido iniciada, e verifica se o usuário ficou
 *            inativo por tempo demais.
 * COMO FAZ: usa session_status() para não chamar session_start()
 *           duas vezes (o que gera warning em PHP). Depois
 *           compara o horário da última atividade guardado na
 *           sessão com o horário atual; se passou do limite
 *           definido em SESSAO_TIMEOUT_MINUTOS, destrói a sessão.
 * FIM DA FUNÇÃO
 */
function iniciarSessao(): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }

    // Se existir um login ativo, verificamos o tempo de inatividade.
    if (isset($_SESSION['usuario_id'])) {
        $limiteSegundos = SESSAO_TIMEOUT_MINUTOS * 60;
        $ultimaAcao = $_SESSION['ultima_acao'] ?? time();

        if ((time() - $ultimaAcao) > $limiteSegundos) {
            // Sessão expirada por inatividade: encerra tudo.
            encerrarSessao();
            return;
        }
    }

    // Atualiza o carimbo de "última ação" a cada requisição válida.
    $_SESSION['ultima_acao'] = time();
}

/**
 * FUNÇÃO: usuarioLogado()
 * O QUE FAZ: informa se existe um usuário autenticado na sessão atual.
 * COMO FAZ: apenas verifica a existência da chave 'usuario_id'.
 * FIM DA FUNÇÃO
 */
function usuarioLogado(): bool
{
    return isset($_SESSION['usuario_id']);
}

/**
 * FUNÇÃO: usuarioId()
 * O QUE FAZ: devolve o ID do usuário logado, ou null se não houver login.
 * FIM DA FUNÇÃO
 */
function usuarioId(): ?int
{
    return $_SESSION['usuario_id'] ?? null;
}

/**
 * FUNÇÃO: usuarioTipo()
 * O QUE FAZ: devolve o tipo do usuário logado ('mestre', 'admin' ou
 *            'funcionario'), ou null se não houver login.
 * FIM DA FUNÇÃO
 */
function usuarioTipo(): ?string
{
    return $_SESSION['tipo'] ?? null;
}

/**
 * FUNÇÃO: usuarioEmpresaId()
 * O QUE FAZ: devolve o empresa_id do usuário logado.
 * IMPORTANTE: este valor SEMPRE vem da sessão (nunca do request/
 *             formulário/query string), pois é a base de todo o
 *             isolamento entre empresas no sistema.
 * FIM DA FUNÇÃO
 */
function usuarioEmpresaId(): ?int
{
    return $_SESSION['empresa_id'] ?? null;
}

/**
 * FUNÇÃO: iniciarLogin()
 * O QUE FAZ: grava na sessão os dados mínimos necessários para
 *            identificar o usuário autenticado, e regenera o ID
 *            de sessão por segurança (evita session fixation).
 * PARÂMETROS: array associativo vindo da tabela `usuarios`
 *             (id, tipo, empresa_id, nome).
 * FIM DA FUNÇÃO
 */
function iniciarLogin(array $usuario): void
{
    // Regenera o ID da sessão sempre que o nível de privilégio muda
    // (aqui, no momento do login) para evitar reaproveitamento de
    // uma sessão anônima por um atacante (session fixation).
    session_regenerate_id(true);

    $_SESSION['usuario_id'] = (int) $usuario['id'];
    $_SESSION['tipo'] = $usuario['tipo'];
    $_SESSION['empresa_id'] = $usuario['empresa_id'] !== null ? (int) $usuario['empresa_id'] : null;
    $_SESSION['nome'] = $usuario['nome'];
    $_SESSION['ultima_acao'] = time();

    // Só o funcionário é obrigado a completar o perfil no primeiro
    // acesso (seção 13). Mestre e Admin já entram com perfil_completo = 1.
    $_SESSION['perfil_completo_pendente'] =
        ($usuario['tipo'] === TIPO_FUNCIONARIO && empty($usuario['perfil_completo'])) ? 1 : 0;
}

/**
 * FUNÇÃO: marcarPerfilComoCompleto()
 * O QUE FAZ: atualiza a sessão assim que o funcionário termina de
 *            preencher os dados obrigatórios, liberando o acesso
 *            normal ao restante do sistema.
 * FIM DA FUNÇÃO
 */
function marcarPerfilComoCompleto(): void
{
    $_SESSION['perfil_completo_pendente'] = 0;
}

/**
 * FUNÇÃO: encerrarSessao()
 * O QUE FAZ: realiza o logout completo do usuário.
 * COMO FAZ: limpa todas as variáveis de sessão, remove o cookie
 *           de sessão do navegador e destrói os dados no servidor.
 * FIM DA FUNÇÃO
 */
function encerrarSessao(): void
{
    $_SESSION = [];

    // Remove o cookie de sessão do navegador, se existir.
    if (ini_get('session.use_cookies')) {
        $parametros = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $parametros['path'],
            $parametros['domain'],
            $parametros['secure'],
            $parametros['httponly']
        );
    }

    session_destroy();
}
