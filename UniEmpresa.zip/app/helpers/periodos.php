<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/periodos.php
 * RESPONSABILIDADE: converter um "atalho" de período (ex.: "hoje",
 *                    "mes", "ultimos_7_dias") em datas de início e
 *                    fim concretas — usado por Financeiro,
 *                    Relatórios e Ranking (seção 33 do documento).
 * =============================================================
 */

/**
 * FUNÇÃO: resolverPeriodo()
 * O QUE FAZ: recebe um código de atalho (ou "personalizado" com
 *            datas explícitas) e devolve ['inicio' => 'AAAA-MM-DD',
 *            'fim' => 'AAAA-MM-DD'].
 * FIM DA FUNÇÃO
 */
function resolverPeriodo(string $atalho, ?string $inicioPersonalizado = null, ?string $fimPersonalizado = null): array
{
    $hoje = date('Y-m-d');

    switch ($atalho) {
        case 'hoje':
            return ['inicio' => $hoje, 'fim' => $hoje];

        case 'ontem':
            $ontem = date('Y-m-d', strtotime('-1 day'));
            return ['inicio' => $ontem, 'fim' => $ontem];

        case 'ultimos_7_dias':
            return ['inicio' => date('Y-m-d', strtotime('-6 days')), 'fim' => $hoje];

        case 'ultimos_30_dias':
            return ['inicio' => date('Y-m-d', strtotime('-29 days')), 'fim' => $hoje];

        case 'semana':
            return ['inicio' => date('Y-m-d', strtotime('monday this week')), 'fim' => $hoje];

        case 'mes':
            return ['inicio' => date('Y-m-01'), 'fim' => $hoje];

        case 'trimestre':
            return ['inicio' => date('Y-m-d', strtotime('-3 months')), 'fim' => $hoje];

        case 'semestre':
            return ['inicio' => date('Y-m-d', strtotime('-6 months')), 'fim' => $hoje];

        case 'ano':
            return ['inicio' => date('Y-01-01'), 'fim' => $hoje];

        case 'dois_anos':
            return ['inicio' => date('Y-m-d', strtotime('-2 years')), 'fim' => $hoje];

        case 'personalizado':
            return [
                'inicio' => $inicioPersonalizado ?: $hoje,
                'fim' => $fimPersonalizado ?: $hoje,
            ];

        default:
            return ['inicio' => $hoje, 'fim' => $hoje];
    }
}
