<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/backup.php
 * RESPONSABILIDADE: gerar dumps SQL de tabelas (com ou sem filtro
 *                    de empresa) e empacotá-los em um arquivo ZIP,
 *                    para os backups de empresa (seção 53) e o
 *                    backup global do Mestre (seção 54).
 *
 * IMPORTANTE: nenhuma senha em texto puro existe no banco (os
 * usuários só têm `senha_hash`), então incluir a tabela `usuarios`
 * inteira no dump é seguro — o hash sozinho não permite login.
 * =============================================================
 */

/**
 * FUNÇÃO: dumpTabelaComoSql()
 * O QUE FAZ: gera comandos SQL "INSERT INTO" com os dados atuais de
 *            uma tabela, opcionalmente filtrando por empresa_id.
 * COMO FAZ: lê todas as linhas da tabela e monta um INSERT por
 *           linha, escapando cada valor com PDO::quote() (nunca
 *           concatenando valores brutos), para o arquivo gerado
 *           poder ser reimportado com segurança se necessário.
 * FIM DA FUNÇÃO
 */
function dumpTabelaComoSql(PDO $pdo, string $tabela, ?int $empresaId = null): string
{
    $sqlSelect = "SELECT * FROM `$tabela`";
    $parametros = [];

    if ($empresaId !== null) {
        $sqlSelect .= ' WHERE empresa_id = :empresa_id';
        $parametros[':empresa_id'] = $empresaId;
    }

    $stmt = $pdo->prepare($sqlSelect);
    $stmt->execute($parametros);

    $linhasSql = "-- Dados da tabela `$tabela`\n";
    while ($linha = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $colunas = array_keys($linha);
        $valores = array_map(static function ($valor) use ($pdo) {
            return $valor === null ? 'NULL' : $pdo->quote((string) $valor);
        }, array_values($linha));

        $linhasSql .= sprintf(
            "INSERT INTO `%s` (`%s`) VALUES (%s);\n",
            $tabela,
            implode('`, `', $colunas),
            implode(', ', $valores)
        );
    }

    return $linhasSql . "\n";
}

/**
 * FUNÇÃO: zipDiretorioCompleto()
 * O QUE FAZ: compacta TODOS os arquivos e pastas do projeto (todo o
 *            conteúdo que está hoje no htdocs do InfinityFree) em um
 *            único .zip — usado apenas pelo backup global do Mestre
 *            (seção 54), que precisa poder reconstruir o site inteiro
 *            em caso de migração de hospedagem ou perda de dados.
 * COMO FAZ: percorre a árvore de diretórios recursivamente a partir de
 *           $pastaRaiz, pulando as pastas informadas em $pastasExcluidas
 *           (sempre inclui a própria pasta de backups, para não gerar
 *           um zip gigante contendo backups anteriores dentro dele).
 * IMPORTANTE: exige a extensão ZipArchive — diferente do dump de
 *             tabelas (que tem um modo alternativo sem zip), não há
 *             como "compactar menos" um diretório inteiro sem essa
 *             extensão, então esta função devolve null se ela não
 *             estiver disponível no plano de hospedagem.
 * FIM DA FUNÇÃO
 */
function zipDiretorioCompleto(string $pastaRaiz, string $caminhoZipDestino, array $pastasExcluidas = []): ?string
{
    if (!class_exists('ZipArchive')) {
        return null;
    }

    $pastaRaiz = rtrim($pastaRaiz, '/');
    $zip = new ZipArchive();
    $zip->open($caminhoZipDestino, ZipArchive::CREATE | ZipArchive::OVERWRITE);

    $iterador = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($pastaRaiz, RecursiveDirectoryIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );

    foreach ($iterador as $item) {
        $caminhoRelativo = substr($item->getPathname(), strlen($pastaRaiz) + 1);

        // Pula qualquer caminho que comece com uma das pastas excluídas
        // (ex.: "storage/backups", para não incluir backups anteriores
        // dentro do novo backup, o que faria o arquivo crescer sem parar).
        foreach ($pastasExcluidas as $excluida) {
            if (str_starts_with($caminhoRelativo, $excluida)) {
                continue 2;
            }
        }

        if ($item->isDir()) {
            $zip->addEmptyDir($caminhoRelativo);
        } else {
            $zip->addFile($item->getPathname(), $caminhoRelativo);
        }
    }

    $zip->close();
    return $caminhoZipDestino;
}

/**
 * FUNÇÃO: criarZipComArquivos()
 * O QUE FAZ: recebe um array ['nome_dentro_do_zip.sql' => 'conteúdo']
 *            e gera um arquivo .zip no caminho informado.
 * COMO FAZ: usa a extensão ZipArchive do PHP quando disponível. Se o
 *           plano de hospedagem não tiver essa extensão habilitada,
 *           cai no modo alternativo (salva o SQL puro sem compactar)
 *           — sempre com um retorno claro de qual formato foi gerado,
 *           já que a seção 53 pede ZIP apenas "quando tecnicamente
 *           possível".
 * DEVOLVE: o caminho final do arquivo gerado (.zip ou .sql).
 * FIM DA FUNÇÃO
 */
function criarZipComArquivos(string $caminhoDestinoSemExtensao, array $arquivos): string
{
    if (class_exists('ZipArchive')) {
        $caminhoZip = $caminhoDestinoSemExtensao . '.zip';
        $zip = new ZipArchive();
        $zip->open($caminhoZip, ZipArchive::CREATE | ZipArchive::OVERWRITE);

        foreach ($arquivos as $nomeArquivo => $conteudo) {
            $zip->addFromString($nomeArquivo, $conteudo);
        }

        $zip->close();
        return $caminhoZip;
    }

    // Modo alternativo sem ZipArchive: concatena tudo em um único .sql.
    $caminhoSql = $caminhoDestinoSemExtensao . '.sql';
    $conteudoUnico = '';
    foreach ($arquivos as $nomeArquivo => $conteudo) {
        $conteudoUnico .= "-- ===== $nomeArquivo =====\n" . $conteudo . "\n";
    }
    file_put_contents($caminhoSql, $conteudoUnico);

    return $caminhoSql;
}
