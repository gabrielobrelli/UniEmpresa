<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/upload.php
 * RESPONSABILIDADE: validar e salvar arquivos de imagem enviados
 *                    pelo usuário (logos de empresa, fotos de
 *                    perfil, fotos de produto) de forma segura.
 *
 * REGRAS DE SEGURANÇA APLICADAS:
 *   - Só aceita extensões de imagem específicas (whitelist).
 *   - Confere o tipo MIME real do arquivo (não confia na extensão
 *     nem no cabeçalho Content-Type enviado pelo navegador).
 *   - Gera um nome de arquivo aleatório (nunca usa o nome original),
 *     eliminando qualquer risco de path traversal ou colisão.
 *   - Limita o tamanho máximo do arquivo.
 *   - Salva sempre dentro de public/uploads/, uma pasta sem
 *     permissão de execução de scripts.
 * =============================================================
 */

/**
 * FUNÇÃO: salvarImagemEnviada()
 * O QUE FAZ: processa um arquivo vindo de $_FILES e, se for válido,
 *            move para a pasta de destino com um nome seguro.
 * PARÂMETROS:
 *   - $arquivo: um item de $_FILES (ex.: $_FILES['logo']).
 *   - $subpasta: subpasta dentro de public/uploads/ (ex.: "empresas/12").
 * DEVOLVE: o caminho relativo do arquivo salvo (para gravar no
 *          banco), ou null se nenhum arquivo tiver sido enviado.
 * LANÇA: RuntimeException com mensagem amigável se o arquivo for
 *        inválido (tipo, tamanho, erro de upload).
 * FIM DA FUNÇÃO
 */
function salvarImagemEnviada(array $arquivo, string $subpasta): ?string
{
    // Nenhum arquivo selecionado pelo usuário: não é um erro, apenas
    // significa "manter sem alteração".
    if (!isset($arquivo['error']) || $arquivo['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($arquivo['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no envio do arquivo. Tente novamente.');
    }

    // Limite de 3 MB por imagem.
    $tamanhoMaximo = 3 * 1024 * 1024;
    if ($arquivo['size'] > $tamanhoMaximo) {
        throw new RuntimeException('A imagem enviada é muito grande (máximo 3 MB).');
    }

    // Descobre o tipo MIME real do arquivo lendo seus primeiros bytes
    // (finfo), em vez de confiar na extensão do nome ou no
    // Content-Type informado pelo navegador — ambos podem ser
    // falsificados facilmente por um atacante.
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeReal = $finfo->file($arquivo['tmp_name']);

    $tiposPermitidos = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp',
    ];

    if (!isset($tiposPermitidos[$mimeReal])) {
        throw new RuntimeException('Formato de imagem não suportado. Envie um arquivo JPG, PNG ou WEBP.');
    }

    $extensao = $tiposPermitidos[$mimeReal];

    // Nome de arquivo totalmente aleatório: elimina qualquer
    // possibilidade de o nome original conter caracteres perigosos
    // ou tentar sobrescrever outro arquivo já existente.
    $nomeArquivo = bin2hex(random_bytes(16)) . '.' . $extensao;

    $pastaDestino = __DIR__ . '/../../public/uploads/' . trim($subpasta, '/');
    if (!is_dir($pastaDestino)) {
        mkdir($pastaDestino, 0755, true);
    }

    $caminhoCompleto = $pastaDestino . '/' . $nomeArquivo;

    if (!move_uploaded_file($arquivo['tmp_name'], $caminhoCompleto)) {
        throw new RuntimeException('Não foi possível salvar a imagem enviada.');
    }

    // Caminho relativo, pronto para ser salvo no banco e usado em <img src="...">.
    return '/public/uploads/' . trim($subpasta, '/') . '/' . $nomeArquivo;
}
