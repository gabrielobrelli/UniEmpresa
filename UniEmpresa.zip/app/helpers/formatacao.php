<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/formatacao.php
 * RESPONSABILIDADE: formatar valores para exibição no padrão
 *                    brasileiro (datas DD/MM/AAAA, moeda R$).
 * =============================================================
 */

/**
 * FUNÇÃO: formatarMoeda()
 * O QUE FAZ: converte um número (ex.: 1250.5) para o formato de
 *            moeda brasileira (ex.: "R$ 1.250,50").
 * COMO FAZ: usa number_format() trocando separador de milhar e
 *           decimal para o padrão BR, e prefixa com "R$ ".
 * FIM DA FUNÇÃO
 */
function formatarMoeda(float $valor): string
{
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

/**
 * FUNÇÃO: formatarData()
 * O QUE FAZ: converte uma data do formato do banco (AAAA-MM-DD ou
 *            AAAA-MM-DD HH:mm:ss) para o formato visual brasileiro
 *            DD/MM/AAAA.
 * PARÂMETROS: $comHora — se true, inclui também HH:mm no final.
 * FIM DA FUNÇÃO
 */
function formatarData(?string $dataBanco, bool $comHora = false): string
{
    if (empty($dataBanco)) {
        return '';
    }

    $timestamp = strtotime($dataBanco);
    if ($timestamp === false) {
        return '';
    }

    return $comHora ? date('d/m/Y H:i', $timestamp) : date('d/m/Y', $timestamp);
}

/**
 * FUNÇÃO: minutosParaHoras()
 * O QUE FAZ: converte uma quantidade de minutos (ex.: 440) em uma
 *            string legível de horas e minutos (ex.: "7h20").
 * FIM DA FUNÇÃO
 */
function minutosParaHoras(int $minutos): string
{
    $horas = intdiv($minutos, 60);
    $minutosRestantes = $minutos % 60;

    return sprintf('%dh%02d', $horas, $minutosRestantes);
}
