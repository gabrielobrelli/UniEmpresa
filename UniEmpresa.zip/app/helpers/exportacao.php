<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/exportacao.php
 * RESPONSABILIDADE: gerar exportações em CSV de forma leve, sem
 *                    bibliotecas externas — adequado para
 *                    hospedagem compartilhada (seção 37).
 * =============================================================
 */

/**
 * FUNÇÃO: exportarCsvEEncerrar()
 * O QUE FAZ: envia ao navegador um arquivo CSV pronto para abrir
 *            no Excel/planilhas, a partir de um array de linhas, e
 *            encerra a execução do script.
 * PARÂMETROS:
 *   - $nomeArquivo: nome sugerido para download (ex.: "vendas.csv")
 *   - $cabecalho: array com os nomes das colunas
 *   - $linhas: array de arrays associativos ou indexados com os dados
 * COMO FAZ: usa fputcsv() com ponto e vírgula como separador (mais
 *           compatível com o Excel em português do que a vírgula) e
 *           um BOM UTF-8 no início do arquivo, para acentos abrirem
 *           corretamente no Excel do Windows.
 * FIM DA FUNÇÃO
 */
function exportarCsvEEncerrar(string $nomeArquivo, array $cabecalho, array $linhas): void
{
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $nomeArquivo . '"');

    $saida = fopen('php://output', 'w');

    // BOM UTF-8: sem isso, o Excel do Windows costuma exibir acentos
    // (ç, ã, é...) incorretamente ao abrir o CSV.
    fwrite($saida, "\xEF\xBB\xBF");

    fputcsv($saida, $cabecalho, ';');

    foreach ($linhas as $linha) {
        fputcsv($saida, $linha, ';');
    }

    fclose($saida);
    exit;
}
