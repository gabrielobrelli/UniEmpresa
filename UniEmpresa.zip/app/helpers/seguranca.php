<?php
/**
 * =============================================================
 * ARQUIVO: app/helpers/seguranca.php
 * RESPONSABILIDADE: funções utilitárias de segurança usadas em
 *                    várias partes do sistema (sanitização de
 *                    saída, limitação de tentativas de login).
 * =============================================================
 */

/**
 * FUNÇÃO: escapar()
 * O QUE FAZ: prepara um texto para ser exibido dentro de HTML sem
 *            risco de XSS (Cross-Site Scripting).
 * COMO FAZ: usa htmlspecialchars() convertendo aspas e caracteres
 *           especiais em entidades HTML seguras. Deve ser chamada
 *           SEMPRE que um dado vindo do banco/usuário for impresso
 *           dentro de uma página HTML.
 * FIM DA FUNÇÃO
 */
function escapar(?string $texto): string
{
    return htmlspecialchars($texto ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * FUNÇÃO: limparEntrada()
 * O QUE FAZ: remove espaços nas pontas e normaliza uma string
 *            recebida de formulário antes de usá-la em validações
 *            ou consultas.
 * IMPORTANTE: isso NÃO substitui os prepared statements do PDO —
 *             é apenas uma normalização de formato, não uma
 *             proteção contra SQL Injection (essa proteção vem do
 *             uso de parâmetros amarrados em todas as queries).
 * FIM DA FUNÇÃO
 */
function limparEntrada(?string $valor): string
{
    return trim($valor ?? '');
}

/**
 * FUNÇÃO: limiteDeTentativasExcedido()
 * O QUE FAZ: implementação genérica de rate limiting por chave
 *            (IP + nome da ação), reaproveitada tanto pelo login
 *            quanto pela recuperação de senha — qualquer ação que
 *            possa ser usada para spam ou força bruta.
 * COMO FAZ: mesma estratégia de arquivo JSON simples por chave,
 *           compatível com hospedagem compartilhada sem Redis.
 * FIM DA FUNÇÃO
 */
function limiteDeTentativasExcedido(string $chave, int $maxTentativas, int $janelaSegundos): bool
{
    $arquivo = __DIR__ . '/../../storage/rate_limit/' . md5($chave) . '.json';

    if (!file_exists($arquivo)) {
        return false;
    }

    $dados = json_decode((string) file_get_contents($arquivo), true);
    if (!is_array($dados)) {
        return false;
    }

    $dentroDaJanela = (time() - $dados['primeira_tentativa']) <= $janelaSegundos;

    return $dentroDaJanela && $dados['tentativas'] >= $maxTentativas;
}

/**
 * FUNÇÃO: registrarTentativa()
 * O QUE FAZ: versão genérica de registrarTentativaLogin(), para
 *            qualquer chave de rate limiting.
 * FIM DA FUNÇÃO
 */
function registrarTentativa(string $chave, int $janelaSegundos): void
{
    $pasta = __DIR__ . '/../../storage/rate_limit';
    if (!is_dir($pasta)) {
        mkdir($pasta, 0755, true);
    }

    $arquivo = $pasta . '/' . md5($chave) . '.json';
    $dados = ['tentativas' => 0, 'primeira_tentativa' => time()];

    if (file_exists($arquivo)) {
        $conteudo = json_decode((string) file_get_contents($arquivo), true);
        if (is_array($conteudo)) {
            $dados = $conteudo;
        }
    }

    if ((time() - $dados['primeira_tentativa']) > $janelaSegundos) {
        $dados = ['tentativas' => 0, 'primeira_tentativa' => time()];
    }

    $dados['tentativas']++;
    file_put_contents($arquivo, json_encode($dados));
}

/**
 * FUNÇÃO: registrarTentativaLogin()
 * O QUE FAZ: guarda, em um arquivo temporário simples, o número de
 *            tentativas de login falhas feitas a partir de um IP,
 *            permitindo aplicar um rate limiting básico sem depender
 *            de serviços externos (compatível com hospedagem
 *            compartilhada, que não costuma oferecer Redis/Memcached).
 * COMO FAZ: mantém um pequeno arquivo JSON por IP dentro de uma
 *           pasta de cache local, com contagem e horário da última
 *           tentativa. Após N tentativas dentro da janela de tempo,
 *           bloqueia novas tentativas por alguns minutos.
 * FIM DA FUNÇÃO
 */
function registrarTentativaLogin(string $ip): void
{
    registrarTentativa('login:' . $ip, 900);
}

/**
 * FUNÇÃO: loginBloqueadoPorTentativas()
 * O QUE FAZ: informa se um determinado IP deve ser bloqueado
 *            temporariamente por excesso de tentativas de login
 *            incorretas (mais de 5 tentativas em 15 minutos).
 * FIM DA FUNÇÃO
 */
function loginBloqueadoPorTentativas(string $ip): bool
{
    return limiteDeTentativasExcedido('login:' . $ip, 5, 900);
}

/**
 * FUNÇÃO: limparTentativasLogin()
 * O QUE FAZ: zera o contador de tentativas de um IP após um login
 *            bem-sucedido.
 * FIM DA FUNÇÃO
 */
function limparTentativasLogin(string $ip): void
{
    $arquivo = __DIR__ . '/../../storage/rate_limit/' . md5('login:' . $ip) . '.json';
    if (file_exists($arquivo)) {
        unlink($arquivo);
    }
}
