<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Venda.php
 * RESPONSABILIDADE: todo o ciclo de vida de uma venda no PDV —
 *                    abrir, adicionar/remover itens, registrar
 *                    pagamento (único ou combinado), finalizar
 *                    (com baixa de estoque em transação), cancelar
 *                    e devolver (seções 22 a 29 do documento).
 *
 * REGRA DE OURO DESTE ARQUIVO: nenhuma linha de venda finalizada
 * é editada ou apagada depois de finalizada — cancelamentos e
 * devoluções sempre geram novos registros/estados, nunca reescrevem
 * o passado.
 * =============================================================
 */

require_once __DIR__ . '/Produto.php';
require_once __DIR__ . '/MovimentacaoEstoque.php';

class Venda
{
    /**
     * FUNÇÃO: buscarVendaAbertaDoFuncionario()
     * O QUE FAZ: verifica se o funcionário já possui uma venda em
     *            status 'aberta' (um atendimento em andamento) e a
     *            devolve, para o PDV continuar de onde parou em vez
     *            de criar uma segunda venda aberta simultânea.
     * FIM DA FUNÇÃO
     */
    public static function buscarVendaAbertaDoFuncionario(int $funcionarioId, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT * FROM vendas
             WHERE funcionario_id = :funcionario_id AND empresa_id = :empresa_id AND status = 'aberta'
             ORDER BY created_at DESC LIMIT 1"
        );
        $stmt->execute([':funcionario_id' => $funcionarioId, ':empresa_id' => $empresaId]);

        $venda = $stmt->fetch();
        return $venda ?: null;
    }

    /**
     * FUNÇÃO: abrirNova()
     * O QUE FAZ: cria uma nova venda em status 'aberta' para o
     *            funcionário começar a adicionar produtos.
     * COMO FAZ: gera um número de venda sequencial e legível por
     *           empresa (ex.: "0001", "0002", ...), baseado na
     *           contagem de vendas já existentes.
     * FIM DA FUNÇÃO
     */
    public static function abrirNova(int $empresaId, int $funcionarioId): int
    {
        $pdo = getPDO();

        $numero = self::gerarProximoNumero($empresaId);

        $stmt = $pdo->prepare(
            "INSERT INTO vendas (empresa_id, numero_venda, funcionario_id, status, subtotal, total, created_at)
             VALUES (:empresa_id, :numero, :funcionario_id, 'aberta', 0, 0, NOW())"
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':numero' => $numero,
            ':funcionario_id' => $funcionarioId,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: gerarProximoNumero()
     * O QUE FAZ: gera um número de venda sequencial, único por
     *            empresa, no formato "000123".
     * FIM DA FUNÇÃO
     */
    private static function gerarProximoNumero(int $empresaId): string
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT COUNT(*) AS total FROM vendas WHERE empresa_id = :empresa_id');
        $stmt->execute([':empresa_id' => $empresaId]);
        $total = (int) $stmt->fetch()['total'];

        return str_pad((string) ($total + 1), 6, '0', STR_PAD_LEFT);
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: busca uma venda garantindo que pertence à empresa.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT * FROM vendas WHERE id = :id AND empresa_id = :empresa_id LIMIT 1');
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);

        $venda = $stmt->fetch();
        return $venda ?: null;
    }

    /**
     * FUNÇÃO: listarItens()
     * O QUE FAZ: lista os itens (produtos) já adicionados a uma venda.
     * FIM DA FUNÇÃO
     */
    public static function listarItens(int $vendaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT vi.*, p.nome AS produto_nome, p.codigo AS produto_codigo
             FROM venda_itens vi
             JOIN produtos p ON p.id = vi.produto_id
             WHERE vi.venda_id = :venda_id
             ORDER BY vi.id ASC'
        );
        $stmt->execute([':venda_id' => $vendaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: adicionarItem()
     * O QUE FAZ: adiciona um produto à venda aberta. Se o mesmo
     *            produto já estiver na venda, soma a quantidade em
     *            vez de criar uma segunda linha (evita duplicidade
     *            visual no carrinho).
     * COMO FAZ: usa o preço de venda atual do produto (preco_venda)
     *           como preço unitário — congelado no momento da
     *           adição, então uma mudança de preço depois não afeta
     *           vendas já em andamento ou finalizadas.
     * IMPORTANTE: não mexe em estoque aqui — a baixa de estoque só
     *             acontece na finalização da venda (seção 24).
     * FIM DA FUNÇÃO
     */
    public static function adicionarItem(int $vendaId, int $produtoId, int $empresaId, float $quantidade): void
    {
        $pdo = getPDO();

        $produto = Produto::buscarPorId($produtoId, $empresaId);
        if (!$produto) {
            throw new RuntimeException('Produto não encontrado.');
        }

        $stmt = $pdo->prepare(
            'SELECT id, quantidade FROM venda_itens WHERE venda_id = :venda_id AND produto_id = :produto_id LIMIT 1'
        );
        $stmt->execute([':venda_id' => $vendaId, ':produto_id' => $produtoId]);
        $itemExistente = $stmt->fetch();

        if ($itemExistente) {
            $novaQuantidade = (float) $itemExistente['quantidade'] + $quantidade;
            $novoSubtotal = $novaQuantidade * (float) $produto['preco_venda'];

            $pdo->prepare('UPDATE venda_itens SET quantidade = :qtd, subtotal = :subtotal WHERE id = :id')
                ->execute([':qtd' => $novaQuantidade, ':subtotal' => $novoSubtotal, ':id' => $itemExistente['id']]);
        } else {
            $subtotal = $quantidade * (float) $produto['preco_venda'];

            $pdo->prepare(
                'INSERT INTO venda_itens (venda_id, produto_id, quantidade, preco_unitario, subtotal)
                 VALUES (:venda_id, :produto_id, :quantidade, :preco_unitario, :subtotal)'
            )->execute([
                ':venda_id' => $vendaId,
                ':produto_id' => $produtoId,
                ':quantidade' => $quantidade,
                ':preco_unitario' => $produto['preco_venda'],
                ':subtotal' => $subtotal,
            ]);
        }

        self::recalcularTotais($vendaId);
    }

    /**
     * FUNÇÃO: removerItem()
     * O QUE FAZ: remove uma linha do carrinho de uma venda aberta.
     * FIM DA FUNÇÃO
     */
    public static function removerItem(int $itemId, int $vendaId): void
    {
        $pdo = getPDO();
        $pdo->prepare('DELETE FROM venda_itens WHERE id = :id AND venda_id = :venda_id')
            ->execute([':id' => $itemId, ':venda_id' => $vendaId]);

        self::recalcularTotais($vendaId);
    }

    /**
     * FUNÇÃO: recalcularTotais()
     * O QUE FAZ: soma os subtotais de todos os itens da venda e
     *            atualiza os campos subtotal/total da venda.
     * COMO FAZ: chamada automaticamente após qualquer alteração no
     *           carrinho, para que a venda nunca fique com um total
     *           desatualizado em relação aos itens reais.
     * FIM DA FUNÇÃO
     */
    private static function recalcularTotais(int $vendaId): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT COALESCE(SUM(subtotal), 0) AS total FROM venda_itens WHERE venda_id = :venda_id');
        $stmt->execute([':venda_id' => $vendaId]);
        $subtotal = (float) $stmt->fetch()['total'];

        $pdo->prepare('UPDATE vendas SET subtotal = :subtotal, total = :subtotal2 WHERE id = :id')
            ->execute([':subtotal' => $subtotal, ':subtotal2' => $subtotal, ':id' => $vendaId]);
    }

    /**
     * FUNÇÃO: vincularCliente()
     * O QUE FAZ: associa (ou remove) um cliente à venda em aberto.
     * FIM DA FUNÇÃO
     */
    public static function vincularCliente(int $vendaId, ?int $clienteId): void
    {
        $pdo = getPDO();
        $pdo->prepare('UPDATE vendas SET cliente_id = :cliente_id WHERE id = :id')
            ->execute([':cliente_id' => $clienteId, ':id' => $vendaId]);
    }

    /**
     * FUNÇÃO: finalizar()
     * O QUE FAZ: fecha a venda definitivamente — a operação mais
     *            crítica de todo o sistema (seção 24 e 59).
     * COMO FAZ, PASSO A PASSO, DENTRO DE UMA ÚNICA TRANSAÇÃO:
     *   1. Trava a linha da venda (FOR UPDATE) e confirma que ela
     *      ainda está 'aberta' (evita finalizar duas vezes por
     *      duplo clique/duplo envio — ver seção 75).
     *   2. Confere se a soma dos pagamentos informados bate
     *      exatamente com o total da venda (seção 26) — usando
     *      comparação com tolerância de 1 centavo por causa de
     *      arredondamento de ponto flutuante.
     *   3. Para cada item do carrinho, chama
     *      MovimentacaoEstoque::registrarSaida() REUTILIZANDO esta
     *      mesma conexão/transação (parâmetro $pdoExterno), fazendo
     *      a baixa de estoque validar disponibilidade em tempo real.
     *   4. Grava os pagamentos informados.
     *   5. Marca a venda como 'finalizada' com data/hora.
     *   6. Registra uma movimentação financeira de entrada
     *      correspondente ao valor da venda.
     *   7. Se qualquer passo falhar (ex.: estoque insuficiente),
     *      TUDO é desfeito — nenhuma baixa parcial, nenhum
     *      pagamento "órfão".
     * PARÂMETROS:
     *   $pagamentos: array de ['forma' => ..., 'valor' => ..., 'parcelas' => ...]
     * FIM DA FUNÇÃO
     */
    public static function finalizar(int $vendaId, int $empresaId, array $pagamentos, int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare('SELECT * FROM vendas WHERE id = :id AND empresa_id = :empresa_id FOR UPDATE');
            $stmt->execute([':id' => $vendaId, ':empresa_id' => $empresaId]);
            $venda = $stmt->fetch();

            if (!$venda) {
                throw new RuntimeException('Venda não encontrada.');
            }
            if ($venda['status'] !== 'aberta') {
                // Duplo clique / reenvio de formulário: a venda já foi
                // finalizada antes — não faz nada e não gera erro
                // assustador para o funcionário, apenas interrompe.
                throw new RuntimeException('Esta venda já foi finalizada anteriormente.');
            }

            $itens = self::listarItens($vendaId);
            if (empty($itens)) {
                throw new RuntimeException('Não é possível finalizar uma venda sem produtos.');
            }

            $somaPagamentos = array_sum(array_column($pagamentos, 'valor'));
            $diferenca = abs($somaPagamentos - (float) $venda['total']);

            if ($diferenca > 0.01) {
                throw new RuntimeException('A soma dos pagamentos precisa ser igual ao total da venda.');
            }

            // Baixa de estoque de cada item, reaproveitando esta mesma
            // transação ($pdo) — se um produto não tiver saldo
            // suficiente, a exceção interrompe tudo e desfaz também os
            // itens que já haviam sido baixados nesta mesma venda.
            foreach ($itens as $item) {
                MovimentacaoEstoque::registrarSaida(
                    (int) $item['produto_id'],
                    $empresaId,
                    (float) $item['quantidade'],
                    'venda',
                    $usuarioId,
                    $vendaId,
                    null,
                    $pdo
                );
            }

            foreach ($pagamentos as $pagamento) {
                $pdo->prepare(
                    'INSERT INTO venda_pagamentos (venda_id, forma, valor, parcelas, created_at)
                     VALUES (:venda_id, :forma, :valor, :parcelas, NOW())'
                )->execute([
                    ':venda_id' => $vendaId,
                    ':forma' => $pagamento['forma'],
                    ':valor' => $pagamento['valor'],
                    ':parcelas' => $pagamento['parcelas'] ?? null,
                ]);
            }

            $pdo->prepare(
                "UPDATE vendas SET status = 'finalizada', finalizada_em = NOW() WHERE id = :id"
            )->execute([':id' => $vendaId]);

            // Reflexo automático no fluxo de caixa: toda venda finalizada
            // gera uma entrada financeira correspondente (seção 30/81).
            $pdo->prepare(
                "INSERT INTO movimentacoes_financeiras
                    (empresa_id, tipo, categoria, descricao, valor, responsavel_id, venda_id, data_movimentacao, created_at)
                 VALUES
                    (:empresa_id, 'entrada', 'Venda', :descricao, :valor, :responsavel_id, :venda_id, CURDATE(), NOW())"
            )->execute([
                ':empresa_id' => $empresaId,
                ':descricao' => 'Venda #' . $venda['numero_venda'],
                ':valor' => $venda['total'],
                ':responsavel_id' => $usuarioId,
                ':venda_id' => $vendaId,
            ]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * FUNÇÃO: cancelar()
     * O QUE FAZ: cancela uma venda. Se ela já estava finalizada,
     *            estorna o estoque de cada item (devolve ao estoque)
     *            dentro da mesma transação.
     * FIM DA FUNÇÃO
     */
    public static function cancelar(int $vendaId, int $empresaId, string $motivo, int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare('SELECT * FROM vendas WHERE id = :id AND empresa_id = :empresa_id FOR UPDATE');
            $stmt->execute([':id' => $vendaId, ':empresa_id' => $empresaId]);
            $venda = $stmt->fetch();

            if (!$venda) {
                throw new RuntimeException('Venda não encontrada.');
            }
            if (in_array($venda['status'], ['cancelada', 'devolvida'], true)) {
                throw new RuntimeException('Esta venda já está cancelada/devolvida.');
            }

            // Só estorna estoque se a venda já havia sido finalizada
            // (uma venda ainda 'aberta' nunca baixou estoque).
            if ($venda['status'] === 'finalizada') {
                $itens = self::listarItens($vendaId);
                foreach ($itens as $item) {
                    MovimentacaoEstoque::registrarEntrada(
                        (int) $item['produto_id'],
                        $empresaId,
                        (float) $item['quantidade'],
                        null,
                        $usuarioId,
                        null,
                        'Estorno por cancelamento da venda #' . $venda['numero_venda']
                    );
                }
            }

            $pdo->prepare(
                "UPDATE vendas SET status = 'cancelada', cancelada_em = NOW(),
                    motivo_cancelamento = :motivo, cancelada_por = :usuario_id
                 WHERE id = :id"
            )->execute([':motivo' => $motivo, ':usuario_id' => $usuarioId, ':id' => $vendaId]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista vendas de uma empresa com filtros opcionais
     *            de status e funcionário — usado nas telas de
     *            acompanhamento do administrador.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId, ?string $status = null, ?int $funcionarioId = null): array
    {
        $pdo = getPDO();
        $sql = 'SELECT v.*, u.nome AS funcionario_nome, c.nome AS cliente_nome
                FROM vendas v
                JOIN usuarios u ON u.id = v.funcionario_id
                LEFT JOIN clientes c ON c.id = v.cliente_id
                WHERE v.empresa_id = :empresa_id';
        $parametros = [':empresa_id' => $empresaId];

        if ($status) {
            $sql .= ' AND v.status = :status';
            $parametros[':status'] = $status;
        }
        if ($funcionarioId) {
            $sql .= ' AND v.funcionario_id = :funcionario_id';
            $parametros[':funcionario_id'] = $funcionarioId;
        }

        $sql .= ' ORDER BY v.created_at DESC LIMIT 200';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }
}
