<?php
/**
 * =============================================================
 * ARQUIVO: app/models/MovimentacaoEstoque.php
 * RESPONSABILIDADE: é o ÚNICO lugar do sistema autorizado a mudar
 *                    o campo `estoque_atual` de um produto. Toda
 *                    entrada ou saída passa por aqui, sempre dentro
 *                    de uma transação MySQL, e sempre gerando uma
 *                    linha de histórico em `movimentacoes_estoque`
 *                    (seções 18 a 21 do documento de requisitos).
 * =============================================================
 */

class MovimentacaoEstoque
{
    /**
     * FUNÇÃO: registrarEntrada()
     * O QUE FAZ: dá entrada de uma quantidade de um produto no
     *            estoque (compra, ajuste positivo, devolução etc.).
     * COMO FAZ:
     *   1. Abre uma transação.
     *   2. Lê a quantidade atual do produto com FOR UPDATE (trava a
     *      linha para evitar que duas requisições simultâneas leiam
     *      o mesmo valor antigo e gerem um cálculo incorreto).
     *   3. Calcula a nova quantidade e atualiza o produto.
     *   4. Insere a linha de histórico com quantidade anterior/
     *      movimentada/posterior.
     *   5. Confirma (COMMIT). Se qualquer passo falhar, tudo é
     *      desfeito (ROLLBACK) e nenhuma alteração fica pela metade.
     * FIM DA FUNÇÃO
     */
    public static function registrarEntrada(
        int $produtoId,
        int $empresaId,
        float $quantidade,
        ?float $valorUnitario,
        int $usuarioId,
        ?int $fornecedorId = null,
        ?string $observacao = null
    ): void {
        $pdo = getPDO();
        $pdo->beginTransaction();

        try {
            $stmt = $pdo->prepare(
                'SELECT estoque_atual FROM produtos
                 WHERE id = :id AND empresa_id = :empresa_id FOR UPDATE'
            );
            $stmt->execute([':id' => $produtoId, ':empresa_id' => $empresaId]);
            $produto = $stmt->fetch();

            if (!$produto) {
                throw new RuntimeException('Produto não encontrado.');
            }

            $quantidadeAnterior = (float) $produto['estoque_atual'];
            $quantidadePosterior = $quantidadeAnterior + $quantidade;
            $valorTotal = $valorUnitario !== null ? $valorUnitario * $quantidade : null;

            $pdo->prepare('UPDATE produtos SET estoque_atual = :novo, updated_at = NOW() WHERE id = :id')
                ->execute([':novo' => $quantidadePosterior, ':id' => $produtoId]);

            $pdo->prepare(
                "INSERT INTO movimentacoes_estoque
                    (empresa_id, produto_id, usuario_id, tipo, motivo,
                     quantidade_anterior, quantidade_movimentada, quantidade_posterior,
                     valor_unitario, valor_total, fornecedor_id, observacao, created_at)
                 VALUES
                    (:empresa_id, :produto_id, :usuario_id, 'entrada', 'compra',
                     :quantidade_anterior, :quantidade_movimentada, :quantidade_posterior,
                     :valor_unitario, :valor_total, :fornecedor_id, :observacao, NOW())"
            )->execute([
                ':empresa_id' => $empresaId,
                ':produto_id' => $produtoId,
                ':usuario_id' => $usuarioId,
                ':quantidade_anterior' => $quantidadeAnterior,
                ':quantidade_movimentada' => $quantidade,
                ':quantidade_posterior' => $quantidadePosterior,
                ':valor_unitario' => $valorUnitario,
                ':valor_total' => $valorTotal,
                ':fornecedor_id' => $fornecedorId,
                ':observacao' => $observacao,
            ]);

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * FUNÇÃO: registrarSaida()
     * O QUE FAZ: retira uma quantidade de um produto do estoque
     *            (ajuste, perda, avaria, uso interno, devolução ou
     *            venda — a saída por venda é chamada internamente
     *            pelo model Venda, dentro da mesma transação da
     *            finalização de venda).
     * COMO FAZ: mesma lógica de trava (FOR UPDATE) e transação da
     *           entrada. Além disso, verifica se o produto permite
     *           estoque negativo antes de concluir a saída — se não
     *           permitir e a operação deixaria o estoque abaixo de
     *           zero, a operação é cancelada com uma exceção.
     * FIM DA FUNÇÃO
     */
    public static function registrarSaida(
        int $produtoId,
        int $empresaId,
        float $quantidade,
        string $motivo,
        int $usuarioId,
        ?int $vendaId = null,
        ?string $observacao = null,
        ?PDO $pdoExterno = null
    ): void {
        // Permite reaproveitar uma transação já aberta pelo chamador
        // (por exemplo, a finalização de venda, que já está dentro de
        // sua própria transação e precisa que a baixa de estoque
        // participe dela em vez de abrir uma transação separada).
        $pdo = $pdoExterno ?? getPDO();
        $transacaoPropria = $pdoExterno === null;

        if ($transacaoPropria) {
            $pdo->beginTransaction();
        }

        try {
            $stmt = $pdo->prepare(
                'SELECT estoque_atual, permite_estoque_negativo FROM produtos
                 WHERE id = :id AND empresa_id = :empresa_id FOR UPDATE'
            );
            $stmt->execute([':id' => $produtoId, ':empresa_id' => $empresaId]);
            $produto = $stmt->fetch();

            if (!$produto) {
                throw new RuntimeException('Produto não encontrado.');
            }

            $quantidadeAnterior = (float) $produto['estoque_atual'];
            $quantidadePosterior = $quantidadeAnterior - $quantidade;

            if ($quantidadePosterior < 0 && !$produto['permite_estoque_negativo']) {
                throw new RuntimeException('Estoque insuficiente para concluir esta operação.');
            }

            $pdo->prepare('UPDATE produtos SET estoque_atual = :novo, updated_at = NOW() WHERE id = :id')
                ->execute([':novo' => $quantidadePosterior, ':id' => $produtoId]);

            $pdo->prepare(
                "INSERT INTO movimentacoes_estoque
                    (empresa_id, produto_id, usuario_id, venda_id, tipo, motivo,
                     quantidade_anterior, quantidade_movimentada, quantidade_posterior,
                     observacao, created_at)
                 VALUES
                    (:empresa_id, :produto_id, :usuario_id, :venda_id, 'saida', :motivo,
                     :quantidade_anterior, :quantidade_movimentada, :quantidade_posterior,
                     :observacao, NOW())"
            )->execute([
                ':empresa_id' => $empresaId,
                ':produto_id' => $produtoId,
                ':usuario_id' => $usuarioId,
                ':venda_id' => $vendaId,
                ':motivo' => $motivo,
                ':quantidade_anterior' => $quantidadeAnterior,
                ':quantidade_movimentada' => $quantidade,
                ':quantidade_posterior' => $quantidadePosterior,
                ':observacao' => $observacao,
            ]);

            if ($transacaoPropria) {
                $pdo->commit();
            }
        } catch (Throwable $e) {
            if ($transacaoPropria) {
                $pdo->rollBack();
            }
            throw $e;
        }
    }

    /**
     * FUNÇÃO: historico()
     * O QUE FAZ: lista o histórico de movimentações de estoque de
     *            uma empresa, com filtros opcionais de produto e
     *            período — usado na tela de histórico (seção 21).
     * FIM DA FUNÇÃO
     */
    public static function historico(int $empresaId, ?int $produtoId = null, ?string $dataInicio = null, ?string $dataFim = null): array
    {
        $pdo = getPDO();

        $sql = "SELECT m.*, p.nome AS produto_nome, u.nome AS usuario_nome
                FROM movimentacoes_estoque m
                JOIN produtos p ON p.id = m.produto_id
                JOIN usuarios u ON u.id = m.usuario_id
                WHERE m.empresa_id = :empresa_id";
        $parametros = [':empresa_id' => $empresaId];

        if ($produtoId) {
            $sql .= ' AND m.produto_id = :produto_id';
            $parametros[':produto_id'] = $produtoId;
        }

        if ($dataInicio) {
            $sql .= ' AND m.created_at >= :data_inicio';
            $parametros[':data_inicio'] = $dataInicio . ' 00:00:00';
        }

        if ($dataFim) {
            $sql .= ' AND m.created_at <= :data_fim';
            $parametros[':data_fim'] = $dataFim . ' 23:59:59';
        }

        $sql .= ' ORDER BY m.created_at DESC LIMIT 200';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }
}
