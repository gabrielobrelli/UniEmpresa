<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Feedback.php
 * RESPONSABILIDADE: registrar e listar feedbacks que o
 *                    administrador dá a um funcionário (positivo,
 *                    ponto de atenção, observação — seção 49).
 * =============================================================
 */

class Feedback
{
    /**
     * FUNÇÃO: registrar()
     * O QUE FAZ: insere um novo feedback para um funcionário.
     * FIM DA FUNÇÃO
     */
    public static function registrar(int $empresaId, int $funcionarioId, int $adminId, string $tipo, string $descricao): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO feedbacks (empresa_id, funcionario_id, admin_id, tipo, descricao, created_at)
             VALUES (:empresa_id, :funcionario_id, :admin_id, :tipo, :descricao, NOW())'
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':funcionario_id' => $funcionarioId,
            ':admin_id' => $adminId,
            ':tipo' => $tipo,
            ':descricao' => $descricao,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: listarPorFuncionario()
     * O QUE FAZ: lista os feedbacks recebidos por um funcionário,
     *            do mais recente para o mais antigo.
     * FIM DA FUNÇÃO
     */
    public static function listarPorFuncionario(int $funcionarioId, int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT f.*, u.nome AS admin_nome
             FROM feedbacks f
             JOIN usuarios u ON u.id = f.admin_id
             WHERE f.funcionario_id = :funcionario_id AND f.empresa_id = :empresa_id
             ORDER BY f.created_at DESC'
        );
        $stmt->execute([':funcionario_id' => $funcionarioId, ':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }
}
