<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Conversa.php
 * RESPONSABILIDADE: gerenciar conversas 1-para-1 e aplicar as
 *                    regras de "quem pode falar com quem" do
 *                    chat interno (seção 40 do documento):
 *   - Mestre fala com qualquer administrador ou funcionário.
 *   - Administrador fala com outros admins e funcionários da
 *     MESMA empresa.
 *   - Funcionário fala apenas com administradores da própria
 *     empresa (nunca com funcionários de outra empresa, nem
 *     com funcionários da mesma empresa neste MVP de chat).
 * =============================================================
 */

class Conversa
{
    /**
     * FUNÇÃO: contatosPermitidos()
     * O QUE FAZ: devolve a lista de usuários com quem o usuário
     *            logado tem permissão de iniciar/manter uma conversa,
     *            já aplicando a regra de isolamento por empresa.
     * COMO FAZ: decide a consulta com base no tipo do usuário logado
     *           — esta é a ÚNICA função que decide quem pode falar
     *           com quem; a tela de chat e a API nunca decidem isso
     *           sozinhas, apenas usam o resultado daqui.
     * FIM DA FUNÇÃO
     */
    public static function contatosPermitidos(int $usuarioId, string $tipoUsuario, ?int $empresaId): array
    {
        $pdo = getPDO();

        if ($tipoUsuario === TIPO_MESTRE) {
            // Mestre pode falar com qualquer admin ou funcionário de
            // qualquer empresa.
            $stmt = $pdo->prepare(
                "SELECT id, nome, tipo, empresa_id, ultima_atividade FROM usuarios
                 WHERE tipo IN ('admin', 'funcionario') AND deleted_at IS NULL
                 ORDER BY nome ASC"
            );
            $stmt->execute();
            return $stmt->fetchAll();
        }

        if ($tipoUsuario === TIPO_ADMIN) {
            // Admin fala com outros admins e funcionários da mesma empresa,
            // e também com o Mestre.
            $stmt = $pdo->prepare(
                "SELECT id, nome, tipo, empresa_id, ultima_atividade FROM usuarios
                 WHERE deleted_at IS NULL AND id != :usuario_id
                   AND (tipo = 'mestre' OR (empresa_id = :empresa_id AND tipo IN ('admin', 'funcionario')))
                 ORDER BY nome ASC"
            );
            $stmt->execute([':usuario_id' => $usuarioId, ':empresa_id' => $empresaId]);
            return $stmt->fetchAll();
        }

        // Funcionário: apenas administradores da própria empresa.
        $stmt = $pdo->prepare(
            "SELECT id, nome, tipo, empresa_id, ultima_atividade FROM usuarios
             WHERE empresa_id = :empresa_id AND tipo = 'admin' AND deleted_at IS NULL
             ORDER BY nome ASC"
        );
        $stmt->execute([':empresa_id' => $empresaId]);
        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: podeConversarCom()
     * O QUE FAZ: confirma, no backend, se o usuário logado tem
     *            permissão de conversar com um determinado
     *            destinatário — chamada sempre antes de abrir uma
     *            conversa ou enviar mensagem, para não depender
     *            apenas da lista mostrada na tela (seção 98: a
     *            segurança nunca depende só da interface).
     * FIM DA FUNÇÃO
     */
    public static function podeConversarCom(int $usuarioId, string $tipoUsuario, ?int $empresaId, int $destinatarioId): bool
    {
        $contatos = self::contatosPermitidos($usuarioId, $tipoUsuario, $empresaId);
        foreach ($contatos as $contato) {
            if ((int) $contato['id'] === $destinatarioId) {
                return true;
            }
        }
        return false;
    }

    /**
     * FUNÇÃO: obterOuCriar()
     * O QUE FAZ: devolve o ID de uma conversa entre dois usuários,
     *            criando-a se ainda não existir.
     * COMO FAZ: normaliza a ordem dos dois IDs (menor primeiro) antes
     *           de gravar, para que a restrição UNIQUE(usuario1_id,
     *           usuario2_id) do banco funcione independentemente de
     *           quem iniciou a conversa.
     * FIM DA FUNÇÃO
     */
    public static function obterOuCriar(int $usuarioA, int $usuarioB): int
    {
        $menor = min($usuarioA, $usuarioB);
        $maior = max($usuarioA, $usuarioB);

        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT id FROM conversas WHERE usuario1_id = :u1 AND usuario2_id = :u2 LIMIT 1'
        );
        $stmt->execute([':u1' => $menor, ':u2' => $maior]);
        $conversa = $stmt->fetch();

        if ($conversa) {
            return (int) $conversa['id'];
        }

        $pdo->prepare(
            'INSERT INTO conversas (usuario1_id, usuario2_id, created_at) VALUES (:u1, :u2, NOW())'
        )->execute([':u1' => $menor, ':u2' => $maior]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: listarConversasDoUsuario()
     * O QUE FAZ: lista as conversas do usuário logado, já com o
     *            nome do outro participante e a última mensagem,
     *            ordenadas pela mais recente primeiro.
     * FIM DA FUNÇÃO
     */
    public static function listarConversasDoUsuario(int $usuarioId): array
    {
        $pdo = getPDO();
        // IMPORTANTE: cada aparição de "meu ID" na consulta usa um nome
        // de placeholder diferente (:usuario_id, :usuario_id2, ...) —
        // todas amarradas ao MESMO valor. Repetir o mesmo nome de
        // placeholder várias vezes na mesma query quebra com
        // "SQLSTATE[HY093]: Invalid parameter number" no PDO (prepared
        // statements nativos não suportam isso). Esse era o motivo do
        // chat não abrir para nenhum tipo de usuário.
        $stmt = $pdo->prepare(
            "SELECT c.id, c.ultima_mensagem_em,
                    IF(c.usuario1_id = :usuario_id, c.usuario2_id, c.usuario1_id) AS outro_usuario_id,
                    u.nome AS outro_usuario_nome,
                    u.ultima_atividade AS outro_usuario_ultima_atividade,
                    (SELECT COUNT(*) FROM mensagens m
                        WHERE m.conversa_id = c.id AND m.remetente_id != :usuario_id2 AND m.lida_em IS NULL) AS nao_lidas
             FROM conversas c
             JOIN usuarios u ON u.id = IF(c.usuario1_id = :usuario_id3, c.usuario2_id, c.usuario1_id)
             WHERE c.usuario1_id = :usuario_id4 OR c.usuario2_id = :usuario_id5
             ORDER BY c.ultima_mensagem_em DESC"
        );
        $stmt->execute([
            ':usuario_id' => $usuarioId,
            ':usuario_id2' => $usuarioId,
            ':usuario_id3' => $usuarioId,
            ':usuario_id4' => $usuarioId,
            ':usuario_id5' => $usuarioId,
        ]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: participaDaConversa()
     * O QUE FAZ: confirma que o usuário logado é um dos dois
     *            participantes de uma conversa — checagem obrigatória
     *            antes de listar mensagens ou enviar (evita que
     *            alguém leia uma conversa alheia trocando o ID na URL).
     * FIM DA FUNÇÃO
     */
    public static function participaDaConversa(int $conversaId, int $usuarioId): bool
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT id FROM conversas WHERE id = :id AND (usuario1_id = :usuario_id OR usuario2_id = :usuario_id2) LIMIT 1'
        );
        $stmt->execute([':id' => $conversaId, ':usuario_id' => $usuarioId, ':usuario_id2' => $usuarioId]);

        return (bool) $stmt->fetch();
    }
}
