<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Relatorio.php
 * RESPONSABILIDADE: consultas agregadas usadas pela tela de
 *                    relatórios (seções 32 a 36 do documento) —
 *                    vendas por dia, produtos mais vendidos,
 *                    desempenho por funcionário, formas de
 *                    pagamento e ranking.
 * Todas as consultas recebem $empresaId e um intervalo de datas
 * já resolvido por resolverPeriodo().
 * =============================================================
 */

class Relatorio
{
    /**
     * FUNÇÃO: vendasPorDia()
     * O QUE FAZ: agrupa o total vendido (finalizado) por dia dentro
     *            do período — dados prontos para alimentar um
     *            gráfico de vendas por período (seção 36).
     * FIM DA FUNÇÃO
     */
    public static function vendasPorDia(int $empresaId, string $inicio, string $fim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT DATE(finalizada_em) AS dia, COUNT(*) AS quantidade, COALESCE(SUM(total), 0) AS total
             FROM vendas
             WHERE empresa_id = :empresa_id AND status = 'finalizada'
               AND DATE(finalizada_em) BETWEEN :inicio AND :fim
             GROUP BY DATE(finalizada_em)
             ORDER BY dia ASC"
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $inicio, ':fim' => $fim]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: produtosMaisVendidos()
     * O QUE FAZ: soma a quantidade e o valor vendido de cada produto
     *            dentro do período, do mais vendido para o menos.
     * FIM DA FUNÇÃO
     */
    public static function produtosMaisVendidos(int $empresaId, string $inicio, string $fim, int $limite = 20): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT p.nome, SUM(vi.quantidade) AS quantidade_vendida, SUM(vi.subtotal) AS valor_total
             FROM venda_itens vi
             JOIN vendas v ON v.id = vi.venda_id
             JOIN produtos p ON p.id = vi.produto_id
             WHERE v.empresa_id = :empresa_id AND v.status = 'finalizada'
               AND DATE(v.finalizada_em) BETWEEN :inicio AND :fim
             GROUP BY vi.produto_id
             ORDER BY valor_total DESC
             LIMIT :limite"
        );
        $stmt->bindValue(':empresa_id', $empresaId, PDO::PARAM_INT);
        $stmt->bindValue(':inicio', $inicio);
        $stmt->bindValue(':fim', $fim);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: vendasPorCategoria()
     * O QUE FAZ: soma o valor vendido agrupado por categoria de
     *            produto, dentro do período.
     * FIM DA FUNÇÃO
     */
    public static function vendasPorCategoria(int $empresaId, string $inicio, string $fim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT COALESCE(c.nome, 'Sem categoria') AS categoria, SUM(vi.subtotal) AS valor_total
             FROM venda_itens vi
             JOIN vendas v ON v.id = vi.venda_id
             JOIN produtos p ON p.id = vi.produto_id
             LEFT JOIN categorias c ON c.id = p.categoria_id
             WHERE v.empresa_id = :empresa_id AND v.status = 'finalizada'
               AND DATE(v.finalizada_em) BETWEEN :inicio AND :fim
             GROUP BY categoria
             ORDER BY valor_total DESC"
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $inicio, ':fim' => $fim]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: formasPagamentoUtilizadas()
     * O QUE FAZ: soma os valores recebidos por forma de pagamento
     *            dentro do período (seção 34).
     * FIM DA FUNÇÃO
     */
    public static function formasPagamentoUtilizadas(int $empresaId, string $inicio, string $fim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT vp.forma, COUNT(*) AS quantidade, SUM(vp.valor) AS valor_total
             FROM venda_pagamentos vp
             JOIN vendas v ON v.id = vp.venda_id
             WHERE v.empresa_id = :empresa_id AND v.status = 'finalizada'
               AND DATE(v.finalizada_em) BETWEEN :inicio AND :fim
             GROUP BY vp.forma
             ORDER BY valor_total DESC"
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $inicio, ':fim' => $fim]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: rankingFuncionarios()
     * O QUE FAZ: ranking de funcionários por valor total vendido no
     *            período, com quantidade de vendas e ticket médio
     *            (seções 34 e 35).
     * FIM DA FUNÇÃO
     */
    public static function rankingFuncionarios(int $empresaId, string $inicio, string $fim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT u.id, u.nome,
                    COUNT(v.id) AS total_vendas,
                    COALESCE(SUM(v.total), 0) AS valor_total,
                    COALESCE(SUM(vi.quantidade), 0) AS quantidade_produtos
             FROM usuarios u
             LEFT JOIN vendas v ON v.funcionario_id = u.id AND v.status = 'finalizada'
                    AND DATE(v.finalizada_em) BETWEEN :inicio AND :fim
             LEFT JOIN venda_itens vi ON vi.venda_id = v.id
             WHERE u.empresa_id = :empresa_id AND u.tipo = 'funcionario' AND u.deleted_at IS NULL
             GROUP BY u.id
             ORDER BY valor_total DESC"
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $inicio, ':fim' => $fim]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: desempenhoFuncionario()
     * O QUE FAZ: detalha o desempenho de UM funcionário específico
     *            no período (seção 34: total vendido, número de
     *            vendas, ticket médio, formas de pagamento usadas).
     * FIM DA FUNÇÃO
     */
    public static function desempenhoFuncionario(int $empresaId, int $funcionarioId, string $inicio, string $fim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT COUNT(*) AS total_vendas, COALESCE(SUM(total), 0) AS valor_total,
                    COALESCE(AVG(total), 0) AS ticket_medio
             FROM vendas
             WHERE empresa_id = :empresa_id AND funcionario_id = :funcionario_id
               AND status = 'finalizada' AND DATE(finalizada_em) BETWEEN :inicio AND :fim"
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':funcionario_id' => $funcionarioId,
            ':inicio' => $inicio,
            ':fim' => $fim,
        ]);

        return $stmt->fetch();
    }
}
