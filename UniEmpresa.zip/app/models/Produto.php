<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Produto.php
 * RESPONSABILIDADE: CRUD de produtos e consultas relacionadas
 *                    (busca por código/nome, produtos com estoque
 *                    baixo/esgotado). O ajuste do campo
 *                    `estoque_atual` em si é feito exclusivamente
 *                    pelo model MovimentacaoEstoque, para garantir
 *                    que toda mudança de estoque gere histórico.
 * =============================================================
 */

class Produto
{
    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista produtos de uma empresa, com busca textual e
     *            paginação — usado na tela de listagem de produtos.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId, string $busca = '', int $pagina = 1, int $porPagina = 20): array
    {
        $pdo = getPDO();
        $offset = max(0, ($pagina - 1) * $porPagina);

        $sql = 'SELECT p.*, c.nome AS categoria_nome, u.sigla AS unidade_sigla
                FROM produtos p
                LEFT JOIN categorias c ON c.id = p.categoria_id
                LEFT JOIN unidades_medida u ON u.id = p.unidade_id
                WHERE p.empresa_id = :empresa_id AND p.deleted_at IS NULL';
        $parametros = [':empresa_id' => $empresaId];

        if ($busca !== '') {
            $sql .= ' AND (p.nome LIKE :busca OR p.codigo LIKE :busca OR p.codigo_barras LIKE :busca)';
            $parametros[':busca'] = '%' . $busca . '%';
        }

        $sql .= ' ORDER BY p.nome ASC LIMIT :limite OFFSET :offset';

        $stmt = $pdo->prepare($sql);
        foreach ($parametros as $chave => $valor) {
            $stmt->bindValue($chave, $valor);
        }
        $stmt->bindValue(':limite', $porPagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: busca um produto garantindo que pertence à empresa
     *            informada (mesma lógica de isolamento usada em
     *            Categoria::buscarPorId()).
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM produtos WHERE id = :id AND empresa_id = :empresa_id AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);

        $produto = $stmt->fetch();
        return $produto ?: null;
    }

    /**
     * FUNÇÃO: buscarPorCodigoOuBarras()
     * O QUE FAZ: localiza um produto pelo código interno OU pelo
     *            código de barras — usado no PDV, quando o funcionário
     *            digita/escaneia um código durante a venda.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorCodigoOuBarras(string $codigo, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM produtos
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL
               AND (codigo = :codigo OR codigo_barras = :codigo2)
             LIMIT 1'
        );
        $stmt->execute([':empresa_id' => $empresaId, ':codigo' => $codigo, ':codigo2' => $codigo]);

        $produto = $stmt->fetch();
        return $produto ?: null;
    }

    /**
     * FUNÇÃO: listarEstoqueBaixo()
     * O QUE FAZ: lista produtos cujo estoque atual está igual ou
     *            abaixo do estoque mínimo configurado — usado no
     *            dashboard do admin e em alertas automáticos.
     * FIM DA FUNÇÃO
     */
    public static function listarEstoqueBaixo(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM produtos
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL
               AND status = "ativo" AND estoque_atual <= estoque_minimo
             ORDER BY estoque_atual ASC'
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: insere um novo produto. O estoque inicial é sempre
     *            zero — para dar entrada em estoque, usa-se o fluxo
     *            de MovimentacaoEstoque::registrarEntrada(), que já
     *            gera o histórico corretamente.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, array $dados): int
    {
        $pdo = getPDO();

        $sql = "INSERT INTO produtos
                    (empresa_id, categoria_id, unidade_id, fornecedor_id, codigo, codigo_barras,
                     nome, descricao, preco_custo, preco_venda, estoque_atual, estoque_minimo,
                     estoque_maximo, permite_estoque_negativo, foto, status, created_at)
                VALUES
                    (:empresa_id, :categoria_id, :unidade_id, :fornecedor_id, :codigo, :codigo_barras,
                     :nome, :descricao, :preco_custo, :preco_venda, 0, :estoque_minimo,
                     :estoque_maximo, :permite_estoque_negativo, :foto, :status, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':categoria_id' => $dados['categoria_id'] ?: null,
            ':unidade_id' => $dados['unidade_id'] ?: null,
            ':fornecedor_id' => $dados['fornecedor_id'] ?: null,
            ':codigo' => $dados['codigo'] ?: null,
            ':codigo_barras' => $dados['codigo_barras'] ?: null,
            ':nome' => $dados['nome'],
            ':descricao' => $dados['descricao'] ?: null,
            ':preco_custo' => $dados['preco_custo'] ?: 0,
            ':preco_venda' => $dados['preco_venda'] ?: 0,
            ':estoque_minimo' => $dados['estoque_minimo'] ?: 0,
            ':estoque_maximo' => $dados['estoque_maximo'] ?: null,
            ':permite_estoque_negativo' => !empty($dados['permite_estoque_negativo']) ? 1 : 0,
            ':foto' => $dados['foto'] ?? null,
            ':status' => $dados['status'] ?? 'ativo',
        ]);

        $novoId = (int) $pdo->lastInsertId();

        // Se o admin não informou um código interno, geramos um
        // automaticamente a partir do próprio ID — sem código, o
        // produto ficava impossível de localizar na tela de PDV
        // (que busca exclusivamente por `codigo`/`codigo_barras`).
        if (empty($dados['codigo'])) {
            $codigoGerado = str_pad((string) $novoId, 4, '0', STR_PAD_LEFT);
            $pdo->prepare('UPDATE produtos SET codigo = :codigo WHERE id = :id')
                ->execute([':codigo' => $codigoGerado, ':id' => $novoId]);
        }

        return $novoId;
    }

    /**
     * FUNÇÃO: atualizar()
     * O QUE FAZ: atualiza os dados cadastrais de um produto (não
     *            mexe em estoque_atual — isso é responsabilidade
     *            exclusiva de MovimentacaoEstoque).
     * FIM DA FUNÇÃO
     */
    public static function atualizar(int $id, int $empresaId, array $dados): void
    {
        $pdo = getPDO();

        $sql = "UPDATE produtos SET
                    categoria_id = :categoria_id,
                    unidade_id = :unidade_id,
                    fornecedor_id = :fornecedor_id,
                    codigo = :codigo,
                    codigo_barras = :codigo_barras,
                    nome = :nome,
                    descricao = :descricao,
                    preco_custo = :preco_custo,
                    preco_venda = :preco_venda,
                    estoque_minimo = :estoque_minimo,
                    estoque_maximo = :estoque_maximo,
                    permite_estoque_negativo = :permite_estoque_negativo,
                    status = :status,
                    updated_at = NOW()
                WHERE id = :id AND empresa_id = :empresa_id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':categoria_id' => $dados['categoria_id'] ?: null,
            ':unidade_id' => $dados['unidade_id'] ?: null,
            ':fornecedor_id' => $dados['fornecedor_id'] ?: null,
            ':codigo' => $dados['codigo'] ?: null,
            ':codigo_barras' => $dados['codigo_barras'] ?: null,
            ':nome' => $dados['nome'],
            ':descricao' => $dados['descricao'] ?: null,
            ':preco_custo' => $dados['preco_custo'] ?: 0,
            ':preco_venda' => $dados['preco_venda'] ?: 0,
            ':estoque_minimo' => $dados['estoque_minimo'] ?: 0,
            ':estoque_maximo' => $dados['estoque_maximo'] ?: null,
            ':permite_estoque_negativo' => !empty($dados['permite_estoque_negativo']) ? 1 : 0,
            ':status' => $dados['status'] ?? 'ativo',
            ':id' => $id,
            ':empresa_id' => $empresaId,
        ]);
    }

    /**
     * FUNÇÃO: atualizarFoto()
     * O QUE FAZ: grava apenas o caminho da foto do produto.
     * FIM DA FUNÇÃO
     */
    public static function atualizarFoto(int $id, int $empresaId, string $caminhoFoto): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE produtos SET foto = :foto, updated_at = NOW() WHERE id = :id AND empresa_id = :empresa_id'
        );
        $stmt->execute([':foto' => $caminhoFoto, ':id' => $id, ':empresa_id' => $empresaId]);
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: soft delete de um produto (preserva histórico de
     *            vendas e movimentações já registradas).
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $id, int $empresaId): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE produtos SET deleted_at = NOW() WHERE id = :id AND empresa_id = :empresa_id'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);
    }
}
