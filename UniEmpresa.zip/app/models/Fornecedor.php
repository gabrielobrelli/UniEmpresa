<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Fornecedor.php
 * RESPONSABILIDADE: CRUD simples de fornecedores por empresa.
 * =============================================================
 */

class Fornecedor
{
    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista fornecedores ativos de uma empresa.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT * FROM fornecedores
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL AND status = 'ativo'
             ORDER BY nome ASC"
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: cadastra um novo fornecedor.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, string $nome, ?string $telefone, ?string $email, ?string $observacao): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "INSERT INTO fornecedores (empresa_id, nome, telefone, email, observacao, status, created_at)
             VALUES (:empresa_id, :nome, :telefone, :email, :observacao, 'ativo', NOW())"
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':nome' => $nome,
            ':telefone' => $telefone,
            ':email' => $email,
            ':observacao' => $observacao,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: soft delete de um fornecedor (mantém o vínculo com
     *            produtos e movimentações de estoque já registradas).
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $id, int $empresaId): void
    {
        $pdo = getPDO();
        $pdo->prepare("UPDATE fornecedores SET deleted_at = NOW(), status = 'inativo' WHERE id = :id AND empresa_id = :empresa_id")
            ->execute([':id' => $id, ':empresa_id' => $empresaId]);
    }
}
