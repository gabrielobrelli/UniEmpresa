<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Cliente.php
 * RESPONSABILIDADE: CRUD simples de clientes. O cadastro de
 *                    cliente é sempre opcional na venda (seção 27).
 * =============================================================
 */

class Cliente
{
    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista clientes de uma empresa, com busca textual.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId, string $busca = ''): array
    {
        $pdo = getPDO();
        $sql = 'SELECT * FROM clientes WHERE empresa_id = :empresa_id AND deleted_at IS NULL';
        $parametros = [':empresa_id' => $empresaId];

        if ($busca !== '') {
            $sql .= ' AND (nome LIKE :busca OR cpf_cnpj LIKE :busca)';
            $parametros[':busca'] = '%' . $busca . '%';
        }

        $sql .= ' ORDER BY nome ASC LIMIT 50';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($parametros);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: busca um cliente garantindo que pertence à empresa.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM clientes WHERE id = :id AND empresa_id = :empresa_id AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);

        $cliente = $stmt->fetch();
        return $cliente ?: null;
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: cadastra um novo cliente.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, array $dados): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO clientes (empresa_id, nome, cpf_cnpj, telefone, email, observacao, created_at)
             VALUES (:empresa_id, :nome, :cpf_cnpj, :telefone, :email, :observacao, NOW())'
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':nome' => $dados['nome'],
            ':cpf_cnpj' => $dados['cpf_cnpj'] ?? null,
            ':telefone' => $dados['telefone'] ?? null,
            ':email' => $dados['email'] ?? null,
            ':observacao' => $dados['observacao'] ?? null,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: atualizar()
     * O QUE FAZ: atualiza os dados de um cliente já cadastrado,
     *            sempre confirmando que ele pertence à empresa.
     * FIM DA FUNÇÃO
     */
    public static function atualizar(int $id, int $empresaId, array $dados): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE clientes SET nome = :nome, cpf_cnpj = :cpf_cnpj, telefone = :telefone,
                email = :email, observacao = :observacao
             WHERE id = :id AND empresa_id = :empresa_id'
        );
        $stmt->execute([
            ':nome' => $dados['nome'],
            ':cpf_cnpj' => $dados['cpf_cnpj'] ?? null,
            ':telefone' => $dados['telefone'] ?? null,
            ':email' => $dados['email'] ?? null,
            ':observacao' => $dados['observacao'] ?? null,
            ':id' => $id,
            ':empresa_id' => $empresaId,
        ]);
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: soft delete de um cliente (preserva o vínculo com
     *            vendas já registradas).
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $id, int $empresaId): void
    {
        $pdo = getPDO();
        $pdo->prepare('UPDATE clientes SET deleted_at = NOW() WHERE id = :id AND empresa_id = :empresa_id')
            ->execute([':id' => $id, ':empresa_id' => $empresaId]);
    }
}
