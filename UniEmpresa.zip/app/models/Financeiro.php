<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Financeiro.php
 * RESPONSABILIDADE: lançamentos financeiros manuais, consulta do
 *                    fluxo de caixa por período e cálculo dos
 *                    indicadores do balanço operacional (seções
 *                    30, 31 e 82 do documento de requisitos).
 *
 * IMPORTANTE (seção 82): o sistema nunca chama nada de "lucro" a
 * menos que realmente tenha todos os dados para calculá-lo. Os
 * indicadores aqui são rotulados com precisão: "capital investido
 * em estoque" (custo), "total de vendas" (receita bruta), "saldo"
 * (entradas − saídas), nunca "lucro".
 * =============================================================
 */

class Financeiro
{
    /**
     * FUNÇÃO: registrarManual()
     * O QUE FAZ: insere uma movimentação financeira manual (não
     *            vinda automaticamente de uma venda ou de uma
     *            entrada de estoque).
     * FIM DA FUNÇÃO
     */
    public static function registrarManual(int $empresaId, array $dados, int $responsavelId): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "INSERT INTO movimentacoes_financeiras
                (empresa_id, tipo, categoria, descricao, valor, forma_pagamento,
                 responsavel_id, observacao, data_movimentacao, created_at)
             VALUES
                (:empresa_id, :tipo, :categoria, :descricao, :valor, :forma_pagamento,
                 :responsavel_id, :observacao, :data_movimentacao, NOW())"
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':tipo' => $dados['tipo'],
            ':categoria' => $dados['categoria'],
            ':descricao' => $dados['descricao'],
            ':valor' => $dados['valor'],
            ':forma_pagamento' => $dados['forma_pagamento'] ?: null,
            ':responsavel_id' => $responsavelId,
            ':observacao' => $dados['observacao'] ?: null,
            ':data_movimentacao' => $dados['data_movimentacao'],
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: listarPorPeriodo()
     * O QUE FAZ: lista as movimentações financeiras de uma empresa
     *            dentro de um intervalo de datas.
     * FIM DA FUNÇÃO
     */
    public static function listarPorPeriodo(int $empresaId, string $dataInicio, string $dataFim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT m.*, u.nome AS responsavel_nome
             FROM movimentacoes_financeiras m
             JOIN usuarios u ON u.id = m.responsavel_id
             WHERE m.empresa_id = :empresa_id
               AND m.data_movimentacao BETWEEN :inicio AND :fim
             ORDER BY m.data_movimentacao DESC, m.created_at DESC'
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $dataInicio, ':fim' => $dataFim]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: totaisPorPeriodo()
     * O QUE FAZ: soma entradas e saídas do período e calcula o
     *            saldo (entradas − saídas).
     * FIM DA FUNÇÃO
     */
    public static function totaisPorPeriodo(int $empresaId, string $dataInicio, string $dataFim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT tipo, COALESCE(SUM(valor), 0) AS total
             FROM movimentacoes_financeiras
             WHERE empresa_id = :empresa_id AND data_movimentacao BETWEEN :inicio AND :fim
             GROUP BY tipo"
        );
        $stmt->execute([':empresa_id' => $empresaId, ':inicio' => $dataInicio, ':fim' => $dataFim]);

        $totais = ['entrada' => 0.0, 'saida' => 0.0];
        foreach ($stmt->fetchAll() as $linha) {
            $totais[$linha['tipo']] = (float) $linha['total'];
        }
        $totais['saldo'] = $totais['entrada'] - $totais['saida'];

        return $totais;
    }

    /**
     * FUNÇÃO: balancoOperacional()
     * O QUE FAZ: calcula os indicadores gerais do negócio (seção 82):
     *   - capital investido em estoque (soma de preco_custo * estoque_atual)
     *   - valor estimado do estoque a preço de venda
     *   - total de vendas do período
     * NÃO calcula "lucro" — apenas os componentes que o admin pode
     * usar para formar sua própria análise.
     * FIM DA FUNÇÃO
     */
    public static function balancoOperacional(int $empresaId): array
    {
        $pdo = getPDO();

        $stmt = $pdo->prepare(
            "SELECT
                COALESCE(SUM(preco_custo * estoque_atual), 0) AS capital_investido_estoque,
                COALESCE(SUM(preco_venda * estoque_atual), 0) AS valor_estimado_estoque
             FROM produtos
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL"
        );
        $stmt->execute([':empresa_id' => $empresaId]);
        $estoque = $stmt->fetch();

        $stmt = $pdo->prepare(
            "SELECT COALESCE(SUM(total), 0) AS total_vendas
             FROM vendas
             WHERE empresa_id = :empresa_id AND status = 'finalizada'
               AND MONTH(created_at) = MONTH(CURDATE()) AND YEAR(created_at) = YEAR(CURDATE())"
        );
        $stmt->execute([':empresa_id' => $empresaId]);
        $vendas = $stmt->fetch();

        return [
            'capital_investido_estoque' => (float) $estoque['capital_investido_estoque'],
            'valor_estimado_estoque' => (float) $estoque['valor_estimado_estoque'],
            'total_vendas_mes' => (float) $vendas['total_vendas'],
        ];
    }
}
