<?php
/**
 * =============================================================
 * ARQUIVO: app/models/ConfiguracaoEmpresa.php
 * RESPONSABILIDADE: armazenar pares chave/valor livres por empresa
 *                    — usado para o texto de boas-vindas exibido no
 *                    painel, e outras preferências futuras que não
 *                    precisam de uma coluna dedicada na tabela
 *                    `empresas` (seção 38 e 83 do documento).
 * =============================================================
 */

class ConfiguracaoEmpresa
{
    /**
     * FUNÇÃO: obter()
     * O QUE FAZ: lê o valor de uma chave de configuração da empresa,
     *            devolvendo um valor padrão se ainda não existir.
     * FIM DA FUNÇÃO
     */
    public static function obter(int $empresaId, string $chave, string $padrao = ''): string
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT valor FROM configuracoes_empresa WHERE empresa_id = :empresa_id AND chave = :chave LIMIT 1'
        );
        $stmt->execute([':empresa_id' => $empresaId, ':chave' => $chave]);
        $linha = $stmt->fetch();

        return $linha ? (string) $linha['valor'] : $padrao;
    }

    /**
     * FUNÇÃO: definir()
     * O QUE FAZ: grava (ou atualiza) o valor de uma chave de
     *            configuração da empresa.
     * COMO FAZ: usa "INSERT ... ON DUPLICATE KEY UPDATE", já que a
     *           tabela tem uma UNIQUE(empresa_id, chave) — evita
     *           precisar checar antes se a chave já existe.
     * FIM DA FUNÇÃO
     */
    public static function definir(int $empresaId, string $chave, string $valor): void
    {
        $pdo = getPDO();
        // IMPORTANTE: o PDO (com prepared statements nativos, sem
        // emulação) NÃO permite reutilizar o mesmo placeholder nomeado
        // duas vezes na mesma query — por isso usamos :valor e :valor2
        // com o MESMO valor, em vez de repetir :valor. Reutilizar o
        // mesmo nome gera "SQLSTATE[HY093]: Invalid parameter number".
        $stmt = $pdo->prepare(
            'INSERT INTO configuracoes_empresa (empresa_id, chave, valor)
             VALUES (:empresa_id, :chave, :valor)
             ON DUPLICATE KEY UPDATE valor = :valor2'
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':chave' => $chave,
            ':valor' => $valor,
            ':valor2' => $valor,
        ]);
    }
}
