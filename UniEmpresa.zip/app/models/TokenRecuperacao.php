<?php
/**
 * =============================================================
 * ARQUIVO: app/models/TokenRecuperacao.php
 * RESPONSABILIDADE: criar, validar e consumir tokens de
 *                    recuperação de senha ("esqueci minha senha").
 *
 * ESTRATÉGIA DE SEGURANÇA: o token que vai por e-mail/link para o
 * usuário NUNCA é o mesmo valor salvo no banco. Salvamos apenas o
 * HASH do token (sha256). Assim, mesmo que o banco de dados seja
 * comprometido, não é possível reconstruir um link de recuperação
 * válido a partir dos dados armazenados.
 * =============================================================
 */

class TokenRecuperacao
{
    /** Tempo de validade do token, em minutos. */
    private const VALIDADE_MINUTOS = 30;

    /**
     * FUNÇÃO: gerar()
     * O QUE FAZ: cria um novo token de recuperação para um usuário.
     * COMO FAZ: gera 32 bytes aleatórios seguros, guarda o hash
     *           (sha256) no banco com prazo de expiração, e devolve
     *           o token em texto puro — que é o único momento em que
     *           ele existe fora do formato de hash. Esse valor deve
     *           ser inserido no link enviado ao usuário.
     * FIM DA FUNÇÃO
     */
    public static function gerar(int $usuarioId): string
    {
        $tokenTextoPuro = bin2hex(random_bytes(32));
        $tokenHash = hash('sha256', $tokenTextoPuro);

        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO tokens_recuperacao (usuario_id, token_hash, expira_em, created_at)
             VALUES (:usuario_id, :token_hash, DATE_ADD(NOW(), INTERVAL :minutos MINUTE), NOW())'
        );
        $stmt->execute([
            ':usuario_id' => $usuarioId,
            ':token_hash' => $tokenHash,
            ':minutos' => self::VALIDADE_MINUTOS,
        ]);

        return $tokenTextoPuro;
    }

    /**
     * FUNÇÃO: validarEBuscarUsuario()
     * O QUE FAZ: recebe o token em texto puro (vindo da URL clicada
     *            pelo usuário), calcula o hash e procura um registro
     *            correspondente que ainda não tenha sido usado e que
     *            ainda esteja dentro do prazo de validade.
     * DEVOLVE: o ID do usuário dono do token, ou null se o token for
     *          inválido/expirado/já usado.
     * FIM DA FUNÇÃO
     */
    public static function validarEBuscarUsuario(string $tokenTextoPuro): ?int
    {
        $tokenHash = hash('sha256', $tokenTextoPuro);

        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT usuario_id FROM tokens_recuperacao
             WHERE token_hash = :hash AND usado_em IS NULL AND expira_em > NOW()
             LIMIT 1'
        );
        $stmt->execute([':hash' => $tokenHash]);
        $linha = $stmt->fetch();

        return $linha ? (int) $linha['usuario_id'] : null;
    }

    /**
     * FUNÇÃO: marcarComoUsado()
     * O QUE FAZ: impede que o mesmo token seja usado duas vezes,
     *            marcando o instante em que foi consumido.
     * FIM DA FUNÇÃO
     */
    public static function marcarComoUsado(string $tokenTextoPuro): void
    {
        $tokenHash = hash('sha256', $tokenTextoPuro);

        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE tokens_recuperacao SET usado_em = NOW() WHERE token_hash = :hash'
        );
        $stmt->execute([':hash' => $tokenHash]);
    }
}
