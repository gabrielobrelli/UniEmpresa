<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Notificacao.php
 * RESPONSABILIDADE: criar e consultar notificações do sistema,
 *                    classificadas por tipo e prioridade
 *                    (verde/amarelo/vermelho — seções 42 e 43).
 * =============================================================
 */

class Notificacao
{
    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: gera uma notificação para um usuário específico.
     *            É a função usada por qualquer parte do sistema que
     *            precise avisar alguém (estoque baixo, empresa
     *            congelada, nova mensagem, lembrete etc.).
     * FIM DA FUNÇÃO
     */
    public static function criar(?int $empresaId, int $usuarioId, string $tipo, string $prioridade, string $titulo, string $mensagem): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO notificacoes (empresa_id, usuario_id, tipo, prioridade, titulo, mensagem, created_at)
             VALUES (:empresa_id, :usuario_id, :tipo, :prioridade, :titulo, :mensagem, NOW())'
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':usuario_id' => $usuarioId,
            ':tipo' => $tipo,
            ':prioridade' => $prioridade,
            ':titulo' => $titulo,
            ':mensagem' => $mensagem,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: listarDoUsuario()
     * O QUE FAZ: lista as notificações mais recentes de um usuário
     *            (lidas e não lidas), para o sino de notificações.
     * FIM DA FUNÇÃO
     */
    public static function listarDoUsuario(int $usuarioId, int $limite = 20): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM notificacoes WHERE usuario_id = :usuario_id
             ORDER BY created_at DESC LIMIT :limite'
        );
        $stmt->bindValue(':usuario_id', $usuarioId, PDO::PARAM_INT);
        $stmt->bindValue(':limite', $limite, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: contarNaoLidas()
     * O QUE FAZ: conta quantas notificações não lidas o usuário tem
     *            — usado no número do sino no topo da tela.
     * FIM DA FUNÇÃO
     */
    public static function contarNaoLidas(int $usuarioId): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) AS total FROM notificacoes WHERE usuario_id = :usuario_id AND lida_em IS NULL'
        );
        $stmt->execute([':usuario_id' => $usuarioId]);

        return (int) $stmt->fetch()['total'];
    }

    /**
     * FUNÇÃO: marcarComoLida()
     * O QUE FAZ: marca uma notificação específica como lida,
     *            garantindo que pertence ao usuário que está pedindo
     *            (nunca marca notificação de outra pessoa).
     * FIM DA FUNÇÃO
     */
    public static function marcarComoLida(int $notificacaoId, int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->prepare(
            'UPDATE notificacoes SET lida_em = NOW() WHERE id = :id AND usuario_id = :usuario_id'
        )->execute([':id' => $notificacaoId, ':usuario_id' => $usuarioId]);
    }

    /**
     * FUNÇÃO: marcarTodasComoLidas()
     * O QUE FAZ: marca todas as notificações do usuário como lidas
     *            de uma vez (botão "marcar tudo como lido").
     * FIM DA FUNÇÃO
     */
    public static function marcarTodasComoLidas(int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->prepare(
            'UPDATE notificacoes SET lida_em = NOW() WHERE usuario_id = :usuario_id AND lida_em IS NULL'
        )->execute([':usuario_id' => $usuarioId]);
    }
}
