<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Auditoria.php
 * RESPONSABILIDADE: gravar um registro de log toda vez que uma
 *                    ação importante acontece no sistema (login,
 *                    criação/edição/exclusão de registros, venda,
 *                    cancelamento, alteração de permissões etc.).
 *
 * A tabela `auditoria` guarda o "antes" e o "depois" em formato
 * JSON, o que permite reconstruir o histórico de qualquer registro
 * mesmo que ele já tenha sido alterado várias vezes.
 * =============================================================
 */

class Auditoria
{
    /**
     * FUNÇÃO: registrar()
     * O QUE FAZ: insere uma linha na tabela `auditoria`.
     * COMO FAZ: recebe a ação (texto livre, ex.: "venda_finalizada"),
     *           a tabela e o ID do registro afetado (opcionais), e os
     *           dados antes/depois (também opcionais, como arrays
     *           associativos que serão convertidos para JSON).
     *           O usuário, a empresa e o IP são capturados
     *           automaticamente da sessão/requisição atual.
     * FIM DA FUNÇÃO
     */
    public static function registrar(
        string $acao,
        ?string $tabelaAfetada = null,
        ?int $registroId = null,
        ?array $dadosAnteriores = null,
        ?array $dadosNovos = null
    ): void {
        $pdo = getPDO();

        $sql = "INSERT INTO auditoria
                    (empresa_id, usuario_id, acao, tabela_afetada, registro_id,
                     dados_anteriores, dados_novos, ip, created_at)
                VALUES
                    (:empresa_id, :usuario_id, :acao, :tabela_afetada, :registro_id,
                     :dados_anteriores, :dados_novos, :ip, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':empresa_id' => usuarioEmpresaId(),
            ':usuario_id' => usuarioId(),
            ':acao' => $acao,
            ':tabela_afetada' => $tabelaAfetada,
            ':registro_id' => $registroId,
            ':dados_anteriores' => $dadosAnteriores !== null ? json_encode($dadosAnteriores) : null,
            ':dados_novos' => $dadosNovos !== null ? json_encode($dadosNovos) : null,
            ':ip' => $_SERVER['REMOTE_ADDR'] ?? null,
        ]);
    }
}
