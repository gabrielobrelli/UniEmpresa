<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Mensagem.php
 * RESPONSABILIDADE: enviar e listar mensagens dentro de uma
 *                    conversa, e controlar o status de leitura
 *                    (seção 41 do documento de requisitos).
 * =============================================================
 */

class Mensagem
{
    /**
     * FUNÇÃO: enviar()
     * O QUE FAZ: grava uma nova mensagem em uma conversa e atualiza
     *            o carimbo `ultima_mensagem_em` da conversa (usado
     *            para ordenar a lista de conversas pela mais recente).
     * FIM DA FUNÇÃO
     */
    public static function enviar(int $conversaId, int $remetenteId, string $texto): int
    {
        $pdo = getPDO();

        $stmt = $pdo->prepare(
            'INSERT INTO mensagens (conversa_id, remetente_id, texto, created_at)
             VALUES (:conversa_id, :remetente_id, :texto, NOW())'
        );
        $stmt->execute([':conversa_id' => $conversaId, ':remetente_id' => $remetenteId, ':texto' => $texto]);
        $mensagemId = (int) $pdo->lastInsertId();

        $pdo->prepare('UPDATE conversas SET ultima_mensagem_em = NOW() WHERE id = :id')
            ->execute([':id' => $conversaId]);

        return $mensagemId;
    }

    /**
     * FUNÇÃO: listarPorConversa()
     * O QUE FAZ: lista as mensagens de uma conversa em ordem
     *            cronológica, opcionalmente só as posteriores a um
     *            certo ID (usado pelo polling do frontend para
     *            buscar apenas mensagens novas, economizando dados
     *            — importante em hospedagem compartilhada).
     * FIM DA FUNÇÃO
     */
    public static function listarPorConversa(int $conversaId, int $depoisDoId = 0): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM mensagens WHERE conversa_id = :conversa_id AND id > :depois_de
             ORDER BY id ASC'
        );
        $stmt->execute([':conversa_id' => $conversaId, ':depois_de' => $depoisDoId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: marcarComoLidas()
     * O QUE FAZ: marca como lidas todas as mensagens de uma
     *            conversa que NÃO foram enviadas pelo usuário atual
     *            (ou seja, marca como lidas as mensagens recebidas).
     * FIM DA FUNÇÃO
     */
    public static function marcarComoLidas(int $conversaId, int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->prepare(
            'UPDATE mensagens SET lida_em = NOW()
             WHERE conversa_id = :conversa_id AND remetente_id != :usuario_id AND lida_em IS NULL'
        )->execute([':conversa_id' => $conversaId, ':usuario_id' => $usuarioId]);
    }
}
