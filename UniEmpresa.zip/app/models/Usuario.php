<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Usuario.php
 * RESPONSABILIDADE: toda leitura/escrita na tabela `usuarios`
 *                    relacionada a autenticação e cadastro.
 *
 * Este model NÃO faz nenhuma verificação de permissão — isso é
 * papel do middleware (app/middleware/Auth.php) e dos controllers.
 * Aqui só existe acesso a dados.
 * =============================================================
 */

class Usuario
{
    /**
     * FUNÇÃO: buscarPorEmail()
     * O QUE FAZ: procura um usuário (de qualquer tipo) pelo e-mail,
     *            usado no momento do login.
     * COMO FAZ: SELECT simples com prepared statement, retornando
     *           null quando nada é encontrado.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorEmail(string $email): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM usuarios WHERE email = :email AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([':email' => $email]);

        $usuario = $stmt->fetch();
        return $usuario ?: null;
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: procura um usuário pelo ID.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM usuarios WHERE id = :id AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([':id' => $id]);

        $usuario = $stmt->fetch();
        return $usuario ?: null;
    }

    /**
     * FUNÇÃO: existeAlgumMestre()
     * O QUE FAZ: verifica se já existe um usuário do tipo 'mestre'
     *            cadastrado no sistema.
     * PARA QUE SERVE: o instalador inicial usa isso para decidir se
     *                 pode ou não criar o primeiro Login Mestre —
     *                 evitando duplicidade caso o instalador seja
     *                 executado mais de uma vez.
     * FIM DA FUNÇÃO
     */
    public static function existeAlgumMestre(): bool
    {
        $pdo = getPDO();
        $stmt = $pdo->query("SELECT COUNT(*) AS total FROM usuarios WHERE tipo = 'mestre'");
        $linha = $stmt->fetch();

        return ((int) $linha['total']) > 0;
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: insere um novo usuário (mestre, admin ou
     *            funcionário) na tabela `usuarios`.
     * COMO FAZ: recebe um array associativo com os campos, gera o
     *           hash da senha com password_hash() (NUNCA grava a
     *           senha em texto puro) e retorna o ID gerado.
     * FIM DA FUNÇÃO
     */
    public static function criar(array $dados): int
    {
        $pdo = getPDO();

        $sql = "INSERT INTO usuarios
                    (empresa_id, tipo, nome, email, senha_hash, telefone, cargo,
                     data_admissao, meta_minutos_diarios, perfil_completo, status, created_at)
                VALUES
                    (:empresa_id, :tipo, :nome, :email, :senha_hash, :telefone, :cargo,
                     :data_admissao, :meta_minutos_diarios, :perfil_completo, :status, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':empresa_id' => $dados['empresa_id'] ?? null,
            ':tipo' => $dados['tipo'],
            ':nome' => $dados['nome'],
            ':email' => $dados['email'],
            // password_hash() usa o algoritmo padrão do PHP (atualmente
            // bcrypt), que já inclui "salt" automático — não é preciso
            // gerar salt manualmente.
            ':senha_hash' => password_hash($dados['senha'], PASSWORD_DEFAULT),
            ':telefone' => $dados['telefone'] ?? null,
            ':cargo' => $dados['cargo'] ?? null,
            ':data_admissao' => $dados['data_admissao'] ?? null,
            ':meta_minutos_diarios' => $dados['meta_minutos_diarios'] ?? 480,
            ':perfil_completo' => $dados['perfil_completo'] ?? 0,
            ':status' => $dados['status'] ?? 'ativo',
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: atualizarSenha()
     * O QUE FAZ: troca a senha de um usuário, sempre gerando um novo
     *            hash — nunca reaproveita ou expõe a senha anterior.
     * FIM DA FUNÇÃO
     */
    public static function atualizarSenha(int $usuarioId, string $novaSenha): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('UPDATE usuarios SET senha_hash = :hash, updated_at = NOW() WHERE id = :id');
        $stmt->execute([
            ':hash' => password_hash($novaSenha, PASSWORD_DEFAULT),
            ':id' => $usuarioId,
        ]);
    }

    /**
     * FUNÇÃO: atualizarFoto()
     * O QUE FAZ: grava o caminho da foto de perfil do usuário.
     * FIM DA FUNÇÃO
     */
    public static function atualizarFoto(int $usuarioId, string $caminhoFoto): void
    {
        $pdo = getPDO();
        $pdo->prepare('UPDATE usuarios SET foto = :foto, updated_at = NOW() WHERE id = :id')
            ->execute([':foto' => $caminhoFoto, ':id' => $usuarioId]);
    }

    /**
     * FUNÇÃO: atualizarPerfilProprio()
     * O QUE FAZ: atualiza os dados pessoais que o PRÓPRIO usuário
     *            (Mestre, Admin ou Funcionário) pode editar sobre si
     *            mesmo: nome, e-mail de acesso, telefone e uma
     *            bio/descrição curta (reaproveitamos a coluna
     *            `observacoes`, que já existia e não tinha uso para
     *            Mestre/Admin — evita precisar alterar o banco).
     * IMPORTANTE: a checagem de e-mail duplicado deve ser feita ANTES
     *             de chamar esta função (ver Usuario::buscarPorEmail()),
     *             pois aqui não há validação de unicidade.
     * FIM DA FUNÇÃO
     */
    public static function atualizarPerfilProprio(int $usuarioId, array $dados): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE usuarios SET nome = :nome, email = :email, telefone = :telefone,
                observacoes = :bio, updated_at = NOW()
             WHERE id = :id'
        );
        $stmt->execute([
            ':nome' => $dados['nome'],
            ':email' => $dados['email'],
            ':telefone' => $dados['telefone'] ?? null,
            ':bio' => $dados['bio'] ?? null,
            ':id' => $usuarioId,
        ]);
    }

    /**
     * FUNÇÃO: atualizarUltimaAtividade()
     * O QUE FAZ: marca o instante atual como a última atividade do
     *            usuário — usado para calcular o status online/offline
     *            (ver seção 50 do documento de requisitos).
     * FIM DA FUNÇÃO
     */
    public static function atualizarUltimaAtividade(int $usuarioId): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('UPDATE usuarios SET ultima_atividade = NOW() WHERE id = :id');
        $stmt->execute([':id' => $usuarioId]);
    }

    /**
     * FUNÇÃO: listarPorEmpresaETipo()
     * O QUE FAZ: lista os usuários (admins ou funcionários) de uma
     *            empresa específica — usado tanto pelo painel do
     *            Mestre (ver administradores de uma empresa) quanto
     *            pelo painel do Admin (ver seus funcionários).
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresaETipo(int $empresaId, string $tipo): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM usuarios
             WHERE empresa_id = :empresa_id AND tipo = :tipo AND deleted_at IS NULL
             ORDER BY nome ASC'
        );
        $stmt->execute([':empresa_id' => $empresaId, ':tipo' => $tipo]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: atualizarStatus()
     * O QUE FAZ: ativa ou desativa um usuário (bloqueia/libera login
     *            sem apagar o cadastro — soft delete lógico de acesso).
     * FIM DA FUNÇÃO
     */
    public static function atualizarStatus(int $usuarioId, string $status): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('UPDATE usuarios SET status = :status, updated_at = NOW() WHERE id = :id');
        $stmt->execute([':status' => $status, ':id' => $usuarioId]);
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: realiza a exclusão lógica (soft delete) de um
     *            usuário, preservando o histórico de vendas, jornada
     *            etc. já associado a ele.
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $usuarioId): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('UPDATE usuarios SET deleted_at = NOW() WHERE id = :id');
        $stmt->execute([':id' => $usuarioId]);
    }
}
