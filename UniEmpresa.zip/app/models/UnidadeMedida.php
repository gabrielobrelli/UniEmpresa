<?php
/**
 * =============================================================
 * ARQUIVO: app/models/UnidadeMedida.php
 * RESPONSABILIDADE: CRUD simples das unidades de medida que cada
 *                    empresa configura para seus produtos (Unidade,
 *                    Caixa, Metro, Quilograma, Litro etc. — seção 16).
 * =============================================================
 */

class UnidadeMedida
{
    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista todas as unidades de medida cadastradas por
     *            uma empresa.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM unidades_medida WHERE empresa_id = :empresa_id ORDER BY nome ASC'
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: cadastra uma nova unidade de medida para a empresa.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, string $nome, string $sigla): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO unidades_medida (empresa_id, nome, sigla, created_at)
             VALUES (:empresa_id, :nome, :sigla, NOW())'
        );
        $stmt->execute([':empresa_id' => $empresaId, ':nome' => $nome, ':sigla' => $sigla]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: garantirPadraoParaEmpresa()
     * O QUE FAZ: se a empresa ainda não tiver nenhuma unidade de
     *            medida cadastrada, cria um conjunto padrão básico
     *            (Unidade, Caixa, Quilograma, Litro, Metro, Pacote).
     * POR QUE EXISTE: evita que uma empresa recém-criada fique sem
     *                 nenhuma opção ao tentar cadastrar seu primeiro
     *                 produto — mas nada aqui é fixo: o admin pode
     *                 editar/criar livremente depois.
     * FIM DA FUNÇÃO
     */
    public static function garantirPadraoParaEmpresa(int $empresaId): void
    {
        if (!empty(self::listarPorEmpresa($empresaId))) {
            return;
        }

        $padroes = [
            ['Unidade', 'UN'],
            ['Caixa', 'CX'],
            ['Quilograma', 'KG'],
            ['Litro', 'L'],
            ['Metro', 'M'],
            ['Pacote', 'PCT'],
        ];

        foreach ($padroes as [$nome, $sigla]) {
            self::criar($empresaId, $nome, $sigla);
        }
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: remove uma unidade de medida da empresa. Só é
     *            chamada quando nenhum produto está usando essa
     *            unidade (verificado pela própria tela antes de
     *            oferecer a ação), já que não há soft delete aqui.
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $id, int $empresaId): void
    {
        $pdo = getPDO();
        $pdo->prepare('DELETE FROM unidades_medida WHERE id = :id AND empresa_id = :empresa_id')
            ->execute([':id' => $id, ':empresa_id' => $empresaId]);
    }

    /**
     * FUNÇÃO: estaEmUso()
     * O QUE FAZ: verifica se algum produto ativo usa esta unidade,
     *            para não deixar excluir uma unidade ainda em uso.
     * FIM DA FUNÇÃO
     */
    public static function estaEmUso(int $id, int $empresaId): bool
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT COUNT(*) AS total FROM produtos
             WHERE unidade_id = :id AND empresa_id = :empresa_id AND deleted_at IS NULL'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);

        return ((int) $stmt->fetch()['total']) > 0;
    }
}
