<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Empresa.php
 * RESPONSABILIDADE: toda leitura/escrita na tabela `empresas`.
 * Usado apenas pelas telas do Login Mestre — administradores e
 * funcionários nunca criam/editam empresas.
 * =============================================================
 */

class Empresa
{
    /**
     * FUNÇÃO: listarTodas()
     * O QUE FAZ: devolve a lista de empresas cadastradas, com busca
     *            textual opcional e paginação simples.
     * COMO FAZ: monta a cláusula WHERE dinamicamente apenas quando
     *           há termo de busca, sempre usando parâmetros amarrados
     *           (nunca concatenando o texto digitado na query).
     * FIM DA FUNÇÃO
     */
    public static function listarTodas(string $busca = '', int $pagina = 1, int $porPagina = 20): array
    {
        $pdo = getPDO();
        $offset = max(0, ($pagina - 1) * $porPagina);

        $sql = 'SELECT * FROM empresas WHERE deleted_at IS NULL';
        $parametros = [];

        if ($busca !== '') {
            $sql .= ' AND (nome_fantasia LIKE :busca OR razao_social LIKE :busca OR cpf_cnpj LIKE :busca)';
            $parametros[':busca'] = '%' . $busca . '%';
        }

        $sql .= ' ORDER BY created_at DESC LIMIT :limite OFFSET :offset';

        $stmt = $pdo->prepare($sql);
        foreach ($parametros as $chave => $valor) {
            $stmt->bindValue($chave, $valor);
        }
        $stmt->bindValue(':limite', $porPagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: contarTotal()
     * O QUE FAZ: conta quantas empresas existem (para paginação e
     *            para os números do dashboard do Mestre).
     * FIM DA FUNÇÃO
     */
    public static function contarPorStatus(): array
    {
        $pdo = getPDO();
        $stmt = $pdo->query(
            "SELECT status, COUNT(*) AS total FROM empresas WHERE deleted_at IS NULL GROUP BY status"
        );

        // Garante que os três status sempre apareçam no resultado,
        // mesmo que alguma contagem seja zero.
        $contagens = ['ativa' => 0, 'congelada' => 0, 'inativa' => 0];
        foreach ($stmt->fetchAll() as $linha) {
            $contagens[$linha['status']] = (int) $linha['total'];
        }

        return $contagens;
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: retorna os dados de uma empresa específica.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('SELECT * FROM empresas WHERE id = :id AND deleted_at IS NULL LIMIT 1');
        $stmt->execute([':id' => $id]);

        $empresa = $stmt->fetch();
        return $empresa ?: null;
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: insere uma nova empresa na tabela `empresas`.
     * DEVOLVE: o ID da empresa recém-criada.
     * FIM DA FUNÇÃO
     */
    public static function criar(array $dados): int
    {
        $pdo = getPDO();

        $sql = "INSERT INTO empresas
                    (razao_social, nome_fantasia, cpf_cnpj, segmento, telefone, whatsapp,
                     email, endereco, cidade, estado, cep, logo, observacoes, status, created_at)
                VALUES
                    (:razao_social, :nome_fantasia, :cpf_cnpj, :segmento, :telefone, :whatsapp,
                     :email, :endereco, :cidade, :estado, :cep, :logo, :observacoes, :status, NOW())";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':razao_social' => $dados['razao_social'],
            ':nome_fantasia' => $dados['nome_fantasia'],
            ':cpf_cnpj' => $dados['cpf_cnpj'] ?? null,
            ':segmento' => $dados['segmento'] ?? null,
            ':telefone' => $dados['telefone'] ?? null,
            ':whatsapp' => $dados['whatsapp'] ?? null,
            ':email' => $dados['email'] ?? null,
            ':endereco' => $dados['endereco'] ?? null,
            ':cidade' => $dados['cidade'] ?? null,
            ':estado' => $dados['estado'] ?? null,
            ':cep' => $dados['cep'] ?? null,
            ':logo' => $dados['logo'] ?? null,
            ':observacoes' => $dados['observacoes'] ?? null,
            ':status' => EMPRESA_ATIVA,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: atualizar()
     * O QUE FAZ: atualiza os dados cadastrais de uma empresa existente.
     * FIM DA FUNÇÃO
     */
    public static function atualizar(int $id, array $dados): void
    {
        $pdo = getPDO();

        $sql = "UPDATE empresas SET
                    razao_social = :razao_social,
                    nome_fantasia = :nome_fantasia,
                    cpf_cnpj = :cpf_cnpj,
                    segmento = :segmento,
                    telefone = :telefone,
                    whatsapp = :whatsapp,
                    email = :email,
                    endereco = :endereco,
                    cidade = :cidade,
                    estado = :estado,
                    cep = :cep,
                    observacoes = :observacoes,
                    updated_at = NOW()
                WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':razao_social' => $dados['razao_social'],
            ':nome_fantasia' => $dados['nome_fantasia'],
            ':cpf_cnpj' => $dados['cpf_cnpj'] ?? null,
            ':segmento' => $dados['segmento'] ?? null,
            ':telefone' => $dados['telefone'] ?? null,
            ':whatsapp' => $dados['whatsapp'] ?? null,
            ':email' => $dados['email'] ?? null,
            ':endereco' => $dados['endereco'] ?? null,
            ':cidade' => $dados['cidade'] ?? null,
            ':estado' => $dados['estado'] ?? null,
            ':cep' => $dados['cep'] ?? null,
            ':observacoes' => $dados['observacoes'] ?? null,
            ':id' => $id,
        ]);
    }

    /**
     * FUNÇÃO: atualizarLogo()
     * O QUE FAZ: grava apenas o caminho do arquivo de logo, separado
     *            do restante dos dados (o upload é tratado à parte).
     * FIM DA FUNÇÃO
     */
    public static function atualizarLogo(int $id, string $caminhoLogo): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare('UPDATE empresas SET logo = :logo, updated_at = NOW() WHERE id = :id');
        $stmt->execute([':logo' => $caminhoLogo, ':id' => $id]);
    }

    /**
     * FUNÇÃO: congelar()
     * O QUE FAZ: muda o status da empresa para 'congelada', grava o
     *            motivo, a mensagem exibida aos administradores e
     *            quem (Mestre) realizou a ação.
     * IMPORTANTE: congelar NUNCA apaga dados — apenas bloqueia o
     *             acesso (ver Auth::verificarEmpresaAtiva()).
     * FIM DA FUNÇÃO
     */
    public static function congelar(int $id, string $motivo, string $mensagem, int $mestreId): void
    {
        $pdo = getPDO();
        $sql = "UPDATE empresas SET
                    status = 'congelada',
                    motivo_congelamento = :motivo,
                    mensagem_congelamento = :mensagem,
                    congelada_por = :mestre_id,
                    congelada_em = NOW(),
                    updated_at = NOW()
                WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':motivo' => $motivo,
            ':mensagem' => $mensagem,
            ':mestre_id' => $mestreId,
            ':id' => $id,
        ]);
    }

    /**
     * FUNÇÃO: reativar()
     * O QUE FAZ: volta o status da empresa para 'ativa' e limpa os
     *            campos relacionados ao congelamento.
     * FIM DA FUNÇÃO
     */
    public static function reativar(int $id): void
    {
        $pdo = getPDO();
        $sql = "UPDATE empresas SET
                    status = 'ativa',
                    motivo_congelamento = NULL,
                    mensagem_congelamento = NULL,
                    congelada_por = NULL,
                    congelada_em = NULL,
                    updated_at = NOW()
                WHERE id = :id";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $id]);
    }

    /**
     * FUNÇÃO: desativar()
     * O QUE FAZ: marca a empresa como 'inativa' (diferente de
     *            congelada: usada para encerramentos definitivos,
     *            mas ainda sem exclusão física dos dados).
     * FIM DA FUNÇÃO
     */
    public static function desativar(int $id): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare("UPDATE empresas SET status = 'inativa', updated_at = NOW() WHERE id = :id");
        $stmt->execute([':id' => $id]);
    }

    /**
     * FUNÇÃO: contarUsuariosPorTipo()
     * O QUE FAZ: conta quantos administradores e funcionários uma
     *            empresa possui — usado na tela de detalhe da empresa.
     * FIM DA FUNÇÃO
     */
    public static function contarUsuariosPorTipo(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT tipo, COUNT(*) AS total FROM usuarios
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL
             GROUP BY tipo"
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        $contagens = ['admin' => 0, 'funcionario' => 0];
        foreach ($stmt->fetchAll() as $linha) {
            $contagens[$linha['tipo']] = (int) $linha['total'];
        }

        return $contagens;
    }

    /**
     * FUNÇÃO: atualizarCores()
     * O QUE FAZ: atualiza as cores de identidade visual da empresa
     *            (seção 91 do documento) — refletidas via variáveis
     *            CSS em todo o painel de administradores/funcionários
     *            dessa empresa.
     * FIM DA FUNÇÃO
     */
    public static function atualizarCores(int $id, string $corPrimaria, string $corSecundaria, string $corDestaque): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE empresas SET cor_primaria = :primaria, cor_secundaria = :secundaria,
                cor_destaque = :destaque, updated_at = NOW() WHERE id = :id'
        );
        $stmt->execute([
            ':primaria' => $corPrimaria,
            ':secundaria' => $corSecundaria,
            ':destaque' => $corDestaque,
            ':id' => $id,
        ]);
    }

    /**
     * FUNÇÃO: atualizarNomeExibido()
     * O QUE FAZ: permite à empresa customizar o nome que aparece
     *            para seus próprios usuários, sem alterar a razão
     *            social/nome fantasia oficial usada em documentos.
     * FIM DA FUNÇÃO
     */
    public static function atualizarNomeExibido(int $id, string $nomeExibido): void
    {
        $pdo = getPDO();
        $pdo->prepare('UPDATE empresas SET nome_fantasia = :nome, updated_at = NOW() WHERE id = :id')
            ->execute([':nome' => $nomeExibido, ':id' => $id]);
    }

    /**
     * FUNÇÃO: atualizarContato()
     * O QUE FAZ: permite ao administrador atualizar os dados de
     *            contato do dia a dia da empresa (telefone, whatsapp,
     *            e-mail, endereço) pela tela de Configurações — sem
     *            mexer nos dados cadastrais oficiais (razão social,
     *            CNPJ/CPF), que continuam sob responsabilidade do
     *            Mestre.
     * FIM DA FUNÇÃO
     */
    public static function atualizarContato(int $id, array $dados): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE empresas SET telefone = :telefone, whatsapp = :whatsapp,
                email = :email, endereco = :endereco, cidade = :cidade, estado = :estado,
                cep = :cep, updated_at = NOW()
             WHERE id = :id'
        );
        $stmt->execute([
            ':telefone' => $dados['telefone'] ?? null,
            ':whatsapp' => $dados['whatsapp'] ?? null,
            ':email' => $dados['email'] ?? null,
            ':endereco' => $dados['endereco'] ?? null,
            ':cidade' => $dados['cidade'] ?? null,
            ':estado' => $dados['estado'] ?? null,
            ':cep' => $dados['cep'] ?? null,
            ':id' => $id,
        ]);
    }
}
