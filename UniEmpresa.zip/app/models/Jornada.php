<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Jornada.php
 * RESPONSABILIDADE: controle de ponto — iniciar e encerrar a
 *                    sessão de serviço de um usuário (admin ou
 *                    funcionário), calcular a duração trabalhada
 *                    e compará-la com a meta diária configurada
 *                    (seções 45 a 48 do documento de requisitos).
 * =============================================================
 */

class Jornada
{
    /**
     * FUNÇÃO: buscarAbertaDoUsuario()
     * O QUE FAZ: verifica se o usuário já iniciou uma jornada hoje
     *            e ainda não a encerrou (campo `saida` NULL).
     * FIM DA FUNÇÃO
     */
    public static function buscarAbertaDoUsuario(int $usuarioId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM jornadas WHERE usuario_id = :usuario_id AND saida IS NULL
             ORDER BY entrada DESC LIMIT 1'
        );
        $stmt->execute([':usuario_id' => $usuarioId]);

        $jornada = $stmt->fetch();
        return $jornada ?: null;
    }

    /**
     * FUNÇÃO: iniciar()
     * O QUE FAZ: registra o início de uma sessão de serviço.
     * COMO FAZ: só cria uma nova linha se não existir uma jornada
     *           já aberta — evita registrar duas entradas seguidas
     *           por duplo clique no botão "Iniciar serviço".
     * FIM DA FUNÇÃO
     */
    public static function iniciar(int $empresaId, int $usuarioId): void
    {
        if (self::buscarAbertaDoUsuario($usuarioId)) {
            return;
        }

        $pdo = getPDO();
        $pdo->prepare(
            'INSERT INTO jornadas (empresa_id, usuario_id, entrada, created_at)
             VALUES (:empresa_id, :usuario_id, NOW(), NOW())'
        )->execute([':empresa_id' => $empresaId, ':usuario_id' => $usuarioId]);
    }

    /**
     * FUNÇÃO: encerrar()
     * O QUE FAZ: fecha a jornada em aberto do usuário, calculando a
     *            duração total em minutos.
     * FIM DA FUNÇÃO
     */
    public static function encerrar(int $usuarioId): void
    {
        $jornada = self::buscarAbertaDoUsuario($usuarioId);
        if (!$jornada) {
            return;
        }

        $pdo = getPDO();
        $pdo->prepare(
            'UPDATE jornadas SET saida = NOW(), duracao_minutos = TIMESTAMPDIFF(MINUTE, entrada, NOW())
             WHERE id = :id'
        )->execute([':id' => $jornada['id']]);
    }

    /**
     * FUNÇÃO: listarPorUsuario()
     * O QUE FAZ: lista o histórico de jornadas de um usuário dentro
     *            de um período.
     * FIM DA FUNÇÃO
     */
    public static function listarPorUsuario(int $usuarioId, string $dataInicio, string $dataFim): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM jornadas
             WHERE usuario_id = :usuario_id AND entrada BETWEEN :inicio AND :fim
             ORDER BY entrada DESC'
        );
        $stmt->execute([
            ':usuario_id' => $usuarioId,
            ':inicio' => $dataInicio . ' 00:00:00',
            ':fim' => $dataFim . ' 23:59:59',
        ]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: resumoPorUsuario()
     * O QUE FAZ: soma os minutos trabalhados no período e compara
     *            com a meta diária multiplicada pelos dias do
     *            período, indicando se o usuário está abaixo,
     *            dentro ou acima da meta esperada (seção 48).
     * FIM DA FUNÇÃO
     */
    public static function resumoPorUsuario(int $usuarioId, string $dataInicio, string $dataFim, int $metaMinutosDiarios): array
    {
        $jornadas = self::listarPorUsuario($usuarioId, $dataInicio, $dataFim);

        $minutosTrabalhados = 0;
        $diasComRegistro = [];

        foreach ($jornadas as $jornada) {
            $minutosTrabalhados += (int) ($jornada['duracao_minutos'] ?? 0);
            $diasComRegistro[substr($jornada['entrada'], 0, 10)] = true;
        }

        $totalDias = count($diasComRegistro);
        $minutosPrevistos = $totalDias * $metaMinutosDiarios;

        return [
            'minutos_trabalhados' => $minutosTrabalhados,
            'minutos_previstos' => $minutosPrevistos,
            'diferenca_minutos' => $minutosTrabalhados - $minutosPrevistos,
            'dias_registrados' => $totalDias,
        ];
    }

    /**
     * FUNÇÃO: statusHojeTodosDaEmpresa()
     * O QUE FAZ: lista, para cada usuário de uma empresa, se ele
     *            está com jornada aberta agora (trabalhando) ou não
     *            — usado no dashboard do administrador (seção 15/47).
     * FIM DA FUNÇÃO
     */
    public static function statusHojeTodosDaEmpresa(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "SELECT u.id, u.nome, u.cargo,
                    j.entrada AS entrada_aberta
             FROM usuarios u
             LEFT JOIN jornadas j ON j.usuario_id = u.id AND j.saida IS NULL
             WHERE u.empresa_id = :empresa_id AND u.tipo = 'funcionario'
               AND u.deleted_at IS NULL AND u.status = 'ativo'
             ORDER BY u.nome ASC"
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }
}
