<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Lembrete.php
 * RESPONSABILIDADE: criar e listar lembretes trocados entre
 *                    administradores e funcionários da mesma
 *                    empresa (seção 44 do documento de requisitos).
 * =============================================================
 */

require_once __DIR__ . '/Notificacao.php';

class Lembrete
{
    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: cria um lembrete para um destinatário específico,
     *            e já dispara uma notificação para ele ser avisado.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, int $criadorId, int $destinatarioId, string $titulo, string $descricao, string $prioridade): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            "INSERT INTO lembretes (empresa_id, criador_id, destinatario_id, titulo, descricao, prioridade, status, created_at)
             VALUES (:empresa_id, :criador_id, :destinatario_id, :titulo, :descricao, :prioridade, 'pendente', NOW())"
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':criador_id' => $criadorId,
            ':destinatario_id' => $destinatarioId,
            ':titulo' => $titulo,
            ':descricao' => $descricao,
            ':prioridade' => $prioridade,
        ]);
        $lembreteId = (int) $pdo->lastInsertId();

        Notificacao::criar($empresaId, $destinatarioId, 'sistema', $prioridade, 'Novo lembrete: ' . $titulo, $descricao);

        return $lembreteId;
    }

    /**
     * FUNÇÃO: listarRecebidos()
     * O QUE FAZ: lista os lembretes recebidos por um usuário, do
     *            mais recente para o mais antigo.
     * FIM DA FUNÇÃO
     */
    public static function listarRecebidos(int $usuarioId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT l.*, u.nome AS criador_nome
             FROM lembretes l
             JOIN usuarios u ON u.id = l.criador_id
             WHERE l.destinatario_id = :usuario_id
             ORDER BY (l.status = "pendente") DESC, l.created_at DESC'
        );
        $stmt->execute([':usuario_id' => $usuarioId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: listarEnviados()
     * O QUE FAZ: lista os lembretes que o próprio usuário criou.
     * FIM DA FUNÇÃO
     */
    public static function listarEnviados(int $usuarioId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT l.*, u.nome AS destinatario_nome
             FROM lembretes l
             JOIN usuarios u ON u.id = l.destinatario_id
             WHERE l.criador_id = :usuario_id
             ORDER BY l.created_at DESC'
        );
        $stmt->execute([':usuario_id' => $usuarioId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: marcarComoConcluido()
     * O QUE FAZ: o destinatário marca o lembrete como concluído,
     *            registrando a data de conclusão.
     * FIM DA FUNÇÃO
     */
    public static function marcarComoConcluido(int $lembreteId, int $usuarioId): void
    {
        $pdo = getPDO();
        $pdo->prepare(
            "UPDATE lembretes SET status = 'concluido', data_conclusao = NOW()
             WHERE id = :id AND destinatario_id = :usuario_id"
        )->execute([':id' => $lembreteId, ':usuario_id' => $usuarioId]);
    }
}
