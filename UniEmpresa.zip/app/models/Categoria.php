<?php
/**
 * =============================================================
 * ARQUIVO: app/models/Categoria.php
 * RESPONSABILIDADE: CRUD de categorias e subcategorias de produtos.
 * Uma subcategoria é apenas uma categoria cujo `categoria_pai_id`
 * aponta para outra categoria da mesma empresa (seção 17).
 *
 * Todas as consultas aqui filtram por empresa_id — o valor SEMPRE
 * vem de Auth::empresaIdEscopo() no controller que chama este model,
 * nunca é aceito diretamente de um parâmetro externo.
 * =============================================================
 */

class Categoria
{
    /**
     * FUNÇÃO: listarPorEmpresa()
     * O QUE FAZ: lista todas as categorias/subcategorias de uma
     *            empresa, já organizadas por nome.
     * FIM DA FUNÇÃO
     */
    public static function listarPorEmpresa(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM categorias
             WHERE empresa_id = :empresa_id AND deleted_at IS NULL
             ORDER BY categoria_pai_id IS NULL DESC, nome ASC'
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: listarPrincipais()
     * O QUE FAZ: lista apenas as categorias "de topo" (sem pai) —
     *            usado para montar o seletor de categoria-pai ao
     *            criar uma subcategoria.
     * FIM DA FUNÇÃO
     */
    public static function listarPrincipais(int $empresaId): array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM categorias
             WHERE empresa_id = :empresa_id AND categoria_pai_id IS NULL AND deleted_at IS NULL
             ORDER BY nome ASC'
        );
        $stmt->execute([':empresa_id' => $empresaId]);

        return $stmt->fetchAll();
    }

    /**
     * FUNÇÃO: buscarPorId()
     * O QUE FAZ: busca uma categoria garantindo que ela pertence à
     *            empresa informada — essa dupla checagem (id + empresa_id)
     *            é o que impede uma empresa de manipular dados de outra
     *            mesmo manipulando o ID na URL.
     * FIM DA FUNÇÃO
     */
    public static function buscarPorId(int $id, int $empresaId): ?array
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'SELECT * FROM categorias WHERE id = :id AND empresa_id = :empresa_id AND deleted_at IS NULL LIMIT 1'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);

        $categoria = $stmt->fetch();
        return $categoria ?: null;
    }

    /**
     * FUNÇÃO: criar()
     * O QUE FAZ: insere uma nova categoria ou subcategoria.
     * FIM DA FUNÇÃO
     */
    public static function criar(int $empresaId, string $nome, ?int $categoriaPaiId): int
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'INSERT INTO categorias (empresa_id, categoria_pai_id, nome, status, created_at)
             VALUES (:empresa_id, :categoria_pai_id, :nome, "ativa", NOW())'
        );
        $stmt->execute([
            ':empresa_id' => $empresaId,
            ':categoria_pai_id' => $categoriaPaiId,
            ':nome' => $nome,
        ]);

        return (int) $pdo->lastInsertId();
    }

    /**
     * FUNÇÃO: renomear()
     * O QUE FAZ: atualiza apenas o nome de uma categoria existente.
     * FIM DA FUNÇÃO
     */
    public static function renomear(int $id, int $empresaId, string $novoNome): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE categorias SET nome = :nome, updated_at = NOW()
             WHERE id = :id AND empresa_id = :empresa_id'
        );
        $stmt->execute([':nome' => $novoNome, ':id' => $id, ':empresa_id' => $empresaId]);
    }

    /**
     * FUNÇÃO: excluir()
     * O QUE FAZ: soft delete de uma categoria (mantém o histórico de
     *            produtos que já usaram essa categoria).
     * FIM DA FUNÇÃO
     */
    public static function excluir(int $id, int $empresaId): void
    {
        $pdo = getPDO();
        $stmt = $pdo->prepare(
            'UPDATE categorias SET deleted_at = NOW() WHERE id = :id AND empresa_id = :empresa_id'
        );
        $stmt->execute([':id' => $id, ':empresa_id' => $empresaId]);
    }
}
