<?php
/**
 * =============================================================
 * ARQUIVO: index.php
 * RESPONSABILIDADE: ponto de entrada da raiz do site. Hospedagens
 *                    como o InfinityFree exigem um arquivo
 *                    index.php na pasta pública (htdocs) — sem
 *                    ele, o acesso ao domínio retorna erro 404.
 *
 * O QUE FAZ: não exibe conteúdo próprio, apenas decide para onde
 *            encaminhar o visitante:
 *   - sem login ativo      -> /login.php
 *   - Mestre logado        -> /mestre/index.php
 *   - Administrador logado -> /admin/index.php
 *   - Funcionário logado   -> /funcionario/index.php
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';

// Exige login válido — cuida também de sessão expirada, empresa
// congelada e perfil incompleto, redirecionando sozinho quando
// necessário. Se não houver login, manda para /login.php.
Auth::exigirLogin();

switch (usuarioTipo()) {
    case TIPO_MESTRE:
        header('Location: /mestre/index.php');
        break;

    case TIPO_ADMIN:
        header('Location: /admin/index.php');
        break;

    case TIPO_FUNCIONARIO:
        // O funcionário cai direto na tela de jornada — bater o ponto
        // deve ser o primeiro passo do dia, antes de ir para o painel.
        header('Location: /funcionario/jornada.php');
        break;

    default:
        header('Location: /login.php');
        break;
}
exit;
