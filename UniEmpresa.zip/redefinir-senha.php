<?php
/**
 * =============================================================
 * ARQUIVO: redefinir-senha.php
 * RESPONSABILIDADE: segunda etapa da recuperação de senha — o
 *                    usuário chega aqui pelo link recebido e
 *                    define uma nova senha, desde que o token
 *                    ainda seja válido.
 * =============================================================
 */

require_once __DIR__ . '/bootstrap.php';
require_once __DIR__ . '/app/models/Usuario.php';
require_once __DIR__ . '/app/models/TokenRecuperacao.php';

$token = $_GET['token'] ?? ($_POST['token'] ?? '');
$erro = null;
$sucesso = false;

// Verifica logo de cara se o token é válido, para não mostrar o
// formulário de troca de senha sem necessidade.
$usuarioId = $token !== '' ? TokenRecuperacao::validarEBuscarUsuario($token) : null;

if ($token === '' || $usuarioId === null) {
    $erro = 'Este link de recuperação é inválido ou já expirou. Solicite um novo.';
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrfValidarOuFalhar();

    $novaSenha = (string) ($_POST['senha'] ?? '');
    $confirmacao = (string) ($_POST['confirmacao'] ?? '');

    if (strlen($novaSenha) < 8) {
        $erro = 'A nova senha deve ter pelo menos 8 caracteres.';
    } elseif ($novaSenha !== $confirmacao) {
        $erro = 'A confirmação de senha não confere com a senha informada.';
    } else {
        Usuario::atualizarSenha($usuarioId, $novaSenha);
        TokenRecuperacao::marcarComoUsado($token);
        Auditoria::registrar('senha_redefinida', 'usuarios', $usuarioId);
        $sucesso = true;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir senha — <?= escapar(APP_NOME) ?></title>
    <link rel="icon" type="image/png" href="/assets/img/empresa.png">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap">
    <link rel="stylesheet" href="/public/css/base.css">
    <link rel="stylesheet" href="/public/css/login.css">
</head>
<body class="pagina-login">

    <main class="cartao-login">
        <img src="/assets/img/empresa.png" alt="<?= escapar(APP_NOME) ?>" class="cartao-login__logo">
        <h1 class="cartao-login__titulo">Redefinir senha</h1>

        <?php if ($erro): ?>
            <div class="alerta alerta--erro"><?= escapar($erro) ?></div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <div class="alerta alerta--sucesso">Senha alterada com sucesso!</div>
            <a href="/login.php" class="botao botao--primario">Ir para o login</a>
        <?php elseif (!$erro): ?>
            <form method="POST" action="/redefinir-senha.php" class="formulario-login">
                <?= csrfCampoOculto() ?>
                <input type="hidden" name="token" value="<?= escapar($token) ?>">

                <label for="senha">Nova senha</label>
                <input type="password" id="senha" name="senha" minlength="8" required autofocus>

                <label for="confirmacao">Confirme a nova senha</label>
                <input type="password" id="confirmacao" name="confirmacao" minlength="8" required>

                <button type="submit" class="botao botao--primario">Salvar nova senha</button>
            </form>
        <?php endif; ?>
    </main>

</body>
</html>
